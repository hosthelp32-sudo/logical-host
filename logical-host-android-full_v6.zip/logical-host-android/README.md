# LOGICAL HOST - Android app

This repo turns the LOGICAL HOST website (https://logicalhost.online) into an installable Android app.
The app opens the trading app full screen in Chrome, so login, signals, alerts and trade execution are exactly as fast as the website.
Trades still run on the server when the app is closed.

## Get the app built on GitHub

1. Create a **private** repository on GitHub and upload every file in this folder (including the `.github` folder).
2. In the repository go to **Settings > Secrets and variables > Actions > New repository secret** and add the two secrets from `LOGICAL-HOST-signing-secrets.txt`:
   - `KEYSTORE_BASE64`
   - `KEYSTORE_PASSWORD`
3. Go to the **Actions** tab and run **Build Android app** (it also runs on every upload to `main`).
4. When it finishes, download the app from the **Releases** page (`LOGICAL-HOST.apk` to install on phones, `LOGICAL-HOST-playstore.aab` for Google Play).

Keep the signing secrets safe and never change them: the website only trusts apps signed with that key
(it is listed in https://logicalhost.online/.well-known/assetlinks.json). With a different key the app still works but shows an address bar.

## iPhone

iPhone users open https://logicalhost.online/app in Safari, tap **Share > Add to Home Screen**. It then opens like an app and can receive alerts (iOS 16.4+).

## Included in this version
- Floating bot bubble (BubbleService.kt, BubbleSetupActivity.kt, assets/lh-console.html) already joined into the manifest and build.
- execution-pipeline/ - the signal receiver and trade execution code, with PIPELINE.md explaining each step.
