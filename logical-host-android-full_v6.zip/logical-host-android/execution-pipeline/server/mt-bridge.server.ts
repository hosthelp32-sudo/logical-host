// MT5 bridge router (server only). MT5 calls go to the owner's own MetaTrader API
// (api.botlogicproapi.co.za, key in the BOTLOGIC_API_KEY secret) because the free public bridge
// (mt5.mtapi.io) now refuses accounts with "Trial expired". The app keeps speaking mtapi.io method
// names; they are renamed here. Broker search and anything the owner's API lacks still use
// mtapi.io. Sessions from mtapi.io (UUID tokens, with dashes) stay on mtapi.io.

export const BLP = "https://api.botlogicproapi.co.za";
export const MTAPI5 = "https://mt5.mtapi.io";

const RENAME: Record<string, string> = {
  GetQuote: "Quote",
  PriceHistoryEx: "PriceHistory",
  OrderSendSafe: "OrderSend",
  OrderCloseSafe: "OrderClose",
  OrderModifySafe: "OrderModify",
  AccountDetails: "Account",
};
const ON_BLP = new Set([
  "ConnectEx", "Connect", "CheckConnect", "Disconnect", "Account", "AccountSummary", "SymbolParams",
  "Quote", "PriceHistory", "OpenedOrders", "OrderHistory", "OrderSend", "OrderClose", "OrderModify",
]);
// Methods the owner's API does not have but the app calls with its sessions.
const LOCAL: Record<string, string> = { Subscribe: '"OK"', SymbolList: "[]" };
const CACHED = new Set(["Quote", "AccountSummary", "OpenedOrders"]);

export type Mt5Plan =
  | { kind: "local"; body: string }
  | { kind: "blp"; url: string; method: string }
  | { kind: "mtapi"; url: string };

const qs = (p: Record<string, string>) => new URLSearchParams(p).toString();

export function mt5Plan(method: string, params: Record<string, string>, hasKey: boolean): Mt5Plan {
  const mtapi = { kind: "mtapi" as const, url: `${MTAPI5}/${method}?${qs(params)}` };
  if (!hasKey) return mtapi;
  const id = params["id"] || "";
  if (id.includes("-")) return mtapi; // an mtapi.io session
  if (LOCAL[method] !== undefined && method !== "SymbolList") return { kind: "local", body: LOCAL[method]! };
  const name = RENAME[method] || method;
  if (ON_BLP.has(name)) {
    const p = { ...params };
    if (name === "PriceHistory" && !p["to"]) p["to"] = new Date().toISOString();
    return { kind: "blp", url: `${BLP}/${name}?${qs(p)}`, method: name };
  }
  if (id && LOCAL[method] !== undefined) return { kind: "local", body: LOCAL[method]! };
  return mtapi;
}

// The owner's API answers errors as {"detail":{"message":...}}; the app reads {"message":...}.
export function mt5Body(text: string) {
  try {
    const d = JSON.parse(text);
    if (d && typeof d === "object" && !Array.isArray(d) && d.message === undefined && d.detail) {
      const m = typeof d.detail === "string" ? d.detail : d.detail.message;
      if (typeof m === "string") return JSON.stringify({ message: m, code: d.detail.code ?? "ERROR" });
    }
  } catch { /* plain text such as a session token */ }
  return text;
}

export type Mt5Reply = { status: number; text: string; type: string };
const cache = new Map<string, { at: number; r: Mt5Reply }>();

async function get(url: string, headers: Record<string, string>, timeoutMs: number): Promise<Mt5Reply> {
  const r = await fetch(url, { headers: { accept: "application/json, text/plain", ...headers }, signal: AbortSignal.timeout(timeoutMs) });
  return { status: r.status, text: await r.text(), type: r.headers.get("content-type") || "text/plain" };
}

export async function mt5Fetch(method: string, params: Record<string, string>, timeoutMs = 55000): Promise<Mt5Reply> {
  const key = process.env["BOTLOGIC_API_KEY"] || "";
  const plan = mt5Plan(method, params, !!key);
  if (plan.kind === "local") return { status: 200, text: plan.body, type: "application/json" };
  if (plan.kind === "mtapi") return get(plan.url, {}, timeoutMs);
  const ck = CACHED.has(plan.method) ? plan.url : "";
  const hit = ck ? cache.get(ck) : undefined;
  if (hit && Date.now() - hit.at < 1500) return hit.r;
  try {
    const r = await get(plan.url, { "x-api-key": key }, timeoutMs);
    // The owner's API offline: logins fall back to the public bridge.
    if (r.status >= 502 && /^Connect/.test(plan.method)) return get(`${MTAPI5}/${method}?${qs(params)}`, {}, timeoutMs);
    const out = { ...r, text: mt5Body(r.text) };
    if (ck && r.status === 200) {
      cache.set(ck, { at: Date.now(), r: out });
      if (cache.size > 500) cache.clear();
    }
    return out;
  } catch (err) {
    if (/^Connect/.test(plan.method)) return get(`${MTAPI5}/${method}?${qs(params)}`, {}, timeoutMs);
    throw err;
  }
}
