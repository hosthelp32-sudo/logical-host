// @ts-nocheck -- loosely-typed compatibility layer for the platform SDK
// Replacement for the Base44 backend: implements the REST endpoints the platform's
// built-in SDK calls (/api/apps/...), storing everything in Lovable Cloud.
type Json = Record<string, any>;

// StudentStatus is reported by the trading app (licence-based, no account) when a bot is switched on/off.
const ANON_WRITE = new Set(["EaSignal", "AppDevice", "SignalNotification", "StudentStatus"]);

// The owner's admin account; its password comes from the ADMIN_PASSWORD secret when that is set.
const OWNER_ADMIN_EMAIL = "youngrims65@gmail.com";

// App visitors (no account) request access with just their email, so they may create these
// records — but only an admin can approve them, so non-admin creates are forced to these values.
const LOCKED_CREATE_FIELDS: Record<string, Json> = {
  AppSubscription: { status: "pending", expires_at: 0 },
  PaymentRecord: { status: "started" },
};
export function createFieldsFor(entity: string, user: Json | null, body: Json): Json | null {
  const locked = LOCKED_CREATE_FIELDS[entity];
  if (!locked) return user || ANON_WRITE.has(entity) ? body : null;
  return user?.role === "admin" ? body : { ...body, ...locked };
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body ?? null), {
    status,
    headers: { "Content-Type": "application/json" },
  });
const fail = (message: string, status = 400) => json({ message, detail: message }, status);

async function db() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin as any;
}

// ---------- passwords & sessions ----------
const toHex = (b: ArrayBuffer | Uint8Array) =>
  [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
const randHex = (n: number) => toHex(crypto.getRandomValues(new Uint8Array(n)));

async function hashPassword(password: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: new TextEncoder().encode(salt), iterations: 100000, hash: "SHA-256" },
    key,
    256,
  );
  return toHex(bits);
}

export function userView(u: Json) {
  return {
    ...(u.data || {}),
    id: u.id,
    email: u.email,
    full_name: u.full_name,
    role: u.role,
    created_date: u.created_date,
    updated_date: u.updated_date,
  };
}

// An admin can suspend or ban an account (data.account_status); blocked accounts cannot sign in and
// their open sessions stop working. New mentors start "pending" until the admin approves them.
// Admins are never blocked, and only an admin may set these fields.
// (The login form treats messages containing "verif", "otp" or "code" as a code step, so avoid them.)
export const PENDING_MESSAGE =
  "Your mentor account is waiting for the admin's approval. You can log in as soon as the admin approves it.";
export function accountBlock(u: Json | null): string | null {
  if (!u || u.role === "admin") return null;
  const st = u.data?.account_status;
  if (st === "pending") return PENDING_MESSAGE;
  if (st === "banned") return "This account has been banned.";
  if (st === "suspended") return "This account is suspended. Contact the admin to be activated again.";
  return null;
}
/** Profile saved at sign-up (the account cannot sign in yet, so the form sends it with register). */
export function registerData(body: Json, first: boolean): Json {
  const t = (v: unknown, n: number) => String(v ?? "").trim().slice(0, n);
  const d: Json = {};
  for (const [k, n] of [["display_name", 80], ["username", 40], ["whatsapp", 30], ["mentor_id", 80]] as const) {
    const v = t(body?.[k], n);
    if (v) d[k] = v;
  }
  if (!first) {
    d.account_status = "pending";
    d.status_changed_at = Date.now();
  }
  return d;
}
export function withoutAdminFields(d: Json): Json {
  const { account_status: _a, status_note: _n, status_changed_at: _c, ...rest } = d || {};
  return rest;
}

async function newSession(userId: string) {
  const token = randHex(32);
  await (await db()).from("lh_sessions").insert({ token, user_id: userId });
  return token;
}

export async function currentUser(request: Request): Promise<Json | null> {
  const h = request.headers.get("Authorization") || "";
  const token = h.startsWith("Bearer ") ? h.slice(7).trim() : "";
  if (!token || token === "null" || token === "undefined") return null;
  const s = await db();
  const { data: sess } = await s.from("lh_sessions").select("user_id").eq("token", token).maybeSingle();
  if (!sess) return null;
  const { data: user } = await s.from("lh_users").select("*").eq("id", sess.user_id).maybeSingle();
  return accountBlock(user) ? null : (user ?? null);
}

// ---------- query matching (Mongo-style subset) ----------
function eq(a: any, b: any) {
  if (Array.isArray(a)) return a.some((x) => eq(x, b));
  return a === b || (a != null && b != null && String(a) === String(b) && typeof a !== "object");
}
function matchCond(val: any, cond: any): boolean {
  if (cond && typeof cond === "object" && !Array.isArray(cond)) {
    const keys = Object.keys(cond);
    if (keys.some((k) => k.startsWith("$"))) {
      return keys.every((op) => {
        const c = cond[op];
        switch (op) {
          case "$eq": return eq(val, c);
          case "$ne": return !eq(val, c);
          case "$in": return (c as any[]).some((x) => eq(val, x));
          case "$nin": return !(c as any[]).some((x) => eq(val, x));
          case "$gt": return val > c;
          case "$gte": return val >= c;
          case "$lt": return val < c;
          case "$lte": return val <= c;
          case "$exists": return c ? val !== undefined && val !== null : val === undefined || val === null;
          case "$regex": return new RegExp(c, cond.$options || "").test(String(val ?? ""));
          case "$options": return true;
          default: return true;
        }
      });
    }
  }
  return eq(val, cond);
}
export function matches(obj: Json, q: Json | undefined): boolean {
  if (!q) return true;
  return Object.entries(q).every(([k, c]) => {
    if (k === "$or") return (c as Json[]).some((s) => matches(obj, s));
    if (k === "$and") return (c as Json[]).every((s) => matches(obj, s));
    if (k === "$nor") return !(c as Json[]).some((s) => matches(obj, s));
    const val = k.split(".").reduce((o: any, p) => (o == null ? undefined : o[p]), obj);
    return matchCond(val, c);
  });
}
export function applyList(items: Json[], params: URLSearchParams) {
  let out = items;
  const q = params.get("q");
  if (q) {
    const parsed = JSON.parse(q);
    out = out.filter((o) => matches(o, parsed));
  }
  const sort = params.get("sort");
  if (sort) {
    const desc = sort.startsWith("-");
    const f = sort.replace(/^[-+]/, "");
    out = [...out].sort((a, b) => {
      const x = a[f], y = b[f];
      if (x === y) return 0;
      if (x == null) return 1;
      if (y == null) return -1;
      return (x > y ? 1 : -1) * (desc ? -1 : 1);
    });
  }
  const skip = Number(params.get("skip") || 0);
  const limit = Number(params.get("limit") || 0);
  out = out.slice(skip, limit ? skip + limit : undefined);
  const fields = params.get("fields");
  if (fields) {
    const fs = fields.split(",");
    out = out.map((o) => Object.fromEntries(fs.concat("id").map((f) => [f, o[f]])));
  }
  return out;
}

// ---------- records ----------
const recView = (r: Json) => ({
  ...(r.data || {}),
  id: r.id,
  created_date: r.created_date,
  updated_date: r.updated_date,
  created_by: r.created_by,
  created_by_id: r.created_by_id,
});
const strip = (d: Json) => {
  const { id, created_date, updated_date, created_by, created_by_id, ...rest } = d || {};
  return rest;
};

async function allRecords(entity: string) {
  const { data, error } = await (await db())
    .from("lh_records").select("*").eq("entity", entity).order("created_date", { ascending: false }).limit(10000);
  if (error) throw error;
  return (data as Json[]).map(recView);
}
async function recentSignals(params: URLSearchParams) {
  let q: Json;
  try { q = JSON.parse(params.get("q") || "{}"); } catch { return null; }
  const code = q?.ea_code;
  if (typeof code !== "string" || (params.get("sort") || "-created_date") !== "-created_date") return null;
  const start = Math.max(0, Number(params.get("cursor") || 0));
  const limit = Math.max(1, Math.min(500, Number(params.get("limit") || 100)));
  const want = Math.min(10000, start + limit + 200);
  const { data, error } = await (await db())
    .from("lh_records").select("*").eq("entity", "EaSignal").eq("data->>ea_code", code)
    .order("created_date", { ascending: false }).limit(want);
  if (error) return null;
  const p = new URLSearchParams(params);
  p.delete("limit"); p.delete("cursor");
  const all = applyList((data as Json[]).map(recView), p);
  const items = all.slice(start, start + limit);
  const more = start + limit < all.length || (data as Json[]).length >= want;
  // Phones that may read signals also get the bot's instant "new signal" doorbell (live.server.ts).
  const lh_live = start === 0 ? await (await import("./live.server")).liveInfo(code).catch(() => null) : null;
  return { items, next_cursor: more ? String(start + limit) : null, ...(lh_live ? { lh_live } : {}) };
}
async function allUsers() {
  const { data } = await (await db()).from("lh_users").select("*").order("created_date", { ascending: false });
  return (data as Json[]).map(userView);
}

const canEdit = (user: Json | null, rec: Json, entity: string) =>
  ANON_WRITE.has(entity) || (user && (user.role === "admin" || rec.created_by_id === user.id || rec.created_by === user.email));

// Mentor signals: place/close trades for students whose bot is ON, even with their app closed.
// Runs after the reply, so the mentor's self-hosting PC gets its answer straight away and its
// next trade is never held back by students' MetaTrader orders.
async function afterSignals(request: Request, records: Json[]) {
  const { afterReply } = await import("./background");
  // Ring the phones' doorbell first so open apps fetch the signal at once (live.server.ts).
  const codes = records.filter((r) => r && r.event !== "heartbeat").map((r) => String(r.ea_code || ""));
  await afterReply(request, () => Promise.allSettled([
    import("./live.server").then((m) => m.ring(codes)),
    import("./auto.server").then((m) => m.runSignals(records)),
  ]));
}

// A self-hosting PC reports every 5 s that it is online (with its live trades). Only the newest
// report per bot and PC account is kept, so they never pile up or bury real signals.
async function pruneHeartbeats(rec: Json) {
  const code = rec?.data?.ea_code;
  if (!code) return;
  let q = (await db()).from("lh_records").delete()
    .eq("entity", "EaSignal").eq("data->>event", "heartbeat").eq("data->>ea_code", String(code)).neq("id", rec.id).lt("created_date", rec.created_date);
  if (rec.data.account) q = q.eq("data->>account", String(rec.data.account));
  await q;
}

// Clients with the bot ON: their phone reported "bot on" recently (it reports every few
// seconds while running) or the server is placing trades for them with the app closed.
export const CLIENT_FRESH_MS = 2 * 60 * 1000;
export function countClients(statuses: Json[], armed: Json[], now = Date.now()) {
  const on = new Set<string>();
  for (const s of statuses) {
    const t = Date.parse(s.updated_date || s.created_date || "");
    if (s.bot_on === true && Number.isFinite(t) && now - t < CLIENT_FRESH_MS) on.add(String(s.licence_code || s.email || s.id));
  }
  for (const a of armed) if (a.licence) on.add(String(a.licence));
  return on.size;
}
async function clientsOn(code: string) {
  if (!code) return 0;
  const s = await db();
  const since = new Date(Date.now() - CLIENT_FRESH_MS).toISOString();
  const [st, ar] = await Promise.all([
    s.from("lh_records").select("*").eq("entity", "StudentStatus").eq("data->>bot_code", code).gte("updated_date", since).limit(1000),
    s.from("lh_auto").select("licence").eq("ea_code", code).eq("armed", true).limit(1000),
  ]);
  return countClients(((st.data as Json[]) || []).map(recView), (ar.data as Json[]) || []);
}

// ---------- access security ----------
// Subscriptions and phone locks are only ever created by the server or an admin: a signed-in
// visitor must not be able to approve themselves, read other people's phone ids or take over
// someone else's locked email, and signals are only handed to phones with an active subscription.
const emptyRead = (sub?: string) =>
  json(sub === "count" ? { count: 0 } : sub === "v2" ? { items: [], next_cursor: null } : []);
async function accessGuard(request: Request, entity: string, sub: string | undefined, method: string, url: URL, body: Json, user: Json | null) {
  const dev = await import("./device.server");
  const device = dev.deviceFrom(request);
  const writes = method !== "GET";

  // Old Bot Studio use counts (the studio was removed) stay read-only.
  if (entity === "StudioUse") return fail("Not allowed", 403);
  // Deleted-key records are written by the server when a key is deleted.
  if (entity === "DeletedKey" && writes) return fail("Not allowed", 403);

  if ((entity === "AppSubscription" || entity === "PaymentRecord") && ["PUT", "PATCH", "DELETE"].includes(method))
    return fail("Only an admin can change this", 403);

  // Lifetime (R500) access never ends, so no new payment can be started for that email.
  if (entity === "PaymentRecord" && method === "POST") {
    const email = String(body?.email || "").trim().toLowerCase();
    if (email) {
      const { data } = await (await db()).from("lh_records").select("data").eq("entity", "AppSubscription").ilike("data->>email", email.replace(/[\\%_]/g, "\\$&")).limit(50);
      const { hasLifetime } = await import("./payfast.server");
      if (hasLifetime(((data as Json[]) || []).map((r) => r.data || {}), String(body?.platform || "both")))
        return fail("You already have lifetime access — there is nothing to renew.", 409);
    }
  }

  // Subscriptions and payment receipts are read one email at a time, never as a full list.
  if ((entity === "AppSubscription" || entity === "PaymentRecord") && !writes) {
    let q: Json = {};
    try { q = JSON.parse(url.searchParams.get("q") || "{}"); } catch { /* none */ }
    if (typeof q?.email !== "string" || !q.email.includes("@")) return emptyRead(sub && ["count", "v2"].includes(sub) ? sub : undefined);
  }

  if (entity === "EaSignal" && (!writes || sub === "aggregate")) {
    const ok = (await dev.deviceAccess(device)) || (!!user && (await dev.ownsABot(user.id)));
    if (!ok) return fail("An active subscription on this phone is required", 403);
  }

  if (entity === "AppDevice") {
    if (!dev.validDeviceId(device)) return writes ? fail("This device could not be identified", 403) : emptyRead(sub && ["count", "v2"].includes(sub) ? sub : undefined);
    const s = await db();
    const mine = async () =>
      ((await s.from("lh_records").select("*").eq("entity", "AppDevice").eq("data->>device_id", device).limit(5)).data as Json[]) || [];
    if (!writes) {
      const items = (await mine()).map(recView);
      if (sub && !["count", "v2"].includes(sub)) {
        const one = items.find((r) => r.id === sub);
        return one ? json(one) : fail("Not found", 404);
      }
      const list = applyList(items, url.searchParams);
      return sub === "count" ? json({ count: list.length }) : sub === "v2" ? json({ items: list, next_cursor: null }) : json(list);
    }
    // Phones are locked by claimDevice only; a phone may update its own backup, nothing else.
    if (method === "PUT" && sub) {
      const row = (await mine()).find((r) => r.id === sub);
      if (!row) return fail("You don't have permission to change this", 403);
      const { data: backup, device_name } = strip(body);
      const { data } = await s.from("lh_records")
        .update({ data: { ...row.data, ...(backup !== undefined ? { data: backup } : {}), ...(device_name ? { device_name: String(device_name).slice(0, 80) } : {}) }, updated_date: new Date().toISOString() })
        .eq("id", sub).select("*").single();
      // Keys this phone just added are now "used"; keys it took out are "removed from app".
      if (backup !== undefined)
        await (await import("./keys.server")).syncKeyUse(device, row.data?.data?.bots, backup?.bots).catch((e) => console.warn("key use", e));
      return json(recView(data));
    }
    return fail("Only an admin can change this", 403);
  }
  return null;
}

// ---------- router ----------
export async function handleApi(request: Request, splat: string): Promise<Response> {
  try {
    const url = new URL(request.url);
    const method = request.method.toUpperCase();
    const parts = splat.split("/").filter(Boolean);
    const body: Json = ["POST", "PUT", "PATCH", "DELETE"].includes(method)
      ? await request.json().catch(() => ({}))
      : {};
    const s = await db();

    if (parts[0] === "public") return json({ id: parts.at(-1), public_settings: { requires_auth: false } });
    if (parts[0] === "auth" && parts[1] === "logout") {
      const to = url.searchParams.get("from_url") || "/";
      const safe = to.startsWith(url.origin) || to.startsWith("/") ? to : "/";
      return Response.redirect(new URL(safe, url.origin).toString(), 302);
    }

    const [, section, ...rest] = parts; // parts[0] = appId
    const user = await currentUser(request);

    if (section === "auth") {
      const action = rest[0];
      const email = String(body.email || "").trim().toLowerCase();
      if (action === "register") {
        if (!email || !body.password) return fail("Email and password are required");
        if (String(body.password).length < 6) return fail("Password must be at least 6 characters");
        const { data: exists } = await s.from("lh_users").select("id").eq("email", email).maybeSingle();
        if (exists) return fail("An account with this email already exists", 409);
        const { count } = await s.from("lh_users").select("id", { count: "exact", head: true });
        const first = (count ?? 0) === 0;
        const salt = randHex(16);
        const { data: created, error } = await s.from("lh_users").insert({
          email, salt, password_hash: await hashPassword(String(body.password), salt),
          full_name: body.display_name || body.full_name || email.split("@")[0],
          role: first ? "admin" : "user",
          data: registerData(body, first),
        }).select("*").single();
        if (error) return fail(error.message, 500);
        // New mentor accounts wait for the admin's approval before they can log in.
        if (accountBlock(created)) {
          const m = await import("./emails.server");
          await m.later(request, () => m.sendMail("account-pending", created.email, { name: created.full_name }, created.id));
          return json({ success: true, pending: true, message: PENDING_MESSAGE });
        }
        return json({ success: true, access_token: await newSession(created.id), user: userView(created) });
      }
      if (action === "login") {
        let { data: u } = await s.from("lh_users").select("*").eq("email", email).maybeSingle();
        const ownerPassword = email === OWNER_ADMIN_EMAIL ? process.env.ADMIN_PASSWORD : undefined;
        // A fresh copy of the app has no owner row yet: the correct owner password creates it as admin.
        if (!u && ownerPassword && String(body.password || "") === ownerPassword) {
          const salt = randHex(16);
          const { data: made, error: mkErr } = await s.from("lh_users").insert({
            email, salt, password_hash: await hashPassword(ownerPassword, salt),
            full_name: email.split("@")[0], role: "admin", data: registerData({}, true),
          }).select("*").single();
          if (mkErr) return fail(mkErr.message, 500);
          u = made;
        }
        if (!u) return fail(action === "login" ? "Invalid email or password" : "Account not found", 401);
        if (ownerPassword) {
          // The owner's password is set from the secure ADMIN_PASSWORD secret; the stored hash follows it.
          if (String(body.password || "") !== ownerPassword) return fail("Invalid email or password", 401);
          if ((await hashPassword(ownerPassword, u.salt)) !== u.password_hash || u.role !== "admin") {
            const salt = randHex(16);
            await s.from("lh_users").update({ salt, role: "admin", password_hash: await hashPassword(ownerPassword, salt) }).eq("id", u.id);
            u.role = "admin";
          }
        } else if ((await hashPassword(String(body.password || ""), u.salt)) !== u.password_hash)
          return fail("Invalid email or password", 401);
        const blocked = accountBlock(u);
        if (blocked) return fail(blocked, 403);
        // No verification emails are sent, so registration is confirmed straight away.
        const token = await newSession(u.id);
        return json({ access_token: token, user: userView(u) });
      }
      if (action === "resend-otp") return json({ success: true });
      if (action === "reset-password-request") return json({ success: true });
      if (action === "change-password") {
        if (!user) return fail("Authentication required", 401);
        if (user.email === OWNER_ADMIN_EMAIL && process.env.ADMIN_PASSWORD)
          return fail("This admin password is managed in the project's secure settings", 400);
        if ((await hashPassword(String(body.current_password || ""), user.salt)) !== user.password_hash)
          return fail("Current password is incorrect", 400);
        const salt = randHex(16);
        await s.from("lh_users").update({ salt, password_hash: await hashPassword(String(body.new_password), salt) }).eq("id", user.id);
        return json({ success: true });
      }
      return fail("Not supported", 400);
    }

    // A phone claims its email (first phone wins); the server, not the app, decides who is locked out.
    if (section === "functions" && rest[0] === "claimDevice") {
      const { claimDevice, deviceFrom } = await import("./device.server");
      const out = await claimDevice({ ...body, device_id: deviceFrom(request) || body.device_id });
      return json(out, (out as Json).error ? 400 : 200);
    }
    // Email safety codes (codes.server.ts): ask for a code, recover bots, move access to this phone.
    if (section === "functions" && ["sendCode", "recoverBots", "moveDevice", "codesStatus"].includes(rest[0])) {
      const codes = await import("./codes.server");
      const { deviceFrom } = await import("./device.server");
      const device = deviceFrom(request);
      if (rest[0] === "codesStatus") return json({ ready: codes.codesReady() });
      if (rest[0] === "sendCode") {
        const out = await codes.requestCode({ email: body.email, purpose: body.purpose, device });
        return json(out, (out as Json).error ? 400 : 200);
      }
      if (rest[0] === "recoverBots") {
        const out = await codes.recoverKeys({ email: body.email, code: body.code });
        return json(out, (out as Json).error ? 400 : 200);
      }
      const out = await codes.moveDevice({ email: body.email, code: body.code, device, device_name: body.device_name });
      return json(out, (out as Json).error ? 400 : 200);
    }
    // The trading app checks a typed licence key: used on another phone, expired, deleted, ...
    if (section === "functions" && rest[0] === "checkKey") {
      const { checkKey } = await import("./keys.server");
      const { deviceFrom } = await import("./device.server");
      return json(await checkKey(body.code, deviceFrom(request)));
    }
    if (section === "functions" && rest[0] === "deleteUserAccount") {
      if (!user) return fail("Authentication required", 401);
      await s.from("lh_records").delete().eq("created_by_id", user.id);
      await s.from("lh_users").delete().eq("id", user.id);
      return json({ success: true });
    }
    if (section === "functions") return json({ error: "This function is not available" });

    if (section !== "entities") return json({});

    const entity = rest[0];
    const sub = rest[1];

    // ----- NewsEvent: live economic calendar (Investing.com), read-only -----
    if (entity === "NewsEvent" && method === "GET") {
      const { economicCalendar, liveReading, livePreRead } = await import("./news.server");
      // "pre~<id>": the pre-read a few minutes before the release, with the live 30-minute move.
      if (sub && sub.startsWith("pre~")) {
        let id = sub.slice(4);
        try { id = decodeURIComponent(id); } catch { /* keep as is */ }
        const live = await livePreRead(id);
        return live ? json(live) : fail("Not found", 404);
      }
      // "live~<id>": fresh figures for one release and the others at the same minute (news automation).
      if (sub && sub.startsWith("live~")) {
        let id = sub.slice(5);
        try { id = decodeURIComponent(id); } catch { /* keep as is */ }
        const live = await liveReading(id);
        return live ? json(live) : fail("Not found", 404);
      }
      const events = await economicCalendar();
      // The app reads one unpaged list, so every matching event is returned regardless of page size.
      const p = new URLSearchParams(url.searchParams);
      p.delete("limit"); p.delete("cursor"); p.delete("skip");
      if (!sub) return json(applyList(events, p));
      if (sub === "count") return json({ count: applyList(events, p).length });
      if (sub === "v2") return json({ items: applyList(events, p), next_cursor: null });
      const one = events.find((e) => e.id === sub);
      return one ? json(one) : fail("Not found", 404);
    }

    // ----- User entity -----
    if (entity === "User") {
      if (sub === "me") {
        if (!user) return json({ message: "Authentication required", extra_data: { reason: "auth_required" } }, 401);
        if (method === "PUT") {
          const { email: _e, role: _r, password_hash, salt, ...upd } = withoutAdminFields(strip(body));
          const full_name = upd.full_name ?? user.full_name;
          delete upd.full_name;
          const { data } = await s.from("lh_users")
            .update({ full_name, data: { ...(user.data || {}), ...upd }, updated_date: new Date().toISOString() })
            .eq("id", user.id).select("*").single();
          return json(userView(data));
        }
        return json(userView(user));
      }
      if (!user) return fail("Authentication required", 401);
      if (method === "GET" && !sub) {
        const list = applyList(await allUsers(), url.searchParams);
        return json(user.role === "admin" ? list : list.filter((u) => u.id === user.id));
      }
      if (method === "GET" && sub === "count") return json({ count: (await allUsers()).length });
      if (method === "GET" && sub === "v2") {
        const list = applyList(await allUsers(), url.searchParams);
        return json({ items: user.role === "admin" ? list : list.filter((u) => u.id === user.id), next_cursor: null });
      }
      if (sub && (method === "PUT" || method === "DELETE")) {
        if (user.role !== "admin" && sub !== user.id) return fail("Forbidden", 403);
        if (method === "DELETE") {
          await s.from("lh_users").delete().eq("id", sub);
          return json({ success: true });
        }
        const { data: target } = await s.from("lh_users").select("*").eq("id", sub).single();
        const { email: _e, password_hash, salt, full_name, role, ...upd } = user.role === "admin" ? strip(body) : withoutAdminFields(strip(body));
        const { data } = await s.from("lh_users").update({
          full_name: full_name ?? target.full_name,
          role: user.role === "admin" && role ? role : target.role,
          data: { ...(target.data || {}), ...upd },
          updated_date: new Date().toISOString(),
        }).eq("id", sub).select("*").single();
        if (user.role === "admin" && data) {
          const m = await import("./emails.server");
          const job = m.userStatusMail(target, data);
          if (job) await m.later(request, job);
        }
        return json(userView(data));
      }
      if (sub && method === "GET") {
        const { data } = await s.from("lh_users").select("*").eq("id", sub).maybeSingle();
        return data ? json(userView(data)) : fail("Not found", 404);
      }
      return fail("Not supported", 400);
    }

    // ----- access security (admins are never limited) -----
    if (user?.role !== "admin") {
      const guarded = await accessGuard(request, entity, sub, method, url, body, user);
      if (guarded) return guarded;
    }

    // ----- generic entities -----
    const writeAllowed = !!user || ANON_WRITE.has(entity);
    const now = new Date().toISOString();
    const insertRow = (d: Json) => ({
      entity, data: strip(d), created_by: user?.email ?? null, created_by_id: user?.id ?? null,
    });

    // Fast path for the trading app's signal receiver: it asks many times a second for the
    // newest signals of one bot, so read only that bot's latest rows instead of every signal.
    if (method === "GET" && entity === "EaSignal" && sub === "v2") {
      const fast = await recentSignals(url.searchParams);
      if (fast) return json(fast);
    }

    if (method === "GET") {
      if (!sub) return json(applyList(await allRecords(entity), url.searchParams));
      if (sub === "count") return json({ count: applyList(await allRecords(entity), url.searchParams).length });
      if (sub === "v2") {
        const p = new URLSearchParams(url.searchParams);
        const start = Number(p.get("cursor") || 0);
        const limit = Number(p.get("limit") || 100);
        p.delete("limit"); p.delete("cursor");
        const all = applyList(await allRecords(entity), p);
        const items = all.slice(start, start + limit);
        const next = start + limit < all.length ? String(start + limit) : null;
        return json({ items, next_cursor: next });
      }
      const { data } = await s.from("lh_records").select("*").eq("entity", entity).eq("id", sub).maybeSingle();
      return data ? json(recView(data)) : fail("Not found", 404);
    }

    if (method === "POST" && sub === "aggregate") {
      const items = (await allRecords(entity)).filter((o) => matches(o, body.query));
      if (!body.groupBy) return json({ rows: [{ count: items.length }] });
      const groups = new Map<any, number>();
      for (const o of items) groups.set(o[body.groupBy], (groups.get(o[body.groupBy]) || 0) + 1);
      return json({ rows: [...groups].map(([k, count]) => ({ [body.groupBy]: k, count })) });
    }

    if (method === "POST" && !sub) {
      const fields = createFieldsFor(entity, user, body);
      if (!fields) return fail("Authentication required", 401);
      // A PC heartbeat's client count is looked up while the record is saved, so the PC waits once.
      const beat = entity === "EaSignal" && body?.event === "heartbeat";
      const clientsP = beat ? clientsOn(String(body.ea_code || "")).catch(() => 0) : null;
      const { data, error } = await s.from("lh_records").insert(insertRow(fields)).select("*").single();
      if (error) return fail(error.message, 500);
      if (entity === "EaSignal" && data?.data?.event === "heartbeat") {
        await (await import("./background")).afterReply(request, () => pruneHeartbeats(data));
        // The PC's chart dot turns green when one or more clients have this bot ON.
        return json({ ...recView(data), lh_clients: await (clientsP || clientsOn(String(data.data.ea_code || "")).catch(() => 0)) });
      }
      if (entity === "EaSignal") await afterSignals(request, [recView(data)]);
      if (entity === "LicenseKey" || entity === "AppSubscription") {
        const m = await import("./emails.server");
        const job = entity === "LicenseKey" ? m.keyCreatedMail(data) : m.subscriptionMail(null, data.data, data.id);
        if (job) await m.later(request, job);
      }
      return json(recView(data));
    }

    if (!writeAllowed) return fail("Authentication required", 401);
    if (!user && entity === "StudentStatus" && method === "DELETE") return fail("Authentication required", 401);
    if (method === "POST" && sub === "bulk") {
      const rows = (Array.isArray(body) ? body : []).map((d) => insertRow(createFieldsFor(entity, user, d)));
      const { data, error } = await s.from("lh_records").insert(rows).select("*");
      if (error) return fail(error.message, 500);
      if (entity === "EaSignal") await afterSignals(request, (data as Json[]).map(recView));
      return json((data as Json[]).map(recView));
    }

    const all = await s.from("lh_records").select("*").eq("entity", entity).limit(10000);
    const raw = (all.data as Json[]) || [];

    if (method === "PATCH" && sub === "update-many") {
      const targets = raw.filter((r) => matches(recView(r), body.query) && canEdit(user, r, entity));
      for (const r of targets)
        await s.from("lh_records").update({ data: { ...r.data, ...strip(body.data) }, updated_date: now }).eq("id", r.id);
      return json({ updated: targets.length });
    }
    if (method === "DELETE" && !sub) {
      const targets = raw.filter((r) => matches(recView(r), body) && canEdit(user, r, entity));
      if (targets.length) await s.from("lh_records").delete().in("id", targets.map((r) => r.id));
      if (targets.length && entity === "LicenseKey") await (await import("./keys.server")).rememberDeleted(targets).catch(() => {});
      return json({ deleted: targets.length });
    }
    if (sub && (method === "PUT" || method === "DELETE")) {
      const r = raw.find((x) => x.id === sub);
      if (!r) return fail("Not found", 404);
      if (!canEdit(user, r, entity)) return fail("You don't have permission to change this", 403);
      if (method === "DELETE") {
        await s.from("lh_records").delete().eq("id", sub);
        if (entity === "LicenseKey") {
          await (await import("./keys.server")).rememberDeleted([r]).catch(() => {});
          const m = await import("./emails.server");
          const job = m.keyDeletedMail(r);
          if (job) await m.later(request, job);
        }
        return json({ success: true });
      }
      const { data } = await s.from("lh_records")
        .update({ data: { ...r.data, ...strip(body) }, updated_date: now }).eq("id", sub).select("*").single();
      if (entity === "AppDevice" && body?.data !== undefined && r.data?.device_id)
        await (await import("./keys.server")).syncKeyUse(String(r.data.device_id), r.data?.data?.bots, body.data?.bots).catch(() => {});
      if (entity === "AppSubscription" && data) {
        const m = await import("./emails.server");
        const job = m.subscriptionMail(r.data, data.data, data.id);
        if (job) await m.later(request, job);
      }
      return json(recView(data));
    }
    return fail("Not supported", 400);
  } catch (e: any) {
    console.error("platform api error", e);
    return fail(e?.message || "Server error", 500);
  }
}
