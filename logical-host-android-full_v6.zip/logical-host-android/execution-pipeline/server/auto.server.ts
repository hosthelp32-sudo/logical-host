// @ts-nocheck -- loosely-typed MetaTrader bridge responses
// Server-side auto execution: when a mentor's signal arrives, place (or close) the trades
// for every student whose bot is switched ON with MetaTrader connected — even when the
// student's app is closed. Phone and server race for the same "claim" so a signal is only
// ever executed once per licence.
import { p256 } from "@noble/curves/nist.js";
import { copiesFor, copyComment, isCopyOf } from "./copy-tags";
import { mtLogin } from "./mt-connect";

type Json = Record<string, any>;

async function db() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin as any;
}

// ---------- small helpers ----------
const enc = new TextEncoder();
const b64u = (b: ArrayBuffer | Uint8Array) =>
  btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const fromB64u = (s: string) => {
  const t = s.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(t + "===".slice((t.length + 3) % 4));
  return Uint8Array.from(bin, (c) => c.charCodeAt(0));
};
const concat = (...parts: Uint8Array[]) => {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let o = 0;
  for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
};
export const symKey = (s: string) => String(s || "").toUpperCase().replace(/\./g, "").replace(/(M|S)$/, "");

export function licenceValid(k: Json | null | undefined, now = Date.now()) {
  if (!k || !k.active) return false;
  return !(k.expires_at && Number(k.expires_at) < now);
}

// ---------- password encryption (AES-GCM, key from LH_AUTO_KEY) ----------
async function aesKey() {
  const secret = process.env.LH_AUTO_KEY;
  if (!secret) throw new Error("Auto execution is not configured");
  const raw = await crypto.subtle.digest("SHA-256", enc.encode(secret));
  return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}
export async function sealText(text: string) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await aesKey(), enc.encode(text));
  return b64u(iv) + "." + b64u(ct);
}
export async function openText(sealed: string) {
  const [iv, ct] = String(sealed).split(".");
  const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromB64u(iv) }, await aesKey(), fromB64u(ct));
  return new TextDecoder().decode(pt);
}

// ---------- MetaTrader bridge ----------
const DEFAULT_BRIDGE = { MT4: "https://mt4.mtapi.io", MT5: "https://mt5.mtapi.io" };
export function safeBridge(url: unknown) {
  try {
    const u = new URL(String(url || ""));
    if (u.protocol !== "https:") return null;
    if (/^(localhost|127\.|10\.|192\.168\.|169\.254\.|\[)/i.test(u.hostname) || /^\d+\.\d+\.\d+\.\d+$/.test(u.hostname)) return null;
    return u.origin + u.pathname.replace(/\/$/, "");
  } catch { return null; }
}
const bridgeOf = (row: Json) => row.bridge || DEFAULT_BRIDGE[row.platform === "MT4" ? "MT4" : "MT5"];
const isErr = (d: any) => !!d && typeof d === "object" && !Array.isArray(d) && typeof d.message === "string";
const ticketOf = (d: any) => d && typeof d === "object" ? d.ticket ?? d.Ticket ?? d.order ?? d.Order : null;

async function mt(row: Json, method: string, params: Json, timeoutMs = 15000) {
  if (bridgeOf(row) === DEFAULT_BRIDGE.MT5) {
    const r = await (await import("./mt-bridge.server")).mt5Fetch(method, Object.fromEntries(Object.entries(params).map(([k, v]) => [k, String(v)])), timeoutMs);
    let data: any = null;
    try { data = JSON.parse(r.text); } catch { data = null; }
    return { ok: r.status >= 200 && r.status < 300, text: r.text, data };
  }
  const res = await fetch(`${bridgeOf(row)}/${method}?${new URLSearchParams(params)}`, { signal: AbortSignal.timeout(timeoutMs), headers: (await import("./mt-relay")).mtKeyHeaders() });
  const text = await res.text();
  let data: any = null;
  try { data = JSON.parse(text); } catch { data = null; }
  return { ok: res.ok, text, data };
}

async function connect(row: Json) {
  const password = await openText(row.password_enc);
  // Same login as the phone (mt-connect.ts): by server name, then the server's own addresses.
  // Kept short because it runs in the background after the signal reply (about 30 s budget).
  const io = {
    get: (m: string, p: Record<string, string>) => mt(row, m, p, m === "ConnectEx" ? 22000 : m === "Connect" ? 13000 : 8000),
    wait: (ms: number) => new Promise((r) => setTimeout(r, Math.min(ms, 5000))),
  };
  const g = await mtLogin(io, { user: row.account, password, server: row.server }, { nameTimeout: 20, hostTimeout: 10, maxHosts: 2 });
  const patch: Json = { token: g.token };
  if (g.server && g.server !== row.server) patch.server = g.server;
  await (await db()).from("lh_auto").update(patch).eq("licence", row.licence);
  row.token = g.token;
  if (patch.server) row.server = patch.server;
  return g.token;
}

// Trades carry the comment "LOGICAL~<bot name>" plus the PC trade's ticket tag (copy-tags.ts,
// MetaTrader keeps 31 characters). Older trades with the untagged or bare bot name still count as
// the bot's own.
export function tradeComment(botName: unknown, ticket?: unknown) {
  return copyComment(botName, ticket);
}
export function isBotComment(comment: unknown, botName: unknown) {
  return isCopyOf(comment, botName);
}

// Open orders placed by this bot; reconnects once when the saved session has expired.
async function botOrders(row: Json) {
  for (let attempt = 0; attempt < 2; attempt++) {
    if (!row.token || attempt) await connect(row);
    const r = await mt(row, "OpenedOrders", { id: row.token });
    if (Array.isArray(r.data)) {
      return r.data.filter((o) => isBotComment(o.Comment ?? o.comment, row.bot_name));
    }
  }
  throw new Error("MetaTrader session could not be opened");
}

// A symbol's price digits never change, so each is looked up once per broker server.
const digitsCache = new Map<string, number>();
async function digitsOf(row: Json, symbol: string) {
  const key = `${row.platform}|${row.server}|${symbol}`;
  if (digitsCache.has(key)) return digitsCache.get(key);
  try {
    const r = await mt(row, "SymbolParams", { id: row.token, symbol });
    const d = Number(r.data?.symbolInfo?.digits ?? r.data?.digits);
    if (!Number.isFinite(d)) return null;
    if (digitsCache.size > 2000) digitsCache.clear();
    digitsCache.set(key, d);
    return d;
  } catch { return null; }
}

async function sendOrder(row: Json, order: Json) {
  const ok = (d: any) => !isErr(d) || ticketOf(d) != null;
  let r = await mt(row, "OrderSendSafe", order);
  if (isErr(r.data) && /not exist/i.test(r.data.message) && !/\.m$/i.test(order.symbol)) {
    order = { ...order, symbol: order.symbol + ".m" };
    r = await mt(row, "OrderSendSafe", order);
  }
  if (isErr(r.data) && /invalid stops/i.test(r.data.message) && (order.stoploss || order.takeprofit)) {
    r = await mt(row, "OrderSendSafe", { ...order, stoploss: 0, takeprofit: 0 });
    const t = ticketOf(r.data);
    if (t != null) await mt(row, "OrderModifySafe", { id: row.token, ticket: t, stoploss: order.stoploss, takeprofit: order.takeprofit }).catch(() => {});
  }
  if (!ok(r.data)) throw new Error(r.data?.message || "The broker rejected the order");
  return ticketOf(r.data);
}

// ---------- claims: one execution per licence per signal ----------
export const claimKey = (licence: string, kind: "open" | "close", sig: Json) =>
  `${licence}|${kind}|${sig.ticket && Number(sig.ticket) ? "t" + sig.ticket : "s" + sig.id}`;

export async function claim(key: string, licence: string, by: "server" | "phone") {
  const s = await db();
  const { error } = await s.from("lh_auto_claims").insert({ key, licence, by });
  if (!error) return { won: true, by };
  const { data } = await s.from("lh_auto_claims").select("*").eq("key", key).maybeSingle();
  return { won: false, by: data?.by || "server", status: data?.status, executed: data?.executed || 0, message: data?.message };
}
async function finish(key: string, status: string, executed: number, message: string | null) {
  await (await db()).from("lh_auto_claims").update({ status, executed, message }).eq("key", key);
}

// ---------- execution ----------
// Reasons a retry cannot fix.
const FINAL = /no money|not enough|insufficient|10019|market (is )?closed|trade (is )?disabled|not exist|invalid volume/i;

// Sends `want` orders at once, then counts the bot's open trades on the pair and places any
// missing ones one by one (brokers often turn away some orders sent at the same moment).
export async function placeAll(
  want: number,
  target: number,
  send: () => Promise<unknown>,
  countOpen: () => Promise<number | null>,
  pause = 300,
) {
  const first = await Promise.allSettled(Array.from({ length: want }, () => send()));
  let placed = first.filter((r) => r.status === "fulfilled").length;
  let why: string | null = (first.find((r) => r.status === "rejected") as any)?.reason?.message || null;
  for (let round = 0; round < 3 && placed < want; round++) {
    if (why && FINAL.test(why)) break;
    if (pause) await new Promise((r) => setTimeout(r, pause));
    const open = await countOpen().catch(() => null);
    const need = open == null ? want - placed : Math.min(want - placed, target - open);
    if (need <= 0) { placed = want; break; }
    for (let i = 0; i < need; i++) {
      try { await send(); placed++; } catch (e) { why = String(e?.message || e); if (FINAL.test(why)) break; }
    }
  }
  return { placed, why: placed >= want ? null : why };
}

export function planOpen(row: Json, sig: Json, openOnSymbol: number) {
  const listed = (row.pairs || []).find((p) => symKey(p.symbol) === symKey(sig.symbol));
  const pair = listed?.allowed ? listed : null;
  if (!pair) return { skip: listed ? `allow ${sig.symbol} in your pairs to trade it` : `${sig.symbol} is not in your pairs — add and allow it to trade it` };
  const max = Number(pair.maxTrades) > 0 ? Number(pair.maxTrades) : 1;
  const count = max - openOnSymbol;
  if (count <= 0) return { skip: `max trades reached on ${sig.symbol} (${max})` };
  const buy = String(sig.direction || "").toLowerCase() === "buy";
  const price = Number(sig.price);
  const sl = Number(sig.sl) || 0, tp = Number(sig.tp) || 0;
  if (price > 0 && ((tp > 0 && (buy ? tp <= price : tp >= price)) || (sl > 0 && (buy ? sl >= price : sl <= price))))
    return { skip: "invalid TP/SL levels" };
  return {
    count,
    order: {
      symbol: pair.resolved || pair.symbol,
      operation: buy ? 0 : 1,
      volume: Number(pair.lot) > 0 ? Number(pair.lot) : 0.01,
      slippage: 30,
      stoploss: sl,
      takeprofit: tp,
      comment: tradeComment(row.bot_name, sig.ticket),
    },
  };
}

async function licenceRecord(code: string) {
  const { data } = await (await db()).from("lh_records").select("data").eq("entity", "LicenseKey").eq("data->>code", code).limit(1);
  return data?.[0]?.data || null;
}
// Licence checks are remembered for a minute so a fast run of signals is not slowed down.
const licenceCache = new Map<string, { at: number; ok: boolean }>();
async function licenceOk(code: string) {
  const c = licenceCache.get(code);
  if (c && Date.now() - c.at < 60_000) return c.ok;
  const ok = licenceValid(await licenceRecord(code));
  if (licenceCache.size > 5000) licenceCache.clear();
  licenceCache.set(code, { at: Date.now(), ok });
  return ok;
}

// While the student's app is open the phone places the trade itself (instant, with the
// execution screen); the server waits and only steps in if the phone did not claim it.
export const PHONE_FRESH_MS = 8000;
export const PHONE_GRACE_MS = 3000;
export function phoneOpen(row: Json, now = Date.now()) {
  const t = row?.phone_seen ? Date.parse(row.phone_seen) : NaN;
  return Number.isFinite(t) && now - t < PHONE_FRESH_MS;
}
const yieldToPhone = (row: Json) => (phoneOpen(row) ? new Promise((r) => setTimeout(r, PHONE_GRACE_MS)) : null);

// The symbol the student's broker uses for the signal's pair.
const brokerSymbol = (row: Json, sig: Json) => {
  const p = (row.pairs || []).find((x) => symKey(x.symbol) === symKey(sig.symbol));
  return String(p?.resolved || p?.symbol || sig.symbol);
};
const onPair = (orders: Json[], sig: Json) => orders.filter((o) => symKey(o.Symbol ?? o.symbol) === symKey(sig.symbol));

async function runOpen(row: Json, sig: Json) {
  const key = claimKey(row.licence, "open", sig);
  await yieldToPhone(row);
  const c = await claim(key, row.licence, "server");
  if (!c.won) return;
  try {
    // Licence, open trades and price digits are fetched at the same time.
    const [ok, orders, digits0, phoneOk] = await Promise.all([
      licenceOk(row.licence), botOrders(row), digitsOf(row, brokerSymbol(row, sig)),
      // A lapsed subscription stops server trades too (phones armed before locks existed have no device yet).
      row.device ? import("./device.server").then((m) => m.deviceAccess(row.device)) : true,
    ]);
    if (!ok) {
      await (await db()).from("lh_auto").update({ armed: false }).eq("licence", row.licence);
      return finish(key, "skipped", 0, "licence is not active");
    }
    if (!phoneOk) return finish(key, "skipped", 0, "subscription is not active — renew in the app");
    const open = onPair(orders, sig).length;
    const plan = planOpen(row, sig, open);
    if (plan.skip) return finish(key, "skipped", 0, plan.skip);
    const digits = digits0 ?? (await digitsOf(row, plan.order.symbol));
    const round = (v: number) => (v && digits != null ? Number(v.toFixed(digits)) : v);
    const order = { ...plan.order, id: row.token, stoploss: round(plan.order.stoploss), takeprofit: round(plan.order.takeprofit) };
    const max = open + plan.count;
    const { placed, why } = await placeAll(plan.count, max, () => sendOrder(row, { ...order }), async () => onPair(await botOrders(row), sig).length);
    await finish(key, placed ? "done" : "failed", placed, why);
    if (placed) {
      const dir = String(sig.direction || "").toUpperCase();
      await notify(row, {
        title: `Trade placed — ${dir} ${sig.symbol}`,
        body: `${row.bot_name} placed ${placed} trade${placed === 1 ? "" : "s"} · ${order.volume} lot`,
        tag: key,
      });
    }
  } catch (e) {
    await finish(key, "failed", 0, String(e?.message || e)).catch(() => {});
  }
}

// Scalping: a close can arrive while the same trade is still being opened. Wait (up to 20 s)
// until that open has finished, so every trade it placed is closed too. Only server opens are
// waited for: a phone never marks its claim finished, so waiting on it only made closes late.
async function openFinished(row: Json, sig: Json) {
  if (!(sig.ticket && Number(sig.ticket))) return;
  const openKey = claimKey(row.licence, "open", sig);
  const until = Date.now() + 20_000;
  while (Date.now() < until) {
    const { data } = await (await db()).from("lh_auto_claims").select("status,by").eq("key", openKey).maybeSingle();
    if (!data || data.by !== "server" || data.status !== "running") return;
    await new Promise((r) => setTimeout(r, 150));
  }
}

async function runClose(row: Json, sig: Json) {
  if (Number(sig.remaining_lot) > 0) return; // partial closes stay with the phone
  const key = claimKey(row.licence, "close", sig);
  await yieldToPhone(row);
  const c = await claim(key, row.licence, "server");
  if (!c.won) return;
  try {
    await openFinished(row, sig);
    // only the copies of this PC trade, never the student's other trades on the pair
    const mine = copiesFor(onPair(await botOrders(row), sig), sig.ticket, row.bot_name);
    if (!mine.length) return finish(key, "skipped", 0, "no copy of this trade is open");
    const results = await Promise.allSettled(mine.map(async (o) => {
      const r = await mt(row, "OrderCloseSafe", { id: row.token, ticket: ticketOf(o) });
      if (isErr(r.data) && ticketOf(r.data) == null) throw new Error(r.data.message);
    }));
    const closed = results.filter((r) => r.status === "fulfilled").length;
    await finish(key, closed ? "done" : "failed", closed, results.find((r) => r.status === "rejected")?.reason?.message || null);
    if (closed) await notify(row, { title: `Trade closed — ${sig.symbol}`, body: `${row.bot_name} closed ${closed} trade${closed === 1 ? "" : "s"}`, tag: key });
  } catch (e) {
    await finish(key, "failed", 0, String(e?.message || e)).catch(() => {});
  }
}

// New SL / TP for the bot's trades on the signal's pair, rounded to the symbol's digits (0 = none).
export function modifyLevels(sig: Json, digits: number | null) {
  const r = (v: unknown) => {
    const n = Number(v) || 0;
    return n > 0 && digits != null ? Number(n.toFixed(digits)) : Math.max(0, n);
  };
  return { stoploss: r(sig.sl), takeprofit: r(sig.tp) };
}

// The mentor moved SL / TP on the PC: move the student's copies the same way. While the
// student's app is open, the app moves its own trades (it knows exactly which copy is which).
async function runModify(row: Json, sig: Json) {
  if (phoneOpen(row)) return;
  const key = `${row.licence}|modify|s${sig.id}`;
  const c = await claim(key, row.licence, "server");
  if (!c.won) return;
  try {
    await openFinished(row, sig);
    const [orders, digits] = await Promise.all([botOrders(row), digitsOf(row, brokerSymbol(row, sig))]);
    const mine = copiesFor(onPair(orders, sig), sig.ticket, row.bot_name);
    if (!mine.length) return finish(key, "skipped", 0, "no copy of this trade is open");
    const levels = modifyLevels(sig, digits ?? (await digitsOf(row, mine[0].Symbol ?? mine[0].symbol)));
    const results = await Promise.allSettled(mine.map(async (o) => {
      const r = await mt(row, "OrderModifySafe", { id: row.token, ticket: ticketOf(o), ...levels });
      if (isErr(r.data) && ticketOf(r.data) == null) throw new Error(r.data.message);
    }));
    const moved = results.filter((r) => r.status === "fulfilled").length;
    await finish(key, moved ? "done" : "failed", moved, results.find((r) => r.status === "rejected")?.reason?.message || null);
    if (moved) await notify(row, { title: `SL / TP updated — ${sig.symbol}`, body: `${row.bot_name} moved ${moved} trade${moved === 1 ? "" : "s"}`, tag: key });
  } catch (e) {
    await finish(key, "failed", 0, String(e?.message || e)).catch(() => {});
  }
}

const RUN = { open: runOpen, close: runClose, modify: runModify };

// Called after EaSignal records are created.
export async function runSignals(records: Json[]) {
  const signals = records.filter((r) => r && r.ea_code && RUN[r.event]);
  if (!signals.length || !process.env.LH_AUTO_KEY) return;
  const codes = [...new Set(signals.map((r) => String(r.ea_code)))];
  const { data: rows } = await (await db()).from("lh_auto").select("*").in("ea_code", codes).eq("armed", true);
  await Promise.allSettled((rows || []).flatMap((row) =>
    signals.filter((s) => s.ea_code === row.ea_code).map((s) => RUN[s.event](row, s)),
  ));
}

// ---------- arming from the phone ----------
export async function arm(input: Json) {
  const { deviceAccess, validDeviceId } = await import("./device.server");
  if (!validDeviceId(input.device) || !(await deviceAccess(input.device)))
    return { ok: false, message: "An active subscription on this phone is required — open the app again" };
  const k = await licenceRecord(input.licence);
  if (!licenceValid(k)) return { ok: false, message: "This licence is not active" };
  const { data: bots } = await (await db()).from("lh_records").select("data").eq("entity", "Bot").eq("id", k.bot_id).limit(1);
  const bot = bots?.[0]?.data;
  if (!bot?.code) return { ok: false, message: "This licence has no bot" };
  const s = await db();
  const { data: prev } = await s.from("lh_auto").select("password_enc,push").eq("licence", input.licence).maybeSingle();
  const row = {
    licence: input.licence,
    ea_code: String(bot.code),
    bot_name: String(bot.name || k.bot_name || "Bot"),
    platform: input.platform === "MT4" ? "MT4" : "MT5",
    bridge: safeBridge(input.bridge),
    account: String(input.account),
    server: String(input.server),
    password_enc: input.password ? await sealText(String(input.password)) : prev?.password_enc,
    token: input.token || null,
    pairs: input.pairs,
    push: input.push || prev?.push || null,
    armed: true,
    device: input.device,
    updated_at: new Date().toISOString(),
  };
  if (!row.password_enc) return { ok: false, message: "MetaTrader login missing" };
  const { error } = await s.from("lh_auto").upsert(row);
  if (error) return { ok: false, message: error.message };
  return { ok: true };
}

export async function disarm(licence: string) {
  await (await db()).from("lh_auto").update({ armed: false, updated_at: new Date().toISOString() }).eq("licence", licence);
  return { ok: true };
}

export async function seen(licence: string) {
  await (await db()).from("lh_auto").update({ phone_seen: new Date().toISOString() }).eq("licence", licence).eq("armed", true);
  // the server clock lets the phone tell how old a signal really is (its own clock may be off)
  return { ok: true, now: Date.now() };
}

export async function armed(licence: string) {
  const { data } = await (await db()).from("lh_auto").select("armed").eq("licence", licence).maybeSingle();
  return !!data?.armed;
}

export async function claimStatus(key: string) {
  const { data } = await (await db()).from("lh_auto_claims").select("by,status,executed,message").eq("key", key).maybeSingle();
  return data || null;
}

// ---------- Web Push (VAPID + aes128gcm) ----------
async function vapid() {
  const seed = process.env.LH_VAPID_SEED;
  if (!seed) return null;
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode("lh-vapid:" + seed)));
  const pub = p256.getPublicKey(d, false); // 65 bytes, uncompressed
  const jwk = { kty: "EC", crv: "P-256", d: b64u(d), x: b64u(pub.slice(1, 33)), y: b64u(pub.slice(33, 65)), ext: true };
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
  return { publicKey: b64u(pub), key };
}
export async function vapidPublicKey() {
  return (await vapid())?.publicKey || null;
}

async function hkdf(salt: Uint8Array, ikm: Uint8Array, info: Uint8Array, bytes: number) {
  const k = await crypto.subtle.importKey("raw", ikm, "HKDF", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: "HKDF", hash: "SHA-256", salt, info }, k, bytes * 8));
}

export async function encryptPush(sub: { keys: { p256dh: string; auth: string } }, payload: string) {
  const uaPub = fromB64u(sub.keys.p256dh);
  const auth = fromB64u(sub.keys.auth);
  const local = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  const asPub = new Uint8Array(await crypto.subtle.exportKey("raw", local.publicKey));
  const uaKey = await crypto.subtle.importKey("raw", uaPub, { name: "ECDH", namedCurve: "P-256" }, false, []);
  const shared = new Uint8Array(await crypto.subtle.deriveBits({ name: "ECDH", public: uaKey }, local.privateKey, 256));
  const ikm = await hkdf(auth, shared, concat(enc.encode("WebPush: info\0"), uaPub, asPub), 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdf(salt, ikm, enc.encode("Content-Encoding: aes128gcm\0"), 16);
  const nonce = await hkdf(salt, ikm, enc.encode("Content-Encoding: nonce\0"), 12);
  const aes = await crypto.subtle.importKey("raw", cek, "AES-GCM", false, ["encrypt"]);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce }, aes, concat(enc.encode(payload), new Uint8Array([2]))));
  const header = new Uint8Array(21);
  header.set(salt, 0);
  new DataView(header.buffer).setUint32(16, 4096);
  header[20] = 65;
  return concat(header, asPub, ct);
}

async function notify(row: Json, msg: { title: string; body: string; tag: string }) {
  const sub = row.push;
  if (!sub?.endpoint || !sub?.keys) return;
  const v = await vapid();
  if (!v) return;
  try {
    const aud = new URL(sub.endpoint).origin;
    const head = b64u(enc.encode(JSON.stringify({ typ: "JWT", alg: "ES256" })));
    const claims = b64u(enc.encode(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: "mailto:youngrims65@gmail.com" })));
    const sig = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, v.key, enc.encode(`${head}.${claims}`));
    const body = await encryptPush(sub, JSON.stringify(msg));
    const res = await fetch(sub.endpoint, {
      method: "POST",
      headers: {
        TTL: "3600",
        Urgency: "high",
        "Content-Encoding": "aes128gcm",
        "Content-Type": "application/octet-stream",
        Authorization: `vapid t=${head}.${claims}.${b64u(sig)}, k=${v.publicKey}`,
      },
      body,
    });
    if (res.status === 404 || res.status === 410) await (await db()).from("lh_auto").update({ push: null }).eq("licence", row.licence);
  } catch { /* notification is best-effort */ }
}
