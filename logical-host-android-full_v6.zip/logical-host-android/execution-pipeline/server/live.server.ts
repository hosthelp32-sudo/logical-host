// Instant signal doorbell: the moment a self-hosting PC (or a mentor) sends a signal, the server
// rings a data-free "new signal" ping on that bot's realtime topic, and every open phone that is
// listening asks for the newest signals straight away instead of waiting for its next check.
// The ping carries no trade data; phones still read signals through /api/apps (subscription
// checked there), and the topic name is only handed out in those checked replies.
type Json = Record<string, any>;

const env = (k: string) => (import.meta.env?.[k] as string | undefined) || (typeof process !== "undefined" ? process.env?.[k] : undefined);
const baseUrl = () => String(env("VITE_SUPABASE_URL") || env("SUPABASE_URL") || "").replace(/\/+$/, "");
const pubKey = () => String(env("VITE_SUPABASE_PUBLISHABLE_KEY") || env("SUPABASE_PUBLISHABLE_KEY") || "");

const topics = new Map<string, string>();
/** Unguessable topic for one bot code (keyed with the server's secret). */
export async function liveTopic(code: string) {
  const hit = topics.get(code);
  if (hit) return hit;
  const secret = (typeof process !== "undefined" && process.env?.["LH_AUTO_KEY"]) || "lh-live";
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode("sig|" + code)));
  const t = "lhs-" + [...sig.slice(0, 16)].map((b) => b.toString(16).padStart(2, "0")).join("");
  if (topics.size > 2000) topics.clear();
  topics.set(code, t);
  return t;
}

/** What a phone needs to listen: socket address, public key and the bot's topic. */
export async function liveInfo(code: string): Promise<Json | null> {
  const u = baseUrl(), k = pubKey();
  if (!code || !u.startsWith("https://") || !k) return null;
  return { u: u.replace(/^https:/, "wss:") + "/realtime/v1/websocket", k, t: await liveTopic(code) };
}

/** Ring the doorbell for these bot codes (never throws, gives up after 3 s). */
export async function ring(codes: string[]) {
  const u = baseUrl(), k = pubKey();
  const list = [...new Set(codes.filter(Boolean))];
  if (!list.length || !u || !k) return;
  try {
    const messages = await Promise.all(list.map(async (c) => ({ topic: await liveTopic(c), event: "sig", payload: {}, private: false })));
    await fetch(u + "/realtime/v1/api/broadcast", {
      method: "POST",
      headers: { apikey: k, "Content-Type": "application/json" },
      body: JSON.stringify({ messages }),
      signal: AbortSignal.timeout(3000),
    });
  } catch (e) {
    console.warn("live ring", e);
  }
}
