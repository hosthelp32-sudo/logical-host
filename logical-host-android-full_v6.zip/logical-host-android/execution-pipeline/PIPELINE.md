# How a signal becomes a trade (LOGICAL HOST)

1. MENTOR SENDS A SIGNAL
   The mentor posts BUY/SELL, pair, entry, stop loss and take profit from the mentor dashboard.
   It is saved in the database (server/api.server.ts).

2. SIGNAL RECEIVER
   - Server side: server/auto.server.ts -> runSignals() picks up every new signal for each armed bot
     (arm / disarm / armed), plans the trade (planOpen, modifyLevels) and claims it once
     (claim) so the same signal is never traded twice (phone and server can't both place it).
   - Phone side: phone/lh-auto.js listens for new signals while the app is open, and
     phone/lh-push-sw.js shows the "Signal" / "Trade placed" notification when it's closed.

3. EXECUTION
   - placeAll() sends the orders with the lot size and number of trades the user chose.
   - Orders go to MetaTrader through server/mt-bridge.server.ts (MT5 -> botlogicproapi.co.za,
     MT4 / broker search -> mtapi.io as backup). Your API key stays on the server, never on the phone.
   - The phone reaches it through routes/mt5.$.ts and routes/mt.ts on logicalhost.online.
   - phone/mt-connect.ts logs the account in and turns broker errors into plain messages
     (wrong password, wrong server, terminal error). phone/mt-relay.ts picks the fastest route.

4. NO ACCOUNT CONNECTED = PRACTICE MODE
   The bot still follows signals and shows "PRACTICE MODE" trades, but nothing is sent to a broker.

5. SCANNER
   phone/scanner.ts = live chart + picture scan. It gives a signal, and EXECUTE sends it through step 3.

6. BUBBLE
   app/.../BubbleService.kt floats the bot console over other apps. Open it from the website with
   intent://bubble#Intent;scheme=lhbubble;package=app.lovable.logicalhostea;end

Note: the execution-pipeline folder is a copy of the code that runs on logicalhost.online, for reading.
The Android app opens the website, so changes to trading are made on the website, not in the app.
Server secrets needed (set on the website server, never in this zip):
BOTLOGIC_API_KEY, LH_AUTO_KEY, LH_VAPID_SEED.
