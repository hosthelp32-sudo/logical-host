import { createFileRoute } from "@tanstack/react-router";
import { handlePayfastNotify } from "@/platform/payfast.server";

// PayFast posts payment notifications here; the handler confirms each one with PayFast before acting.
export const Route = createFileRoute("/api/public/payfast/notify")({
  server: { handlers: { POST: ({ request }) => handlePayfastNotify(request) } },
});
