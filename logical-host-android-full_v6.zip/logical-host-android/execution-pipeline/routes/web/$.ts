import { createFileRoute } from "@tanstack/react-router";

// Public picture of a mentor's bot web (/api/public/web/<link-name>/picture), used for the
// preview card when the link is shared. Only the bot picture is returned; webs are public pages.
export const Route = createFileRoute("/api/public/web/$")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const [key = "", action = ""] = String(params._splat || "").split("/");
        if (action !== "picture" || !/^[a-z0-9-]{1,48}$/i.test(key)) return new Response("Not found", { status: 404 });
        const { webPicture } = await import("@/platform/web-link.server");
        const pic = await webPicture(key).catch(() => null);
        if (!pic) return new Response("Not found", { status: 404 });
        if ("redirect" in pic) return Response.redirect(String(pic.redirect), 302);
        return new Response(pic.bytes, { headers: { "Content-Type": String(pic.type), "Cache-Control": "public, max-age=3600" } });
      },
    },
  },
});
