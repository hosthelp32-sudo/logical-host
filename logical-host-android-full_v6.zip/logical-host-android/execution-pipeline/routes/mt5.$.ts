import { createFileRoute } from "@tanstack/react-router";

// The trading app's MT5 address. Each call (/api/public/mt5/<Method>?...) goes to the owner's own
// MetaTrader API with its private key added on the server, or to the public bridge for broker
// search (mt-bridge.server.ts). Only MetaTrader method names are accepted, so it is not an open proxy.
export const Route = createFileRoute("/api/public/mt5/$")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const method = String((params as { _splat?: string })._splat || "");
        if (!/^[A-Za-z]{2,40}$/.test(method)) return new Response(JSON.stringify({ message: "Bad MetaTrader method" }), { status: 400 });
        const q = Object.fromEntries(new URL(request.url).searchParams);
        const { mt5Fetch } = await import("@/platform/mt-bridge.server");
        try {
          const r = await mt5Fetch(method, q);
          return new Response(r.text, { status: r.status, headers: { "content-type": r.type, "cache-control": "no-store" } });
        } catch (err) {
          console.error("mt5", method, String(err));
          return new Response(JSON.stringify({ message: "Could not reach the MetaTrader API — timed out" }), { status: 408, headers: { "content-type": "application/json" } });
        }
      },
    },
  },
});
