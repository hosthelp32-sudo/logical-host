import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

// Called by the trading app (licence-based, no website login). Every action is tied to an
// active licence; the server works out which mentor bot that licence follows itself.
const licence = z.string().trim().min(4).max(80);
const pair = z.object({
  symbol: z.string().min(1).max(40),
  resolved: z.string().max(40).optional(),
  lot: z.number().positive().max(100),
  maxTrades: z.number().int().min(1).max(50),
  allowed: z.boolean(),
});
const push = z.object({
  endpoint: z.string().url().max(1000).refine((u) => u.startsWith("https://")),
  keys: z.object({ p256dh: z.string().min(20).max(200), auth: z.string().min(8).max(100) }),
});
const armBody = z.object({
  licence,
  platform: z.enum(["MT4", "MT5"]),
  bridge: z.string().max(300).optional().nullable(),
  account: z.string().trim().min(1).max(40),
  server: z.string().trim().min(1).max(120),
  password: z.string().min(1).max(200).optional(),
  token: z.string().max(200).optional().nullable(),
  pairs: z.array(pair).max(60),
  push: push.optional().nullable(),
});
const claimBody = z.object({
  licence,
  kind: z.enum(["open", "close"]),
  signal: z.object({ id: z.union([z.string(), z.number()]).optional().nullable(), ticket: z.union([z.string(), z.number()]).optional().nullable() }),
});

const ok = (b: unknown, status = 200) => Response.json(b, { status });

export const Route = createFileRoute("/api/public/auto/$")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const auto = await import("@/platform/auto.server");
        if (params._splat === "vapid") return ok({ publicKey: await auto.vapidPublicKey() });
        if (params._splat === "status") {
          const url = new URL(request.url);
          const l = licence.safeParse(url.searchParams.get("licence"));
          const key = String(url.searchParams.get("key") || "");
          if (!l.success || !key.startsWith(l.data + "|")) return ok({ message: "bad request" }, 400);
          return ok(await auto.claimStatus(key.slice(0, 200)));
        }
        return ok({ message: "not found" }, 404);
      },
      POST: async ({ request, params }) => {
        const auto = await import("@/platform/auto.server");
        const body = await request.json().catch(() => null);
        try {
          if (params._splat === "arm") {
            const b = armBody.safeParse(body);
            if (!b.success) return ok({ ok: false, message: "Invalid settings" }, 400);
            return ok(await auto.arm({ ...b.data, device: request.headers.get("x-lh-device") || "" }));
          }
          if (params._splat === "disarm") {
            const b = z.object({ licence }).safeParse(body);
            if (!b.success) return ok({ ok: false }, 400);
            return ok(await auto.disarm(b.data.licence));
          }
          if (params._splat === "seen") {
            const b = z.object({ licence }).safeParse(body);
            if (!b.success) return ok({ ok: false }, 400);
            return ok(await auto.seen(b.data.licence));
          }
          if (params._splat === "claim") {
            const b = claimBody.safeParse(body);
            if (!b.success) return ok({ won: true, by: "phone" }, 400);
            if (!(await auto.armed(b.data.licence))) return ok({ won: true, by: "phone" });
            const key = auto.claimKey(b.data.licence, b.data.kind, b.data.signal);
            return ok({ key, ...(await auto.claim(key, b.data.licence, "phone")) });
          }
        } catch (e) {
          return ok({ ok: false, message: e instanceof Error ? e.message : "failed" }, 500);
        }
        return ok({ message: "not found" }, 404);
      },
    },
  },
});
