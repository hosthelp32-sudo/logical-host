import { createFileRoute } from "@tanstack/react-router";
import { mtKeyHeaders, mtRelayTarget } from "@/platform/mt-relay";

// Same-site relay for MetaTrader bridge calls. Phones whose browser or network blocks the bridge
// directly (in-app browsers, some carriers, privacy blockers) retry through here. Only the two
// public MetaTrader bridges are reachable, so it is not an open proxy.
export const Route = createFileRoute("/api/public/mt")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const target = mtRelayTarget(new URL(request.url).searchParams.get("u"));
        if (!target) return new Response(JSON.stringify({ message: "Bad MetaTrader address" }), { status: 400 });
        try {
          const u = new URL(target);
          if (u.hostname === "mt5.mtapi.io") {
            const { mt5Fetch } = await import("@/platform/mt-bridge.server");
            const m = await mt5Fetch(u.pathname.slice(1), Object.fromEntries(u.searchParams));
            return new Response(m.text, { status: m.status, headers: { "content-type": m.type, "cache-control": "no-store" } });
          }
          const r = await fetch(target, { headers: { accept: "application/json, text/plain", ...mtKeyHeaders() }, signal: AbortSignal.timeout(55000) });
          return new Response(await r.text(), {
            status: r.status,
            headers: { "content-type": r.headers.get("content-type") || "text/plain", "cache-control": "no-store" },
          });
        } catch (err) {
          console.error("mt relay", target.split("?")[0], String(err));
          return new Response(JSON.stringify({ message: "Could not reach the MetaTrader API — timed out" }), { status: 408, headers: { "content-type": "application/json" } });
        }
      },
    },
  },
});
