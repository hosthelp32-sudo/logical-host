// Trading app chart scanner (the "lw" screen of the platform export), live-chart version (prompt 44):
// header box with the logo and the word SCANNER, the bot's pairs, the live price, timeframes,
// a live candle chart from the connected MetaTrader account in the app's colours, SCAN, then the
// result box (pair, confidence, BUY/SELL, price, entry, TP, SL), lot + number of trades, EXECUTE
// and the reasons. The strategy is a simple placeholder reading (trend + structure + momentum);
// the owner will supply the real strategy later.
// The code is spliced into the export, so it uses the export's own names:
//   L = JSX runtime, _ = React, $ = trading-app state, bv = MetaTrader request, ng = logo picture link,
//   Tn = X icon, fn = loader icon.
// It must contain no backtick and no "${" (it is written inside String.raw).

export const scannerComponent = String.raw`
var __lhTfs=["M1","M5","M15","M30","H1","H4","D1"],__lhTfMin={M1:1,M5:5,M15:15,M30:30,H1:60,H4:240,D1:1440};
function __lhBars(list){return(Array.isArray(list)?list:[]).map(function(b){var o=Number(b.openPrice!=null?b.openPrice:b.open),h=Number(b.highPrice!=null?b.highPrice:b.high),l=Number(b.lowPrice!=null?b.lowPrice:b.low),c=Number(b.closePrice!=null?b.closePrice:b.close);return{o:o,h:h,l:l,c:c}}).filter(function(b){return b.o>0&&b.h>0&&b.l>0&&b.c>0&&b.h>=b.l})}
function __lhEma(a,n){var k=2/(n+1),e=a[0],out=[];for(var i=0;i<a.length;i++){e=i?a[i]*k+e*(1-k):a[i];out.push(e)}return out}
function __lhDp(p){p=Number(p);return p>=1000?2:p>=100?3:p>=10?3:5}
function __lhRound(x,dp){return Number(Number(x).toFixed(dp))}
// Placeholder reading until the owner sends the real strategy: three simple votes.
function __lhLiveRead(cs,price){if(!cs||cs.length<30)return null;var cl=cs.map(function(b){return b.c}),e20=__lhEma(cl,20),e50=__lhEma(cl,50),n=cs.length-1,why=[],up=0,dn=0;
  if(e20[n]>e50[n]){up++;why.push("Trend is up: the fast average is above the slow average")}else{dn++;why.push("Trend is down: the fast average is below the slow average")}
  var a=cs.slice(-20,-10),b=cs.slice(-10),hiA=Math.max.apply(null,a.map(function(x){return x.h})),hiB=Math.max.apply(null,b.map(function(x){return x.h})),loA=Math.min.apply(null,a.map(function(x){return x.l})),loB=Math.min.apply(null,b.map(function(x){return x.l}));
  if(hiB>hiA&&loB>loA){up++;why.push("Structure: higher highs and higher lows")}else if(hiB<hiA&&loB<loA){dn++;why.push("Structure: lower highs and lower lows")}else why.push("Structure: price is ranging");
  var m=cl[n]-cl[Math.max(0,n-5)];if(m>0){up++;why.push("Momentum: the last 5 candles pushed higher")}else{dn++;why.push("Momentum: the last 5 candles pushed lower")}
  var sig=up>=dn?"BUY":"SELL",votes=Math.max(up,dn),dp=__lhDp(price),d=sig==="BUY"?1:-1,e=__lhRound(price,dp);
  return{signal:sig,confidence:votes===3?82:votes===2?66:52,entry:e,sl:__lhRound(e*(1-d*.0039),dp),tp:__lhRound(e*(1+d*.0055),dp),dp:dp,reason:why}}
// Uploaded chart picture: the server reads pair, timeframe, price, bid, ask and the same three votes.
function __lhPicRead(r){if(!r||!(r.price>0))return null;var up=0,dn=0,why=[],T=function(k,u,d,g){var v=r[k];if(v==="up"){up++;why.push(u)}else if(v==="down"){dn++;why.push(d)}else why.push(g)};
  T("trend","Trend is up on the picture","Trend is down on the picture","Trend: no clear direction on the picture");
  T("structure","Structure: higher highs and higher lows","Structure: lower highs and lower lows","Structure: price is ranging");
  T("momentum","Momentum: the last candles pushed higher","Momentum: the last candles pushed lower","Momentum: flat");
  var sig=up>=dn?"BUY":"SELL",votes=Math.max(up,dn),dp=__lhDp(r.price),d=sig==="BUY"?1:-1,e=__lhRound(sig==="BUY"&&r.ask>0?r.ask:sig==="SELL"&&r.bid>0?r.bid:r.price,dp);
  return{signal:sig,confidence:votes===3?82:votes===2?66:52,entry:e,sl:__lhRound(e*(1-d*.0039),dp),tp:__lhRound(e*(1+d*.0055),dp),dp:dp,reason:why}}
function __lhShrink(file){return new Promise(function(ok,no){var fr=new FileReader();fr.onerror=function(){no(new Error("read"))};fr.onload=function(){var im=new Image();im.onerror=function(){no(new Error("img"))};im.onload=function(){var k=Math.min(1,1600/Math.max(im.width,im.height)),c=document.createElement("canvas");c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext("2d").drawImage(im,0,0,c.width,c.height);ok(c.toDataURL("image/jpeg",.88))};im.src=String(fr.result)};fr.readAsDataURL(file)})}
// Free on-phone chart picture reader (no AI, no credits). Candles are found by contrast against the
// background, so any chart theme/colour works; direction comes from candle positions, not colours.
function __lhPix(im){var W=im.width,H=im.height,D=im.data,x0=Math.floor(W*.02),x1=Math.floor(W*.86),y0=Math.floor(H*.1),y1=Math.floor(H*.94),hist={},best=0,bk=0;
  for(var y=y0;y<y1;y+=3)for(var x=x0;x<x1;x+=3){var i=(y*W+x)*4,k=(D[i]>>4)*256+(D[i+1]>>4)*16+(D[i+2]>>4);hist[k]=(hist[k]||0)+1;if(hist[k]>best){best=hist[k];bk=i}}
  var br=D[bk],bg=D[bk+1],bb=D[bk+2],ink=function(x,y){var i=(y*W+x)*4;return Math.abs(D[i]-br)+Math.abs(D[i+1]-bg)+Math.abs(D[i+2]-bb)>70};
  var skipR={},skipC={},span=x1-x0,tall=y1-y0;
  for(var y=y0;y<y1;y++){var n=0;for(var x=x0;x<x1;x++)if(ink(x,y))n++;if(n>span*.45)skipR[y]=1}
  for(var x=x0;x<x1;x++){var n=0;for(var y=y0;y<y1;y++)if(!skipR[y]&&ink(x,y))n++;if(n>tall*.8)skipC[x]=1}
  var cols=[];for(var x=x0;x<x1;x++){var t=-1,b=-1;if(!skipC[x])for(var y=y0;y<y1;y++)if(!skipR[y]&&ink(x,y)){if(t<0)t=y;b=y}cols.push(t<0?null:{t:t,b:b})}
  var cs=[],g=null,flush=function(){if(g&&g.w<=W*.05)cs.push({h:H-g.t,l:H-g.b,c:H-(g.t+g.b)/2,o:H-(g.t+g.b)/2,y:(g.t+g.b)/2});g=null};
  cols.forEach(function(c){if(!c){flush();return}if(!g)g={t:c.t,b:c.b,w:1};else{g.t=Math.min(g.t,c.t);g.b=Math.max(g.b,c.b);g.w++}});flush();
  return cs}
function __lhCandles(im){var W=im.width,H=im.height,D=im.data,x0=Math.floor(W*.02),x1=Math.floor(W*.86),y0=Math.floor(H*.1),y1=Math.floor(H*.94),hist={},best=0,bk=0;
  for(var y=y0;y<y1;y+=3)for(var x=x0;x<x1;x+=3){var i=(y*W+x)*4,k=(D[i]>>4)*256+(D[i+1]>>4)*16+(D[i+2]>>4);hist[k]=(hist[k]||0)+1;if(hist[k]>best){best=hist[k];bk=i}}
  var br=D[bk],bg=D[bk+1],bb=D[bk+2],ink=function(x,y){var i=(y*W+x)*4;return Math.abs(D[i]-br)+Math.abs(D[i+1]-bg)+Math.abs(D[i+2]-bb)>70},sat=function(x,y){var i=(y*W+x)*4;return Math.max(D[i],D[i+1],D[i+2])-Math.min(D[i],D[i+1],D[i+2])>45};
  var skipR={},skipC={},span=x1-x0,tall=y1-y0;
  for(var y=y0;y<y1;y++){var n=0;for(var x=x0;x<x1;x++)if(ink(x,y))n++;if(n>span*.45)skipR[y]=1}
  for(var x=x0;x<x1;x++){var n=0;for(var y=y0;y<y1;y++)if(!skipR[y]&&ink(x,y))n++;if(n>tall*.8)skipC[x]=1}
  var nS=0,nI=0;for(var y=y0;y<y1;y+=2)for(var x=x0;x<x1;x+=2)if(!skipR[y]&&!skipC[x]&&ink(x,y)){nI++;if(sat(x,y))nS++}var useSat=nI>0&&nS/nI>.5;
  var ok0=function(x,y){return!skipR[y]&&!skipC[x]&&ink(x,y)&&(!useSat||sat(x,y))},CW=x1-x0,CH=y1-y0,lab=new Int32Array(CW*CH),keep=[0],st=[],id=0,comps=[];
  for(var yy=0;yy<CH;yy++)for(var xx=0;xx<CW;xx++){if(lab[yy*CW+xx]||!ok0(xx+x0,yy+y0))continue;id++;var a1=xx,a2=xx,b1=yy,b2=yy;st.push(yy*CW+xx);lab[yy*CW+xx]=id;
    while(st.length){var q=st.pop(),qx=q%CW,qy=(q-qx)/CW;if(qx<a1)a1=qx;if(qx>a2)a2=qx;if(qy<b1)b1=qy;if(qy>b2)b2=qy;
      for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){var nx=qx+dx,ny=qy+dy;if(nx<0||ny<0||nx>=CW||ny>=CH)continue;var nq=ny*CW+nx;if(!lab[nq]&&ok0(nx+x0,ny+y0)){lab[nq]=id;st.push(nq)}}}
    keep[id]=a2-a1+1<=W*.05&&b2-b1+1<CH*.6&&b2-b1>=2?1:0;keep[id]&&comps.push({i:id,a:a1,z:a2,t:b1,b:b2})}
  comps.forEach(function(c){var n=0;comps.forEach(function(d){if(d!==c&&Math.abs(d.t-c.t)<=3&&Math.abs(d.b-c.b)<=3&&Math.abs(d.a-c.a)<W*.08)n++});if(n>=3)keep[c.i]=0});
  var ok=function(x,y){var v=lab[(y-y0)*CW+(x-x0)];return v>0&&keep[v]===1};
  var live=comps.filter(function(c){return keep[c.i]}).sort(function(p,q){return p.a-q.a}),groups=[];
  live.forEach(function(c){var g=groups[groups.length-1];if(g&&Math.min(g.z,c.z)-Math.max(g.a,c.a)>=0&&Math.max(c.t-g.b,g.t-c.b)<CH*.05){g.a=Math.min(g.a,c.a);g.z=Math.max(g.z,c.z);g.t=Math.min(g.t,c.t);g.b=Math.max(g.b,c.b);g.ids[c.i]=1}else groups.push({a:c.a,z:c.z,t:c.t,b:c.b,ids:(function(){var o={};o[c.i]=1;return o})()})});
  groups=groups.filter(function(g){return g.z<CW-2&&g.a>1});groups.forEach(function(g){g.a+=x0;g.z+=x0;g.t+=y0;g.b+=y0});

  var hs=groups.map(function(g){return g.b-g.t}).sort(function(p,q){return p-q}),mh=hs[hs.length>>1]||1;
  groups=groups.filter(function(g,k){var nb=groups.slice(Math.max(0,k-4),k).concat(groups.slice(k+1,k+5));if(nb.length<3)return!0;var lo=Infinity,hi=-Infinity;nb.forEach(function(d){lo=Math.min(lo,d.t);hi=Math.max(hi,d.b)});var m=(g.t+g.b)/2;return m>lo-mh*3&&m<hi+mh*3});
  ok=(function(o){return function(x,y,g){var v=lab[(y-y0)*CW+(x-x0)];return v>0&&(!g||g.ids[v])&&o(x,y)}})(ok);
  var cs=[],prev=null;groups.forEach(function(g){var w=g.z-g.a+1;if(w>W*.05||g.b-g.t<2)return;var mx=0,rows=[],R=0,G=0,B=0,m=0;
    for(var y=g.t;y<=g.b;y++){var n=0;for(var x=g.a;x<=g.z;x++)if(ok(x,y,g)){n++;var i=(y*W+x)*4;R+=D[i];G+=D[i+1];B+=D[i+2];m++}rows.push(n);if(n>mx)mx=n}
    var bt=-1,bo=-1,lim=Math.max(1,Math.ceil(mx*.6));if(mx<2){bt=g.t;bo=g.b}else rows.forEach(function(n,k){if(n>=lim){if(bt<0)bt=g.t+k;bo=g.t+k}});
    R/=m||1;G/=m||1;B/=m||1;var mid=(bt+bo)/2,dir=Math.max(G,B)>R+15?1:R>Math.max(G,B)+15?-1:prev&&mid>prev.m?-1:1;
    var hiB=H-bt,loB=H-bo,c={h:H-g.t,l:H-g.b,o:dir>0?loB:hiB,c:dir>0?hiB:loB,y:mid,m:mid,x:(g.a+g.z)/2/W};cs.push(c);prev=c});
  return cs}
function __lhPixVotes(cs){if(!cs||cs.length<12)return null;var cl=cs.map(function(b){return b.c}),n=cs.length-1,f=__lhEma(cl,Math.max(5,Math.round(n/4))),sl=__lhEma(cl,Math.max(10,Math.round(n/2))),q=Math.max(3,Math.floor(cs.length/6));
  var a=cs.slice(-2*q,-q),b=cs.slice(-q),mx=function(z,k){return Math.max.apply(null,z.map(function(v){return v[k]}))},mn=function(z,k){return Math.min.apply(null,z.map(function(v){return v[k]}))};
  var hiA=mx(a,"h"),hiB=mx(b,"h"),loA=mn(a,"l"),loB=mn(b,"l"),tol=(mx(cs,"h")-mn(cs,"l"))*.01;
  return{trend:f[n]>sl[n]+tol?"up":f[n]<sl[n]-tol?"down":"range",structure:hiB>hiA+tol&&loB>loA+tol?"up":hiB<hiA-tol&&loB<loA-tol?"down":"range",momentum:cl[n]>=cl[Math.max(0,n-5)]?"up":"down",lastY:cs[n].y}}
var __lhTessP=null;function __lhTess(){return __lhTessP||(__lhTessP=new Promise(function(ok,no){if(window.Tesseract)return ok(window.Tesseract);var sc=document.createElement("script");sc.src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js";sc.onload=function(){ok(window.Tesseract)};sc.onerror=function(){__lhTessP=null;no(new Error("ocr"))};document.head.appendChild(sc)}))}
function __lhNum(t){t=String(t).replace(/[^0-9.,]/g,"");if(/,\d{3}(\.|$)/.test(t))t=t.replace(/,/g,"");else t=t.replace(",",".");var v=parseFloat(t);return v>0?v:0}
function __lhTextRead(txt,words,W,H,lastY,deck){var up=String(txt||"").toUpperCase(),flat=up.replace(/[^A-Z0-9]/g,""),out={pair:"",timeframe:"",price:0,bid:0,ask:0};
  (deck||[]).forEach(function(p){var sy=String(p).toUpperCase().replace(/[^A-Z0-9]/g,"");if(!out.pair&&sy.length>=3&&flat.indexOf(sy)>=0)out.pair=sy});
  if(!out.pair){var m=up.match(/\b(XAU|XAG|EUR|GBP|USD|AUD|NZD|CAD|CHF|BTC|ETH)\s?\/?\s?(USD|EUR|GBP|JPY|CHF|CAD|AUD|NZD|USDT)\b/)||up.match(/\b(US30|US100|NAS100|SPX500|US500|GER40|DE40|UK100|JP225|USTEC|BOOM\s?\d+|CRASH\s?\d+|VOLATILITY\s?\d+)\b/);if(m)out.pair=m[0].replace(/[^A-Z0-9]/g,"")}
  var t=up.match(/\b(M1|M5|M15|M30|H1|H4|D1|W1|MN)\b/);if(t)out.timeframe=t[1];else{var u=up.match(/\b(1|5|15|30)\s?(M|MIN)\b/),h=up.match(/\b(1|4)\s?H\b/);out.timeframe=u?"M"+u[1]:h?"H"+h[1]:/\b(1D|DAILY|1 DAY)\b/.test(up)?"D1":""}
  var bm=up.match(/BID[^0-9]{0,4}([0-9][0-9.,]*)/),am=up.match(/ASK[^0-9]{0,4}([0-9][0-9.,]*)/);if(bm)out.bid=__lhNum(bm[1]);if(am)out.ask=__lhNum(am[1]);
  var ax=(words||[]).filter(function(w){return w.bbox&&w.bbox.x0>W*.8&&/^[0-9][0-9.,]*$/.test(String(w.text).trim())&&String(w.text).length>=3}).map(function(w){return{y:(w.bbox.y0+w.bbox.y1)/2,v:__lhNum(w.text)}}).filter(function(p){return p.v>0});
  if(ax.length>=2&&lastY!=null){var med=ax.map(function(p){return p.v}).sort(function(a,b){return a-b})[ax.length>>1];ax=ax.filter(function(p){return p.v>med*.8&&p.v<med*1.25});
    var n=ax.length,sx=0,sy=0,sxx=0,sxy=0;ax.forEach(function(p){sx+=p.y;sy+=p.v;sxx+=p.y*p.y;sxy+=p.y*p.v});var dd=n*sxx-sx*sx;if(n>=2&&Math.abs(dd)>1e-6){var k=(n*sxy-sx*sy)/dd,b0=(sy-k*sx)/n,pr=k*lastY+b0;if(k<0&&pr>0)out.price=pr}}
  var near=function(v){return v>0&&(!out.price||Math.abs(v-out.price)/out.price<.03)};if(!near(out.bid))out.bid=0;if(!near(out.ask)||out.ask<out.bid)out.ask=0;if(out.bid&&out.ask)out.price=(out.bid+out.ask)/2;else if(out.bid)out.price=out.bid;return out}
function __lhCrop(url,x,y,w,h,k){return new Promise(function(ok,no){var im=new Image();im.onerror=function(){no(new Error("img"))};im.onload=function(){var X=x*im.width,Y=y*im.height,Ww=w*im.width,Hh=h*im.height,c=document.createElement("canvas");c.width=Math.round(Ww*k);c.height=Math.round(Hh*k);var g=c.getContext("2d");g.imageSmoothingQuality="high";g.drawImage(im,X,Y,Ww,Hh,0,0,c.width,c.height);ok({url:c.toDataURL("image/png"),x:X,y:Y,k:k})};im.src=url})}
// Reads the top strip (pair, timeframe, bid, ask) and the right price axis separately, enlarged, so chart lines do not confuse the text reader.
async function __lhOcrChart(url,W,H,lastY,deck){var T=await __lhTess(),top=await __lhCrop(url,0,0,1,.16,2),ax=await __lhCrop(url,.8,0,.2,1,2),a=await T.recognize(top.url,"eng"),b=await T.recognize(ax.url,"eng");
  var words=(b.data.words||[]).map(function(w){return{text:w.text,bbox:{x0:ax.x+w.bbox.x0/ax.k,x1:ax.x+w.bbox.x1/ax.k,y0:ax.y+w.bbox.y0/ax.k,y1:ax.y+w.bbox.y1/ax.k}}});
  return __lhTextRead(a.data.text+"\n"+b.data.text,words,W,H,lastY,deck)}
function __lhImgData(url){return new Promise(function(ok,no){var im=new Image();im.onerror=function(){no(new Error("img"))};im.onload=function(){var c=document.createElement("canvas");c.width=im.width;c.height=im.height;var x=c.getContext("2d");x.drawImage(im,0,0);ok(x.getImageData(0,0,c.width,c.height))};im.src=url})}
// Trend from swing points: zigzag through pivot highs/lows, each labelled HH/LH or HL/LL.
function __lhSwings(cs,k){k=k||3;var pts=[];for(var i=k;i<cs.length-k;i++){var hi=!0,lo=!0;for(var j=i-k;j<=i+k;j++){if(j===i)continue;if(cs[j].h>cs[i].h)hi=!1;if(cs[j].l<cs[i].l)lo=!1}
    if(hi)pts.push({i:i,p:cs[i].h,t:"H"});if(lo)pts.push({i:i,p:cs[i].l,t:"L"})}
  var z=[];pts.forEach(function(q){var l=z[z.length-1];if(l&&l.t===q.t){if(q.t==="H"?q.p>l.p:q.p<l.p)z[z.length-1]=q}else if(!l||l.i!==q.i)z.push(q)});
  var ph=null,pl=null;z.forEach(function(q){if(q.t==="H"){q.lab=ph==null?"H":q.p>ph?"HH":"LH";ph=q.p}else{q.lab=pl==null?"L":q.p>pl?"HL":"LL";pl=q.p}});
  var lh=null,ll=null;for(var m=z.length-1;m>=0;m--){if(!lh&&z[m].t==="H")lh=z[m];if(!ll&&z[m].t==="L")ll=z[m]}
  var tr=lh&&ll&&lh.lab==="HH"&&ll.lab==="HL"?"up":lh&&ll&&lh.lab==="LH"&&ll.lab==="LL"?"down":"range";return{pts:z,trend:tr,lastH:lh,lastL:ll}}
function __lhTrendRead(cs,price){var base=__lhLiveRead(cs,price);if(!base)return null;var sw=__lhSwings(cs.slice(-70),3),why=[];
  var lh=sw.lastH,ll=sw.lastL;why.push("Swings mapped: last high "+(lh?lh.lab:"—")+", last low "+(ll?ll.lab:"—"));
  if(sw.trend==="range"){why.push("Trend from swings: mixed — no clean HH/HL or LH/LL, so the other checks decide");base.reason=why.concat(base.reason);base.confidence=Math.min(base.confidence,55);return base}
  var sig=sw.trend==="up"?"BUY":"SELL",d=sig==="BUY"?1:-1;why.push(sw.trend==="up"?"Trend from swings: UP — higher high and higher low":"Trend from swings: DOWN — lower high and lower low");
  var agree=base.signal===sig;base.signal=sig;base.sl=__lhRound(base.entry*(1-d*.0039),base.dp);base.tp=__lhRound(base.entry*(1+d*.0055),base.dp);base.confidence=agree?Math.min(90,base.confidence+6):58;base.reason=why.concat(base.reason);return base}
function __lhDraw(cv,cs,tone,an){if(!cv)return;var r=cv.getBoundingClientRect(),dpr=window.devicePixelRatio||1,W=Math.max(1,r.width),H=Math.max(1,r.height);cv.width=W*dpr;cv.height=H*dpr;var x=cv.getContext("2d");x.setTransform(dpr,0,0,dpr,0,0);x.clearRect(0,0,W,H);
  if(!cs||!cs.length)return;var st=getComputedStyle(cv),up=(st.getPropertyValue("--blue-bright")||"").trim()||"#38bdf8",dn=(st.getPropertyValue("--red")||"").trim()||"#ef4444",gr="rgba(148,163,184,.12)";
  var show=cs.slice(-70),hi=-Infinity,lo=Infinity;show.forEach(function(b){hi=Math.max(hi,b.h);lo=Math.min(lo,b.l)});var pad=(hi-lo)*.08||hi*.001;hi+=pad;lo-=pad;var py=function(p){return 8+(hi-p)/(hi-lo)*(H-16)},cw=(W-50)/show.length;
  x.strokeStyle=gr;x.lineWidth=1;for(var g=0;g<5;g++){var yy=8+g*(H-16)/4;x.beginPath();x.moveTo(0,yy);x.lineTo(W,yy);x.stroke();x.fillStyle="rgba(148,163,184,.7)";x.font="10px Poppins,sans-serif";x.fillText(__lhRound(hi-g*(hi-lo)/4,__lhDp(hi)).toString(),W-48,yy-2)}
  show.forEach(function(b,i){var c=b.c>=b.o?up:dn,cx=i*cw+cw/2;x.strokeStyle=c;x.beginPath();x.moveTo(cx,py(b.h));x.lineTo(cx,py(b.l));x.stroke();x.fillStyle=c;var t=py(Math.max(b.o,b.c)),h=Math.max(1,py(Math.min(b.o,b.c))-t);x.fillRect(cx-cw*.35,t,cw*.7,h)});
  var last=show[show.length-1].c,ly=py(last);x.setLineDash([4,4]);x.strokeStyle=up;x.beginPath();x.moveTo(0,ly);x.lineTo(W-50,ly);x.stroke();x.setLineDash([]);
  if(!an||!an.sw)return;var zz=an.sw.pts,gold="#facc15",px2=function(q){return{x:q.i*cw+cw/2,y:py(q.p)}},lim=an.phase==="map"?Infinity:an.p*(show.length-1);
  x.lineWidth=2;x.strokeStyle=gold;x.shadowColor=gold;x.shadowBlur=8;x.beginPath();var started=!1;
  for(var z=0;z<zz.length;z++){var A=px2(zz[z]);if(zz[z].i<=lim){started?x.lineTo(A.x,A.y):x.moveTo(A.x,A.y);started=!0}else{if(started&&z>0){var P=zz[z-1],f=(lim-P.i)/(zz[z].i-P.i),B=px2(P);x.lineTo(B.x+(A.x-B.x)*f,B.y+(A.y-B.y)*f)}break}}
  x.stroke();x.shadowBlur=0;x.font="700 10px Poppins,sans-serif";x.textAlign="center";
  zz.forEach(function(q){if(q.i>lim)return;var A=px2(q),good=q.lab==="HH"||q.lab==="HL",bad=q.lab==="LH"||q.lab==="LL",col=good?up:bad?dn:"#e2e8f0",ty=q.t==="H"?A.y-9:A.y+16;
    x.fillStyle=col;x.beginPath();x.arc(A.x,A.y,3,0,7);x.fill();var tw=x.measureText(q.lab).width+8;x.fillStyle="rgba(5,7,12,.85)";x.fillRect(A.x-tw/2,ty-10,tw,13);x.fillStyle=col;x.fillText(q.lab,A.x,ty)});
  x.textAlign="left";
  if(an.phase!=="map"){var sx=Math.min(W-50,an.p*(W-50));x.strokeStyle="rgba(250,204,21,.55)";x.lineWidth=1;x.beginPath();x.moveTo(sx,0);x.lineTo(sx,H);x.stroke();return}
  [an.sw.lastH,an.sw.lastL].forEach(function(q){if(!q)return;var yy=py(q.p);x.setLineDash([6,4]);x.strokeStyle=q.t==="H"?dn:up;x.lineWidth=1;x.beginPath();x.moveTo(q.i*cw,yy);x.lineTo(W-50,yy);x.stroke();x.setLineDash([])});
  var tt=an.sw.trend==="up"?"TREND: UP":an.sw.trend==="down"?"TREND: DOWN":"TREND: RANGE",tc=an.sw.trend==="up"?up:an.sw.trend==="down"?dn:gold;x.font="800 12px Poppins,sans-serif";var w2=x.measureText(tt).width+16;
  x.fillStyle="rgba(5,7,12,.9)";x.fillRect(8,8,w2,22);x.strokeStyle=tc;x.lineWidth=1.5;x.strokeRect(8,8,w2,22);x.fillStyle=tc;x.fillText(tt,16,23)}
// Draws the swing zigzag straight onto the user's own uploaded picture (object-fit: contain), so the original chart stays visible.
function __lhPicOverlay(cv,cs,iw,ih,an){if(!cv)return;var r=cv.getBoundingClientRect(),dpr=window.devicePixelRatio||1,W=Math.max(1,r.width),H=Math.max(1,r.height);cv.width=W*dpr;cv.height=H*dpr;var x=cv.getContext("2d");x.setTransform(dpr,0,0,dpr,0,0);x.clearRect(0,0,W,H);
  if(!cs||!cs.length||!an||!an.sw||!iw||!ih)return;var st=getComputedStyle(cv),up=(st.getPropertyValue("--blue-bright")||"").trim()||"#38bdf8",dn=(st.getPropertyValue("--red")||"").trim()||"#ef4444",gold="#facc15";
  var k=Math.min(W/iw,H/ih),ox=(W-iw*k)/2,oy=(H-ih*k)/2,py=function(p){return oy+(ih-p)*k},cx=function(i){var b=cs[i];return ox+(b&&b.x!=null?b.x*iw:0)*k},px2=function(q){return{x:cx(q.i),y:py(q.p)}};
  var zz=an.sw.pts,lim=an.phase==="map"?Infinity:an.p*(cs.length-1),x0=cx(0),x1=cx(cs.length-1);
  x.lineWidth=2.5;x.strokeStyle=gold;x.shadowColor=gold;x.shadowBlur=10;x.beginPath();var started=!1;
  for(var z=0;z<zz.length;z++){var A=px2(zz[z]);if(zz[z].i<=lim){started?x.lineTo(A.x,A.y):x.moveTo(A.x,A.y);started=!0}else{if(started&&z>0){var P=zz[z-1],f=(lim-P.i)/(zz[z].i-P.i),B=px2(P);x.lineTo(B.x+(A.x-B.x)*f,B.y+(A.y-B.y)*f)}break}}
  x.stroke();x.shadowBlur=0;x.font="700 10px Poppins,sans-serif";x.textAlign="center";
  zz.forEach(function(q){if(q.i>lim)return;var A=px2(q),good=q.lab==="HH"||q.lab==="HL",bad=q.lab==="LH"||q.lab==="LL",col=good?up:bad?dn:"#e2e8f0",ty=q.t==="H"?A.y-9:A.y+16;
    x.fillStyle=col;x.beginPath();x.arc(A.x,A.y,3,0,7);x.fill();var tw=x.measureText(q.lab).width+8;x.fillStyle="rgba(5,7,12,.85)";x.fillRect(A.x-tw/2,ty-10,tw,13);x.fillStyle=col;x.fillText(q.lab,A.x,ty)});
  x.textAlign="left";
  if(an.phase!=="map"){var sx=x0+an.p*(x1-x0);x.strokeStyle="rgba(250,204,21,.7)";x.lineWidth=1.5;x.beginPath();x.moveTo(sx,oy);x.lineTo(sx,oy+ih*k);x.stroke();return}
  [an.sw.lastH,an.sw.lastL].forEach(function(q){if(!q)return;var yy=py(q.p);x.setLineDash([6,4]);x.strokeStyle=q.t==="H"?dn:up;x.lineWidth=1.2;x.beginPath();x.moveTo(cx(q.i),yy);x.lineTo(x1+8,yy);x.stroke();x.setLineDash([])});
  var tt=an.sw.trend==="up"?"TREND: UP":an.sw.trend==="down"?"TREND: DOWN":"TREND: RANGE",tc=an.sw.trend==="up"?up:an.sw.trend==="down"?dn:gold;x.font="800 12px Poppins,sans-serif";var w2=x.measureText(tt).width+16;
  x.fillStyle="rgba(5,7,12,.9)";x.fillRect(ox+8,oy+8,w2,22);x.strokeStyle=tc;x.lineWidth=1.5;x.strokeRect(ox+8,oy+8,w2,22);x.fillStyle=tc;x.fillText(tt,ox+16,oy+23)}
function lw({open:e,onClose:t}){
  let{mainBot:n,pairs:r,mt:i,showToast:a,setScreen:o,pushLog:s,runScanSignal:c}=$();
  let cvRef=(0,_.useRef)(null);
  let[pair,setPair]=(0,_.useState)(""),[tf,setTf]=(0,_.useState)("M5"),[bars,setBars]=(0,_.useState)([]),[px,setPx]=(0,_.useState)(0),
    [busy,setBusy]=(0,_.useState)(!1),[res,setRes]=(0,_.useState)(null),[lot,setLot]=(0,_.useState)("0.01"),[cnt,setCnt]=(0,_.useState)(1),[sending,setSending]=(0,_.useState)(!1),[note,setNote]=(0,_.useState)(""),[pic,setPic]=(0,_.useState)(null),[picBusy,setPicBusy]=(0,_.useState)(!1),[anim,setAnim]=(0,_.useState)(null),fileRef=(0,_.useRef)(null);
  let live=!!(i&&i.status==="connected"&&i.token),plat=i&&i.account&&i.account.platform||"MT5",symOf=p=>i&&i.resolveSymbol&&i.resolveSymbol(p)||p;
  let bot=n&&n.bot||null,deck=(r&&r.length?r:(bot&&bot.pairs||[]).map(p=>typeof p==="string"?{symbol:p}:p)).filter(p=>p&&p.symbol);
  (0,_.useEffect)(()=>{if(e&&!pair&&deck.length)pick(deck[0])},[e,deck.length]);
  (0,_.useEffect)(()=>{if(!e||!live||!pair)return;let stop=!1;
    let load=async()=>{try{let h=await bv({op:"history",id:i.token,symbol:symOf(pair),timeFrame:String(__lhTfMin[tf]),numBars:"120",platform:plat});if(stop)return;let cs=__lhBars(h&&h.bars);setBars(cs);setNote(cs.length?"":"No candles came back for "+pair+" — check the pair name on your broker.")}catch(er){stop||setNote("Could not load the live chart — terminal error, try later.")}};
    let quote=async()=>{try{let q=(await bv({op:"quote",id:i.token,symbol:symOf(pair),platform:plat})).quote,A=Number(q&&q.ask),B=Number(q&&q.bid);!stop&&A>0&&B>0&&setPx((A+B)/2)}catch{}};
    load();quote();let h1=setInterval(load,4e3),h2=setInterval(quote,1500);return()=>{stop=!0;clearInterval(h1);clearInterval(h2)}},[e,live,pair,tf]);
  (0,_.useEffect)(()=>{if(!e)return;let cs=bars.slice();if(cs.length&&px>0){let b=Object.assign({},cs[cs.length-1]);b.c=px;b.h=Math.max(b.h,px);b.l=Math.min(b.l,px);cs[cs.length-1]=b}pic?__lhPicOverlay(cvRef.current,anim?anim.cs:null,pic.iw,pic.ih,anim):anim?__lhDraw(cvRef.current,anim.cs,null,anim.sw?anim:null):__lhDraw(cvRef.current,cs)},[e,bars,px,anim,pic]);
  if(!e)return null;
  function pick(p){setPair(String(p.symbol).toUpperCase());setLot((Number(p.lot)>0?Math.min(100,Number(p.lot)):.01).toFixed(2));setCnt(Number(p.maxTrades)>0?Math.min(20,Math.round(Number(p.maxTrades))):1);setRes(null);setBars([]);setPx(0);setNote("")}
  let upload=async ev=>{let inp=ev.target,fl=inp.files&&inp.files[0];if(!fl)return;setPicBusy(!0);setRes(null);setAnim(null);
    try{let img=await __lhShrink(fl);inp.value="";let id=await __lhImgData(img),v=__lhPixVotes(__lhPix(id));if(!v){a("Could not find candles on that picture — try a clearer chart.");return}
      let tx={pair:"",timeframe:"",price:0,bid:0,ask:0};try{tx=await __lhOcrChart(img,id.width,id.height,v.lastY,deck.map(p=>p.symbol))}catch(er){}
      if(!tx.pair)tx.pair=pair;if(!tx.timeframe)tx.timeframe=tf;if(!tx.price&&live&&px>0&&tx.pair===pair)tx.price=px;
      let j=Object.assign({img:img,cs:__lhCandles(id),iw:id.width,ih:id.height},tx,v);setPic(j);s("SCANNER — CHART PICTURE READ · "+(j.pair||"?")+" · "+(j.timeframe||"?"),"info");if(!j.price)a("Could not read the price on the picture — connect your account for the live price.")}
    catch(er){inp.value="";a("Could not read that picture — try another one.")}finally{setPicBusy(!1)}};
  let scan=()=>{if(busy)return;if(pic){setBusy(!0);setRes(null);s("SCANNER — ANALYSING CHART PICTURE · "+(pic.pair||"?")+" · "+(pic.timeframe||"?"),"info");
      if(pic.cs&&pic.cs.length>=12){let pcs=pic.cs.slice(-70),psw=__lhSwings(pcs,3),q0=Date.now(),C1=0,P1=4e3,P2=2e3;
        let pstep=()=>{let el=Date.now()-q0;          if(el<C1+P1){setAnim({cs:pcs,sw:psw,p:(el-C1)/P1,phase:"draw"});requestAnimationFrame(pstep);return}
          if(el<C1+P1+P2){setAnim({cs:pcs,sw:psw,p:1,phase:"map"});requestAnimationFrame(pstep);return}
          let out=__lhPicRead(pic);setBusy(!1);setAnim({cs:pcs,sw:psw,p:1,phase:"map"});if(!out){a("Could not see the price on that chart — try a clearer picture.");return}setRes(out);s(out.signal+" ["+(pic.pair||"CHART")+"] · "+(pic.timeframe||"")+" · "+out.confidence+"% · TREND "+String(psw.trend).toUpperCase(),"signal")};
        s("Mapping swings: "+psw.pts.map(q=>q.lab).join(" → "),"info");requestAnimationFrame(pstep);return}
      setTimeout(()=>{let out=__lhPicRead(pic);setBusy(!1);if(!out){a("Could not see the price on that chart — try a clearer picture.");return}setRes(out);s(out.signal+" ["+(pic.pair||"CHART")+"] · "+(pic.timeframe||"")+" · "+out.confidence+"%","signal")},1400);return}
    if(!live){a("Connect an account first");o("mt");return}if(!pair){a("Select a pair first");return}if(bars.length<30){a("The live chart is still loading");return}
    setBusy(!0);setRes(null);s("SCANNER — SCANNING LIVE CHART · "+pair+" · "+tf,"info");
    let fz=bars.slice(),pr=px>0?px:fz[fz.length-1].c,sw=__lhSwings(fz.slice(-70),3),t0=Date.now(),D1=4500,D2=2200;
    let step=()=>{let el=Date.now()-t0;if(el<D1){setAnim({cs:fz,sw:sw,p:el/D1,phase:"draw"});requestAnimationFrame(step);return}
      if(el<D1+D2){setAnim({cs:fz,sw:sw,p:1,phase:"map"});requestAnimationFrame(step);return}
      setAnim(null);let out=__lhTrendRead(fz,pr);setBusy(!1);if(!out){a("Not enough candles yet");return}setRes(out);s(out.signal+" ["+pair+"] · "+tf+" · "+out.confidence+"%","signal")};
    s("Mapping swings: "+sw.pts.map(q=>q.lab).join(" → "),"info");requestAnimationFrame(step)};
  let execute=async()=>{if(!res||sending)return;if(!live){a("Connect an account before executing trades.");o("mt");return}
    let tp0=pic?pic.pair:pair;if(!tp0){a("The pair name was not visible on the picture.");return}
    let lt=Math.max(.01,Math.min(100,Number(lot)||.01)),nt=Math.max(1,Math.min(20,Math.round(Number(cnt))||1)),d=res.signal==="BUY"?1:-1,ent=!pic&&px>0?__lhRound(px,res.dp):res.entry,sl=__lhRound(ent*(1-d*.0039),res.dp),tp=__lhRound(ent*(1+d*.0055),res.dp);
    setSending(!0);s("━━━ CHART SCANNER ━━━","info");s("Executing "+res.signal+" "+tp0,"signal");
    try{let x=await c({symbol:tp0,direction:res.signal.toLowerCase(),price:ent,sl:sl,tp:tp},{lot:lt,maxTrades:nt});
      x&&x.executed>0?(s(x.executed+" trade"+(x.executed===1?"":"s")+" placed · "+tp0+" "+res.signal,"ok"),a(res.signal+" "+tp0+" executed")):(s("Trade not placed — "+(x&&x.message||"please retry"),"err"),a("Trade not placed — please retry."))}
    catch(er){s("Execution failed — "+(er&&er.message||"please retry"),"err");a("Execution failed — please retry.")}finally{setSending(!1)}};
  let f=v=>res?Number(v).toFixed(res.dp):"—",buy=res&&res.signal==="BUY",shown=pic?pic.price:px>0?px:bars.length?bars[bars.length-1].c:0,pdp=__lhDp(shown||1),title=pic?(pic.pair||"CHART")+" · "+(pic.timeframe||"—"):pair+" · "+tf;
  return (0,L.jsx)("div",{className:"lsc2",children:(0,L.jsxs)("div",{className:"lsc2-in",children:[
    (0,L.jsx)("button",{type:"button",className:"lsc2-x","aria-label":"Close scanner",onClick:t,children:(0,L.jsx)(Tn,{size:20})}),
    (0,L.jsxs)("div",{className:"lsc2-box lsc2-head",children:[(0,L.jsx)("div",{className:"lsc2-logo",children:(0,L.jsx)("img",{src:ng,alt:"Logical Host"})}),(0,L.jsx)("div",{className:"lsc2-word",children:"SCANNER"})]}),
    (0,L.jsx)("div",{className:"lsc2-pairs",children:deck.length?deck.map(p=>{let sy=String(p.symbol).toUpperCase();return (0,L.jsx)("button",{type:"button",className:"lsc2-chip"+(sy===pair?" on":""),onClick:()=>pick(p),children:sy},sy)}):(0,L.jsx)("div",{className:"lsc2-muted",children:"Your bot has no pairs yet."})}),
    (0,L.jsxs)("div",{className:"lsc2-box lsc2-price",children:[(0,L.jsx)("span",{children:pic?title:pair||"PAIR"}),(0,L.jsx)("b",{children:shown?Number(shown).toFixed(pdp):"—"})]}),
    pic&&(0,L.jsx)("div",{className:"lsc2-grid lsc2-pinfo",children:[["PAIR",pic.pair||"—"],["TIMEFRAME",pic.timeframe||"—"],["BID",pic.bid>0?Number(pic.bid).toFixed(pdp):"—"],["ASK",pic.ask>0?Number(pic.ask).toFixed(pdp):"—"]].map(v=>(0,L.jsxs)("div",{className:"lsc2-cell",children:[(0,L.jsx)("span",{children:v[0]}),(0,L.jsx)("b",{children:v[1]})]},v[0]))}),
    !pic&&(0,L.jsx)("div",{className:"lsc2-tfs",children:__lhTfs.map(k=>(0,L.jsx)("button",{type:"button",className:"lsc2-tf"+(k===tf?" on":""),onClick:()=>{setTf(k);setBars([]);setRes(null)},children:k},k))}),
    (0,L.jsx)("div",{className:"lsc2-box lsc2-chart",children:pic?(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)("img",{className:"lsc2-pic",src:pic.img,alt:"Uploaded chart"}),(0,L.jsx)("canvas",{ref:cvRef,className:"lsc2-cv lsc2-ov"}),busy&&!anim&&(0,L.jsx)("div",{className:"lsc2-sweep"})]}):picBusy?(0,L.jsx)("div",{className:"lsc2-over",children:"Reading your chart picture…"}):live?(0,L.jsxs)(L.Fragment,{children:[(0,L.jsx)("canvas",{ref:cvRef,className:"lsc2-cv"}),busy&&!anim&&(0,L.jsx)("div",{className:"lsc2-sweep"}),!bars.length&&(0,L.jsx)("div",{className:"lsc2-over",children:note||"Loading live chart…"})]}):(0,L.jsxs)("div",{className:"lsc2-over",children:["Connect your MetaTrader account to see the live chart.",(0,L.jsx)("button",{type:"button",className:"lsc2-link",onClick:()=>o("mt"),children:"CONNECT ACCOUNT"})]})}),
    (0,L.jsxs)("div",{className:"lsc2-up",children:[(0,L.jsx)("input",{ref:fileRef,type:"file",accept:"image/*",hidden:!0,onChange:upload}),(0,L.jsx)("button",{type:"button",className:"lsc2-link",disabled:picBusy,onClick:()=>fileRef.current&&fileRef.current.click(),children:picBusy?"READING…":pic?"UPLOAD ANOTHER":"UPLOAD CHART"}),pic&&(0,L.jsx)("button",{type:"button",className:"lsc2-link",onClick:()=>{(setAnim(null),setPic(null));setRes(null)},children:live?"BACK TO LIVE CHART":"REMOVE PICTURE"})]}),
    (0,L.jsx)("button",{type:"button",className:"lsc2-btn",disabled:busy||picBusy,onClick:scan,children:busy?(pic?"ANALYSING…":"SCANNING…"):pic?"ANALYSE":"SCAN"}),
    res&&(0,L.jsxs)(L.Fragment,{children:[
      (0,L.jsxs)("div",{className:"lsc2-box lsc2-res",children:[
        (0,L.jsxs)("div",{className:"lsc2-row",children:[(0,L.jsx)("b",{children:title}),(0,L.jsx)("span",{className:"lsc2-conf",children:res.confidence+"% CONFIDENCE"})]}),
        (0,L.jsx)("div",{className:"lsc2-sig "+(buy?"buy":"sell"),children:res.signal}),
        (0,L.jsxs)("div",{className:"lsc2-grid",children:[["PRICE",shown?Number(shown).toFixed(res.dp):"—"],["ENTRY",f(res.entry)],["TP",f(res.tp)],["SL",f(res.sl)]].map(v=>(0,L.jsxs)("div",{className:"lsc2-cell",children:[(0,L.jsx)("span",{children:v[0]}),(0,L.jsx)("b",{children:v[1]})]},v[0]))})]}),
      (0,L.jsxs)("div",{className:"lsc2-grid2",children:[
        (0,L.jsxs)("label",{className:"lsc2-box lsc2-field",children:[(0,L.jsx)("span",{children:"LOT"}),(0,L.jsx)("input",{inputMode:"decimal",value:lot,onChange:v=>setLot(v.target.value)})]}),
        (0,L.jsxs)("div",{className:"lsc2-box lsc2-field",children:[(0,L.jsx)("span",{children:"TRADES"}),(0,L.jsxs)("div",{className:"lsc2-step",children:[(0,L.jsx)("button",{type:"button",onClick:()=>setCnt(Math.max(1,cnt-1)),children:"−"}),(0,L.jsx)("b",{children:cnt}),(0,L.jsx)("button",{type:"button",onClick:()=>setCnt(Math.min(20,cnt+1)),children:"+"})]})]})]}),
      (0,L.jsx)("button",{type:"button",className:"lsc2-btn exec "+(buy?"buy":"sell"),disabled:sending,onClick:execute,children:sending?"EXECUTING…":"EXECUTE"}),
      (0,L.jsxs)("div",{className:"lsc2-box lsc2-why",children:[(0,L.jsx)("b",{children:"WHAT THE SCANNER SAW"}),res.reason.map((w,k)=>(0,L.jsx)("p",{children:w},k))]})]})
  ]})})}`;

export const scannerStyle = `
.lsc2{position:fixed;inset:0;z-index:60;overflow-y:auto;background:radial-gradient(120% 60% at 50% 0%,color-mix(in oklab,var(--blue-bright,#38bdf8) 16%,transparent),transparent 70%),var(--bg,#05070d);color:var(--text,#e5edf7);font-family:Poppins,sans-serif}
.lsc2-in{max-width:520px;margin:0 auto;padding:calc(env(safe-area-inset-top,0px) + 16px) 16px 40px;display:flex;flex-direction:column;gap:12px;position:relative}
.lsc2-x{position:absolute;top:calc(env(safe-area-inset-top,0px) + 16px);right:16px;z-index:2;width:36px;height:36px;border-radius:50%;display:grid;place-items:center;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.06);color:inherit;cursor:pointer}
.lsc2-box{border-radius:18px;border:1px solid color-mix(in oklab,var(--blue-bright,#38bdf8) 28%,transparent);background:linear-gradient(160deg,rgba(255,255,255,.07),rgba(255,255,255,.02));box-shadow:0 10px 30px -14px color-mix(in oklab,var(--blue-bright,#38bdf8) 45%,transparent);backdrop-filter:blur(10px)}
.lsc2-head{border-radius:28px 28px 60% 60%/28px 28px 22px 22px;padding:22px 16px 26px;display:flex;flex-direction:column;align-items:center;gap:6px}
.lsc2-logo{width:58px;height:58px;display:grid;place-items:center;filter:drop-shadow(0 0 14px var(--blue-bright,#38bdf8))}.lsc2-logo img{width:100%;height:100%;object-fit:contain}
.lsc2-word{font-family:Orbitron,Poppins,sans-serif;font-weight:800;letter-spacing:.32em;font-size:20px;background:linear-gradient(90deg,var(--text,#fff),var(--blue-bright,#38bdf8));-webkit-background-clip:text;background-clip:text;color:transparent}
.lsc2-pairs,.lsc2-tfs{display:flex;gap:8px;overflow-x:auto;padding-bottom:2px;scrollbar-width:none}
.lsc2-chip,.lsc2-tf{flex:0 0 auto;padding:8px 14px;border-radius:999px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.05);color:inherit;font-weight:600;font-size:12px;letter-spacing:.06em;cursor:pointer}
.lsc2-tf{padding:7px 12px;font-size:11px}
.lsc2-chip.on,.lsc2-tf.on{background:var(--blue-bright,#38bdf8);border-color:transparent;color:#04121f;box-shadow:0 0 16px color-mix(in oklab,var(--blue-bright,#38bdf8) 60%,transparent)}
.lsc2-muted{opacity:.6;font-size:13px}
.lsc2-price{display:flex;justify-content:space-between;align-items:center;padding:14px 18px}.lsc2-price span{font-size:12px;letter-spacing:.14em;opacity:.7}.lsc2-price b{font-family:Orbitron,Poppins,sans-serif;font-size:22px;color:var(--blue-bright,#38bdf8)}
.lsc2-chart{position:relative;height:260px;overflow:hidden}.lsc2-pic{width:100%;height:100%;object-fit:contain;display:block;background:rgba(0,0,0,.25)}
.lsc2-ov{position:absolute;inset:0;pointer-events:none;background:transparent}
.lsc2-up{display:flex;gap:8px;justify-content:center;flex-wrap:wrap}.lsc2-link:disabled{opacity:.6}.lsc2-cv{width:100%;height:100%;display:block}
.lsc2-over{position:absolute;inset:0;display:flex;flex-direction:column;gap:12px;align-items:center;justify-content:center;text-align:center;padding:20px;font-size:13px;opacity:.85}
.lsc2-link{padding:9px 16px;border-radius:999px;border:1px solid var(--blue-bright,#38bdf8);background:transparent;color:var(--blue-bright,#38bdf8);font-weight:700;letter-spacing:.08em;font-size:12px;cursor:pointer}
.lsc2-sweep{position:absolute;top:0;bottom:0;width:30%;background:linear-gradient(90deg,transparent,color-mix(in oklab,var(--blue-bright,#38bdf8) 35%,transparent),transparent);animation:lsc2s 1.1s linear infinite}
@keyframes lsc2s{from{left:-30%}to{left:100%}}
.lsc2-btn{height:52px;border-radius:16px;border:0;font-family:Orbitron,Poppins,sans-serif;font-weight:800;letter-spacing:.24em;font-size:15px;color:#04121f;background:linear-gradient(90deg,var(--blue-bright,#38bdf8),color-mix(in oklab,var(--blue-bright,#38bdf8) 60%,#fff));box-shadow:0 10px 26px -10px var(--blue-bright,#38bdf8);cursor:pointer}
.lsc2-btn:disabled{opacity:.6}
.lsc2-btn.exec.buy{background:linear-gradient(90deg,var(--green,#22c55e),#86efac)}.lsc2-btn.exec.sell{background:linear-gradient(90deg,var(--red,#ef4444),#fca5a5)}
.lsc2-res{padding:16px;display:flex;flex-direction:column;gap:12px}
.lsc2-row{display:flex;justify-content:space-between;align-items:center;gap:8px}.lsc2-row b{letter-spacing:.08em}
.lsc2-conf{font-size:11px;font-weight:700;padding:5px 10px;border-radius:999px;background:color-mix(in oklab,var(--blue-bright,#38bdf8) 20%,transparent);color:var(--blue-bright,#38bdf8)}
.lsc2-sig{text-align:center;font-family:Orbitron,Poppins,sans-serif;font-weight:900;font-size:30px;letter-spacing:.3em;padding:8px 0;border-radius:14px}
.lsc2-sig.buy{color:var(--green,#22c55e);background:color-mix(in oklab,var(--green,#22c55e) 12%,transparent)}.lsc2-sig.sell{color:var(--red,#ef4444);background:color-mix(in oklab,var(--red,#ef4444) 12%,transparent)}
.lsc2-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.lsc2-cell{padding:10px 12px;border-radius:12px;background:rgba(255,255,255,.04);display:flex;flex-direction:column;gap:2px}.lsc2-cell span{font-size:10px;letter-spacing:.14em;opacity:.6}.lsc2-cell b{font-size:15px}
.lsc2-grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.lsc2-field{padding:10px 14px;display:flex;flex-direction:column;gap:6px}.lsc2-field span{font-size:10px;letter-spacing:.14em;opacity:.6}
.lsc2-field input{background:transparent;border:0;outline:0;color:inherit;font-size:18px;font-weight:700;width:100%}
.lsc2-step{display:flex;align-items:center;justify-content:space-between}.lsc2-step button{width:30px;height:30px;border-radius:50%;border:1px solid rgba(255,255,255,.2);background:transparent;color:inherit;font-size:18px;cursor:pointer}.lsc2-step b{font-size:18px}
.lsc2-why{padding:14px 16px}.lsc2-why b{font-size:11px;letter-spacing:.16em;color:var(--blue-bright,#38bdf8)}.lsc2-why p{margin:8px 0 0;font-size:13px;opacity:.85;padding-left:12px;border-left:2px solid color-mix(in oklab,var(--blue-bright,#38bdf8) 50%,transparent)}
`;
