/* LOGICAL HOST auto execution (phone side).
   While the bot is ON with MetaTrader connected, this phone hands the server what it needs
   to place the mentor's trades with the app closed: the MetaTrader login, the pairs deck
   (lot, number of trades, allowed) and a notification address. When the app is open, the
   phone and the server race for each signal, so a trade is only ever placed once; if the
   server got there first, the phone just plays the trade sound and logs it. */
(function () {
  "use strict";
  if (window.__lhAuto) return;
  var API = "/api/public/auto/";
  var lastSig = "", armedFor = "", pushSub = null, vapidKey = null, busy = false;

  try { armedFor = localStorage.getItem("lh_auto_armed") || ""; } catch (e) { armedFor = ""; }

  // Every request gives up after 8 s so a slow answer can never hold up the next signal.
  function timed(p) {
    return Promise.race([p, new Promise(function (_, j) { setTimeout(function () { j(new Error("timeout")); }, 8000); })]);
  }
  function post(path, body) {
    return timed(fetch(API + path, { method: "POST", headers: { "Content-Type": "application/json", "X-LH-Device": device() }, body: JSON.stringify(body) })
      .then(function (r) { return r.json(); }));
  }
  // The phone's secret id (made by the app); the server only trades for phones with an active subscription.
  function device() { try { return localStorage.getItem("lh_dev") || ""; } catch (e) { return ""; } }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function client() { return window.__lhClient || null; }
  function licence() {
    var c = client();
    var code = (c && c.mainCode) || "";
    if (!code) { try { code = localStorage.getItem("lh_mainCode") || ""; } catch (e) { code = ""; } }
    return String(code || "");
  }
  function setArmed(code) {
    armedFor = code;
    try { code ? localStorage.setItem("lh_auto_armed", code) : localStorage.removeItem("lh_auto_armed"); } catch (e) { /* ignore */ }
  }

  // ---- notifications ----
  function b64ToBytes(s) {
    var t = s.replace(/-/g, "+").replace(/_/g, "/");
    var bin = atob(t + "===".slice((t.length + 3) % 4));
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function pushSupported() {
    return "serviceWorker" in navigator && "PushManager" in window && "Notification" in window && window.isSecureContext;
  }
  function subscribe() {
    if (!pushSupported() || Notification.permission !== "granted") return Promise.resolve(null);
    return navigator.serviceWorker.register("/lh-push-sw.js").then(function (reg) {
      return navigator.serviceWorker.ready.then(function () { return reg; });
    }).then(function (reg) {
      return reg.pushManager.getSubscription().then(function (sub) {
        if (sub) return sub;
        var key = vapidKey ? Promise.resolve(vapidKey) : fetch(API + "vapid").then(function (r) { return r.json(); }).then(function (j) { vapidKey = j.publicKey; return vapidKey; });
        return key.then(function (k) {
          if (!k) return null;
          return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToBytes(k) });
        });
      });
    }).then(function (sub) {
      pushSub = sub ? sub.toJSON() : null;
      return pushSub;
    }).catch(function () { return null; });
  }
  // Asking for notification permission needs a tap, so ask when the bot switch is tapped.
  document.addEventListener("click", function (e) {
    var t = e.target && e.target.closest && e.target.closest(".lh-client .ha-btn.main");
    if (!t || !pushSupported()) return;
    if (Notification.permission === "default") {
      Notification.requestPermission().then(function () { lastSig = ""; subscribe(); });
    }
  }, true);

  // ---- keep the server in step with the bot switch ----
  function pairsOf(c) {
    return (c.pairs || []).map(function (p) {
      var resolved = "";
      try { resolved = c.mt && c.mt.resolveSymbol ? String(c.mt.resolveSymbol(p.symbol) || "") : ""; } catch (e) { resolved = ""; }
      return {
        symbol: String(p.symbol),
        resolved: resolved || undefined,
        lot: Number(p.lot) > 0 ? Math.min(100, Number(p.lot)) : 0.01,
        maxTrades: Number(p.maxTrades) > 0 ? Math.min(50, Math.round(Number(p.maxTrades))) : 1,
        allowed: !!p.allowed,
      };
    });
  }
  function bridge() { try { return localStorage.getItem("lhMtapiBridgeUrl") || null; } catch (e) { return null; } }

  function tick() {
    if (busy) return;
    var c = client();
    var code = licence();
    if (!c || !code) return;
    var on = c.runState && c.runState !== "idle";
    if (!on) {
      if (armedFor) {
        busy = true;
        post("disarm", { licence: armedFor }).then(function () { setArmed(""); lastSig = ""; })
          .catch(function () { /* retry next tick */ }).then(function () { busy = false; });
      }
      return;
    }
    if (!c.mt || c.mt.status !== "connected" || !c.mainBot) return;
    var creds = window.__lhMtCreds ? window.__lhMtCreds() : null;
    var acct = c.mt.account || {};
    var account = String((creds && creds.accountID) || acct.login || acct.user || acct.accountID || "");
    var server = String((creds && creds.server) || acct.server || "");
    if (!account || !server) return;
    var body = {
      licence: code,
      platform: (acct.platform || (creds && creds.platform)) === "MT4" ? "MT4" : "MT5",
      bridge: bridge(),
      account: account,
      server: server,
      token: c.mt.token ? String(c.mt.token) : null,
      pairs: pairsOf(c),
      push: pushSub,
    };
    var sig = JSON.stringify(body) + "|" + (creds && creds.password ? creds.password.length : 0);
    if (sig === lastSig && armedFor === code) return;
    if (creds && creds.password) body.password = creds.password;
    busy = true;
    post("arm", body).then(function (r) {
      if (r && r.ok) { setArmed(code); lastSig = sig; }
    }).catch(function () { /* retry next tick */ }).then(function () { busy = false; });
  }

  // ---- one execution per signal ----
  function playSounds(n) {
    for (var i = 0; i < n; i++) { try { window.__lhTradeSound && window.__lhTradeSound(); } catch (e) { /* no sound */ } }
  }
  function claim(kind, sig, onLost) {
    var code = licence();
    if (!armedFor || armedFor !== code || !sig) return Promise.resolve(null);
    var ticket = sig.ticket != null && Number(sig.ticket) ? sig.ticket : null;
    var id = sig.id != null && sig.id !== "" ? sig.id : null;
    if (ticket == null && id == null) return Promise.resolve(null);
    var req = post("claim", { licence: code, kind: kind, signal: { id: id, ticket: ticket } });
    // Fast path (scalping): the server already knows this phone is open, so it waits before
    // stepping in - the phone places / closes the trade at once and claims it at the same time.
    // ...but only for a signal that is still young: an old one (phone asleep, page reloaded) may
    // already be handled by the server, so the phone waits for the claim answer instead.
    if (fresh() && young(sig)) {
      req.then(function (r) {
        if (r && r.won === false) try { console.warn("LOGICAL HOST: server also handled", kind, sig.symbol); } catch (e) { /* ignore */ }
      }).catch(function () { /* the phone already acted */ });
      return Promise.resolve(null);
    }
    return req.then(function (r) {
      if (!r || r.won) return null; // this phone places the trade itself
      try { onLost && onLost(); } catch (e) { /* display only */ }
      var started = Date.now();
      function poll(state) {
        if (state && state.status && state.status !== "running") return state;
        if (Date.now() - started > 25000) return state || r;
        return wait(700).then(function () {
          return timed(fetch(API + "status?licence=" + encodeURIComponent(code) + "&key=" + encodeURIComponent(r.key)).then(function (x) { return x.json(); }))
            .catch(function () { return null; }).then(poll);
        });
      }
      return poll(r).then(function (s) {
        // The server could not place it (e.g. broker login failed): this open phone tries itself.
        if (s && s.status === "failed" && !s.executed) return null;
        var done = { won: false, executed: (s && s.executed) || 0, message: (s && s.message) || "" };
        if (kind === "open" && done.executed > 0) playSounds(done.executed);
        return done;
      });
    }).catch(function () { return null; });
  }

  // ---- tell the server this phone is open, so it lets the phone place trades first ----
  // seenAt: when the server last confirmed it knows this phone is open (it then waits
  // 3 s before placing a trade itself, far longer than the phone needs to claim it).
  var seenBusy = false, seenAt = 0, skew = null;
  // Server time (from the "seen" replies), so signal ages do not depend on the phone's clock.
  function serverNow() { return skew == null ? 0 : Date.now() + skew; }
  function young(sig) {
    var n = serverNow(), d = sig && sig.created_date ? String(sig.created_date) : "";
    if (!n || !d) return true;
    var c = new Date(/Z$|[+-]\d\d:?\d\d$/.test(d) ? d : d + "Z").getTime();
    return !isFinite(c) || n - c < 2500;
  }
  function fresh() {
    return document.visibilityState === "visible" && armedFor === licence() && Date.now() - seenAt < 3000;
  }
  function ping() {
    var code = licence();
    if (seenBusy || !armedFor || armedFor !== code || document.visibilityState !== "visible") return;
    seenBusy = true;
    var sent = Date.now();
    post("seen", { licence: code }).then(function (r) {
      if (!r || !r.ok) return;
      seenAt = sent;
      if (typeof r.now === "number") skew = r.now - Math.round((sent + Date.now()) / 2);
    })
      .catch(function () { /* next ping */ }).then(function () { seenBusy = false; });
  }
  document.addEventListener("visibilitychange", function () { if (document.visibilityState !== "visible") seenAt = 0; ping(); });
  setInterval(ping, 1200);

  // ---- instant signals: the server's "new signal" doorbell ----
  // The signal receiver hands over {u: socket address, k: public key, t: bot topic} from its first
  // checked reply; when the server rings that topic (no trade data, just "check now"), the
  // receiver checks for the newest signals at once instead of on its next timed check.
  var live = { ws: null, url: "", key: "", topics: {}, ref: 0, hb: 0, retry: 0, timer: 0 };
  function liveSend(m) { try { if (live.ws && live.ws.readyState === 1) live.ws.send(JSON.stringify(m)); } catch (e) { /* reconnects */ } }
  function liveJoin(t) {
    live.ref++;
    liveSend({ topic: "realtime:" + t, event: "phx_join", payload: { config: { broadcast: { self: false }, presence: { key: "" }, private: false } }, ref: String(live.ref), join_ref: String(live.ref) });
  }
  function liveRing(t) {
    (live.topics[t] || []).slice().forEach(function (cb) { try { cb(); } catch (e) { /* receiver */ } });
  }
  function liveOpen() {
    if (live.ws || !live.url || !Object.keys(live.topics).length || typeof WebSocket === "undefined") return;
    var ws;
    try { ws = new WebSocket(live.url + "?apikey=" + encodeURIComponent(live.key) + "&vsn=1.0.0"); } catch (e) { return; }
    live.ws = ws;
    ws.onopen = function () {
      live.retry = 0;
      Object.keys(live.topics).forEach(function (t) { liveJoin(t); liveRing(t); }); // catch up after a reconnect
      clearInterval(live.hb);
      live.hb = setInterval(function () { live.ref++; liveSend({ topic: "phoenix", event: "heartbeat", payload: {}, ref: String(live.ref) }); }, 25000);
    };
    ws.onmessage = function (m) {
      var j; try { j = JSON.parse(m.data); } catch (e) { return; }
      if (!j || j.event !== "broadcast") return;
      liveRing(String(j.topic || "").replace(/^realtime:/, ""));
    };
    ws.onclose = ws.onerror = function () {
      if (live.ws !== ws) return;
      live.ws = null; clearInterval(live.hb); clearTimeout(live.timer);
      try { ws.close(); } catch (e) { /* closed */ }
      live.retry = Math.min(live.retry + 1, 8);
      live.timer = setTimeout(liveOpen, 800 * live.retry);
    };
  }
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && !live.ws) { clearTimeout(live.timer); live.retry = 0; liveOpen(); }
  });
  window.__lhLive = function (info, cb) {
    if (!info || typeof cb !== "function") return null;
    var u = String(info.u || ""), k = String(info.k || ""), t = String(info.t || "");
    if (!/^wss:\/\/[^\s"']+$/.test(u) || !/^lhs-[0-9a-f]{8,64}$/.test(t) || !k) return null;
    if (live.url && live.url !== u && live.ws) { var old = live.ws; live.ws = null; try { old.close(); } catch (e) { /* closed */ } }
    live.url = u; live.key = k;
    var isNew = !live.topics[t];
    (live.topics[t] = live.topics[t] || []).push(cb);
    if (live.ws) { if (isNew) liveJoin(t); } else liveOpen();
    return function () {
      var list = live.topics[t] || [], i = list.indexOf(cb);
      if (i >= 0) list.splice(i, 1);
      if (list.length) return;
      delete live.topics[t];
      live.ref++;
      liveSend({ topic: "realtime:" + t, event: "phx_leave", payload: {}, ref: String(live.ref) });
      if (!Object.keys(live.topics).length && live.ws) { var w = live.ws; live.ws = null; clearInterval(live.hb); try { w.close(); } catch (e) { /* closed */ } }
    };
  };

  window.__lhAuto = { claim: claim, serverNow: serverNow };
  subscribe();
  setInterval(tick, 3000);
  setTimeout(tick, 1500);
})();
