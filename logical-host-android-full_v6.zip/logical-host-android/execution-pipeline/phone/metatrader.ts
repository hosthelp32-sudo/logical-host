import { brokerDirectory } from "./brokers";
import { applyMtConnect } from "./mt-connect";
import { applyMtRelay } from "./mt-relay";

// Trading app MetaTrader screen (the export's `oC`), redesigned: a login card with the MT5 / MT4
// switch, a connecting radar, and once connected an account card whose equity counts up and down
// live with a moving equity line (balance, floating profit, free margin, margin level, leverage).
// Names from the export: $ = trading-app state (mt = MetaTrader connection), L = JSX runtime,
// _ = React, aC = the side-menu button. Spliced into the export, so no backtick and no "${".
export const metatraderComponent = String.raw`var __lhmHist=[];try{__lhmHist=JSON.parse(sessionStorage.getItem("lh_eq_hist")||"[]")}catch(e){__lhmHist=[]}
function __lhmPick(o,names){if(!o)return void 0;var ks=Object.keys(o);for(var i=0;i<names.length;i++)for(var k=0;k<ks.length;k++)if(ks[k].toLowerCase()===names[i]){var v=o[ks[k]];return v}return void 0}
function __lhmNum(v){var n=Number(v);return isFinite(n)?n:null}
function __lhmFmt(v,cur){if(v==null)return"—";return(cur?cur+" ":"")+Number(v).toLocaleString(void 0,{minimumFractionDigits:2,maximumFractionDigits:2})}
function __lhmTween(target){var st=(0,_.useState)(target),val=st[0],setVal=st[1],from=(0,_.useRef)(target);
  (0,_.useEffect)(function(){if(target==null){setVal(null);return}var a=from.current==null?target:from.current,t0=performance.now(),raf=0,dur=900;
    var step=function(t){var k=Math.min(1,(t-t0)/dur),e=1-Math.pow(1-k,3),v=a+(target-a)*e;setVal(v);from.current=v;if(k<1)raf=requestAnimationFrame(step)};raf=requestAnimationFrame(step);return function(){cancelAnimationFrame(raf)}},[target]);
  return val}
function __lhmLine(pts,w,h){if(pts.length<2)return null;var lo=Math.min.apply(null,pts),hi=Math.max.apply(null,pts),pad=(hi-lo)*.18||Math.abs(hi)*.0004||1;lo-=pad;hi+=pad;
  var xy=pts.map(function(v,i){return[6+i/(pts.length-1)*(w-18),6+(h-12)-(v-lo)/(hi-lo)*(h-12)]}),d="M"+xy.map(function(p){return p[0].toFixed(1)+" "+p[1].toFixed(1)}).join(" L");
  return{d:d,area:d+" L"+w+" "+h+" L0 "+h+" Z",end:xy[xy.length-1]}}
var __lhmCache={};
function __lhmBase(plat){try{if(typeof iv==="function")return iv(plat)}catch(x){}return plat==="MT4"?"https://mt4.mtapi.io":"https://mt5.mtapi.io"}
function __lhmFind(name){var v=String(name||""),list=typeof __lhmBrokers!=="undefined"?__lhmBrokers:[];for(var i=0;i<list.length;i++){try{if(new RegExp(list[i].m,"i").test(v))return list[i]}catch(x){}}return null}
function __lhmSearch(plat,q){var k=plat+"|"+String(q).toLowerCase();if(__lhmCache[k])return __lhmCache[k];
  var one=function(w){return fetch(__lhmBase(plat)+"/Search?company="+encodeURIComponent(w)).then(function(r){return r.json()}).then(function(d){return Array.isArray(d)?d:[]})},
    t=String(q).trim(),ws=t.split(/\s+/).filter(function(w){return w.length>=3}).sort(function(a,b){return b.length-a.length}),
    vs=[t,t.replace(/\s+/g,"")].concat(ws).filter(function(v,i,a){return v&&a.indexOf(v)===i}),
    pr=vs.reduce(function(p,v){return p.then(function(d){return d.length?d:one(v).catch(function(){return[]})})},Promise.resolve([]));
  __lhmCache[k]=pr;pr.catch(function(){delete __lhmCache[k]});return pr}
function __lhmSort(a){return a.slice().sort(function(x,y){var dx=/demo|trial|contest/i.test(x),dy=/demo|trial|contest/i.test(y);if(dx!==dy)return dx?1:-1;return x.localeCompare(y,void 0,{numeric:!0,sensitivity:"base"})})}
function __lhmGroups(d,plat){var out=[],by={};(d||[]).forEach(function(c){var sv=(c.results||[]).map(function(r){return r.name}).filter(Boolean);if(!sv.length)return;
    var b=__lhmFind(c.companyName)||__lhmFind(sv[0]),id=b?b.id:"c:"+c.companyName;
    if(!by[id]){by[id]=b?Object.assign({},b,{servers:[]}):{id:id,name:c.companyName,servers:[],co:[],pl:plat};out.push(by[id])}
    by[id].co&&by[id].co.push(c.companyName);sv.forEach(function(n){by[id].servers.indexOf(n)<0&&by[id].servers.push(n)})});
  return out}
function __lhmServersOf(plat,g){if(g.q)return __lhmSearch(plat,g.q).then(function(d){var re=new RegExp(g.m,"i"),sv=[];(d||[]).forEach(function(c){var ns=(c.results||[]).map(function(r){return r.name});
      if(re.test(c.companyName)||ns.some(function(n){return re.test(n)}))ns.forEach(function(n){n&&sv.indexOf(n)<0&&sv.push(n)})});return __lhmSort(sv)});
  if(g.pl===plat&&g.servers)return Promise.resolve(__lhmSort(g.servers));
  return __lhmSearch(plat,(g.co&&g.co[0])||g.name).then(function(d){var sv=[];(d||[]).forEach(function(c){(g.co||[g.name]).indexOf(c.companyName)>=0&&(c.results||[]).forEach(function(r){r.name&&sv.indexOf(r.name)<0&&sv.push(r.name)})});return __lhmSort(sv)})}
function __lhmLogo(b,cls){var H=_.createElement,n=String(b&&b.name||"?");
  if(b&&b.logo)return H("span",{className:"lhm-lg"+(cls?" "+cls:"")},H("img",{src:b.logo,alt:"",loading:"lazy"}));
  var h=0;for(var i=0;i<n.length;i++)h=(h*31+n.charCodeAt(i))%360;
  return H("span",{className:"lhm-lg mono"+(cls?" "+cls:""),style:{background:"hsl("+h+" 65% 42%)"}},n.replace(/[^A-Za-z0-9]/g,"").slice(0,2).toUpperCase())}
function __lhmLast(){try{var v=JSON.parse(localStorage.getItem("lh_mt_pick")||"null");return v&&typeof v==="object"?v:null}catch(x){return null}}
function __lhmI(n){var P={search:["M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z","M21 21l-4.3-4.3"],chev:["M9 18l6-6-6-6"],x:["M18 6 6 18","M6 6l12 12"],back:["M15 18l-6-6 6-6"]}[n]||[];
  return _.createElement("svg",{width:16,height:16,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2.4,strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true"},P.map(function(d,i){return _.createElement("path",{key:i,d:d})}))}
function __lhmBroker(srv){var v=String(srv||""),b=__lhmFind(v);
  if(/just\s*markets|justmarkets/i.test(v))return{id:"jm",name:"JustMarkets",logo:"/brokers/justmarkets.svg",mark:"/brokers/justmarkets-mark.svg",icon:b&&b.logo};
  if(b)return{id:b.id,name:b.name,icon:b.logo};
  var n=v.split(/[-_ .]/)[0]||"";return n?{id:"other",name:n}:null}
function __lhmAgo(l){return l&&l.ts?l.ts.slice(0,5):""}
function oC(){var s=$(),e=s.mt,
    l0=(0,_.useState)(__lhmLast)[0]||{},
    p1=(0,_.useState)(l0.plat==="MT4"?"MT4":"MT5"),plat=p1[0],setPlat=p1[1],a1=(0,_.useState)(l0.acc||""),acc=a1[0],setAcc=a1[1],w1=(0,_.useState)(""),pw=w1[0],setPw=w1[1],
    v1=(0,_.useState)(l0.srv||""),srv=v1[0],setSrv=v1[1],
    s2=(0,_.useState)(l0.srv?"login":"broker"),step=s2[0],setStep=s2[1],k2=(0,_.useState)(l0.b||null),pk=k2[0],setPk=k2[1],
    q2=(0,_.useState)(""),bq=q2[0],setBq=q2[1],q3=(0,_.useState)(""),sq=q3[0],setSq=q3[1],
    m2=(0,_.useState)({q:"",list:[],loading:!1,err:""}),rem=m2[0],setRem=m2[1],n2=(0,_.useState)({k:"",list:[],loading:!1,err:""}),sl=n2[0],setSl=n2[1],
    o2=(0,_.useState)(!1),man=o2[0],setMan=o2[1],o3=(0,_.useState)(""),mtxt=o3[0],setMtxt=o3[1],r1=(0,_.useState)(""),err=r1[0],setErr=r1[1],h1=(0,_.useState)(!1),showPw=h1[0],setShowPw=h1[1],
    t1=(0,_.useState)(0),setTick=t1[1],
    on=e.status==="connected",wait=e.status==="loading"||e.status==="reconnecting",
    sm=e.summary||null,cur=__lhmPick(sm,["currency"])||"",
    eq=__lhmNum(__lhmPick(sm,["equity"])),bal=__lhmNum(__lhmPick(sm,["balance"])),pr=__lhmNum(__lhmPick(sm,["profit"])),
    fm=__lhmNum(__lhmPick(sm,["freemargin","margin_free"])),mg=__lhmNum(__lhmPick(sm,["margin"])),lev=__lhmNum(__lhmPick(sm,["leverage"])),
    ml=mg&&eq!=null&&mg>0?eq/mg*100:__lhmNum(__lhmPick(sm,["marginlevel","margin_level"])),
    live=eq!=null?eq:bal,shown=__lhmTween(live),acct=e.account||{},key=String(acct.accountID||"")+"|"+String(acct.server||""),
    brk=__lhmBroker(acct.server),acts=(s.logs||[]).slice(0,6);
  (0,_.useEffect)(function(){if(!on||live==null)return;var last=__lhmHist[__lhmHist.length-1];if(!last||last.k!==key)__lhmHist=__lhmHist.filter(function(x){return x.k===key});
    __lhmHist.push({k:key,v:live,t:Date.now()});if(__lhmHist.length>90)__lhmHist=__lhmHist.slice(-90);try{sessionStorage.setItem("lh_eq_hist",JSON.stringify(__lhmHist))}catch(x){}setTick(function(n){return n+1})},[on,live,key]);
  (0,_.useEffect)(function(){if(!on)return;var id=setInterval(function(){if(live!=null){__lhmHist.push({k:key,v:live,t:Date.now()});if(__lhmHist.length>90)__lhmHist=__lhmHist.slice(-90);setTick(function(n){return n+1})}},4e3);return function(){clearInterval(id)}},[on,live,key]);
  (0,_.useEffect)(function(){if(on||wait)return;var q=bq.trim();if(q.length<3){setRem({q:"",list:[],loading:!1,err:""});return}
    var off=!1;setRem(function(r){return{q:r.q,list:r.list,loading:!0,err:""}});
    var id=setTimeout(function(){__lhmSearch(plat,q).then(function(d){off||setRem({q:q,list:__lhmGroups(d,plat),loading:!1,err:""})}).catch(function(){off||setRem({q:q,list:[],loading:!1,err:"Broker search is not reachable — check your internet."})})},380);
    return function(){off=!0;clearTimeout(id)}},[bq,plat,on,wait]);
  (0,_.useEffect)(function(){if(on||wait||!pk||step==="broker")return;var k=plat+"|"+(pk.id||pk.name);if(sl.k===k&&(sl.list.length||sl.loading))return;
    var off=!1;setSl({k:k,list:[],loading:!0,err:""});
    __lhmServersOf(plat,pk).then(function(list){off||setSl({k:k,list:list,loading:!1,err:""})}).catch(function(){off||setSl({k:k,list:[],loading:!1,err:"Could not load the servers — check your internet and try again."})});
    return function(){off=!0}},[pk&&(pk.id||pk.name),plat,step,on,wait]);
  var tickM=function(){try{navigator.vibrate&&navigator.vibrate(6)}catch(x){}},
    pickB=function(g){tickM();setPk(g);setSrv("");setSq("");setMan(!1);setStep("server")},
    pickS=function(n){tickM();setSrv(n);setErr("");setStep("login")},
    goStep=function(t){tickM();if(t==="server"&&!pk)return;if(t==="login"&&!srv)return;setStep(t)},
    switchPlat=function(t){if(t===plat)return;tickM();setPlat(t);setSrv("");setSq("");setStep(pk?"server":"broker")};
  var connect=async function(){setErr("");if(!srv.trim())return setErr("Choose your broker's server");if(!acc.trim())return setErr("Enter your account ID");if(!pw.trim())return setErr("Enter your account password");
    var __pl=pw.trim().toLowerCase();if(__pl===srv.trim().toLowerCase()||__pl===acc.trim().toLowerCase()){setPw("");setShowPw(!0);return setErr("The password box had your server name or account number in it (your phone may have filled it in). Type your MetaTrader trading password and tap Connect again.")}
    try{var keep=pk?{id:pk.id,name:pk.name,logo:pk.logo,q:pk.q,m:pk.m,co:pk.co,pl:pk.pl,servers:pk.q?void 0:pk.servers}:null;localStorage.setItem("lh_mt_pick",JSON.stringify({plat:plat,b:keep,srv:srv.trim(),acc:acc.trim()}))}catch(x){}
    try{await e.connect(acc.trim(),pw.trim(),srv.trim(),plat)}catch(x){}};
  var pts=__lhmHist.filter(function(x){return x.k===key}).map(function(x){return x.v}),line=__lhmLine(pts.length>1?pts:live!=null?[live,live]:[],320,96),
    first=pts.length?pts[0]:live,chg=live!=null&&first!=null?live-first:0,up=chg>=0;
  var stat=function(label,val,cls){return(0,L.jsxs)("div",{className:"lhm-stat"+(cls?" "+cls:""),children:[(0,L.jsx)("span",{children:label}),(0,L.jsx)("b",{children:val})]},label)};
  return(0,L.jsxs)("div",{className:"lhm"+(on?" is-on":wait?" is-wait":""),children:[
    (0,L.jsx)("span",{className:"lhm-bg","aria-hidden":"true"}),
    (0,L.jsxs)("div",{className:"lhm-head",children:[(0,L.jsx)("span",{className:"lhm-menu",children:(0,L.jsx)(aC,{})}),
      (0,L.jsxs)("div",{className:"lhm-ht",children:[(0,L.jsx)("small",{children:"TRADING TERMINAL"}),(0,L.jsxs)("h1",{children:["META",(0,L.jsx)("em",{children:"TRADER"})]})]}),
      (0,L.jsxs)("span",{className:"lhm-state",children:[(0,L.jsx)("i",{}),on?"LIVE":wait?"LINKING":"OFFLINE"]})]}),
    on?(0,L.jsxs)("div",{className:"lhm-body",children:[
      (0,L.jsxs)("div",{className:"lhm-card",children:[
        (0,L.jsx)("span",{className:"lhm-shine","aria-hidden":"true"}),
        (0,L.jsxs)("div",{className:"lhm-card-top",children:[
          (0,L.jsx)("span",{className:"lhm-plat",children:acct.platform||plat}),
          (0,L.jsxs)("div",{className:"lhm-acc",children:[(0,L.jsx)("b",{children:acct.accountID||"—"}),(0,L.jsx)("span",{children:acct.server||""})]}),
          (0,L.jsxs)("span",{className:"lhm-live",children:[(0,L.jsx)("i",{}),"CONNECTED"]})]}),
        brk?(0,L.jsxs)("div",{className:"lhm-broker"+(brk.logo?" has-logo":""),children:[
          brk.logo?(0,L.jsx)("span",{className:"lhm-broker-logo",children:(0,L.jsx)("img",{src:brk.logo,alt:brk.name})}):__lhmLogo({name:brk.name,logo:brk.icon},"md"),
          (0,L.jsxs)("span",{className:"lhm-broker-s",children:[(0,L.jsx)("small",{children:"BROKER · LINKED"}),(0,L.jsx)("b",{children:brk.name})]})]}):null,
        (0,L.jsx)("div",{className:"lhm-eq-l",children:"EQUITY"}),
        (0,L.jsx)("div",{className:"lhm-eq",children:__lhmFmt(shown,cur)}),
        (0,L.jsxs)("div",{className:"lhm-chg "+(up?"up":"down"),children:[up?"▲ ":"▼ ",__lhmFmt(Math.abs(chg),cur)," this session"]}),
        (0,L.jsxs)("div",{className:"lhm-chart",children:[line?(0,L.jsxs)("svg",{viewBox:"0 0 320 96",preserveAspectRatio:"none",children:[
            (0,L.jsx)("defs",{children:(0,L.jsxs)("linearGradient",{id:"lhm-fill",x1:"0",y1:"0",x2:"0",y2:"1",children:[(0,L.jsx)("stop",{offset:"0",stopColor:"currentColor",stopOpacity:".35"}),(0,L.jsx)("stop",{offset:"1",stopColor:"currentColor",stopOpacity:"0"})]})}),
            (0,L.jsx)("path",{d:line.area,fill:"url(#lhm-fill)",className:"lhm-area"}),
            (0,L.jsx)("path",{d:line.d,fill:"none",stroke:"currentColor",strokeWidth:"2.4",strokeLinejoin:"round",strokeLinecap:"round",className:"lhm-path"}),
            (0,L.jsx)("circle",{cx:line.end[0],cy:line.end[1],r:"4.5",fill:"currentColor",className:"lhm-end"})]}):null,
          (0,L.jsx)("span",{className:"lhm-scan","aria-hidden":"true"})]})]}),
      (0,L.jsxs)("div",{className:"lhm-grid",children:[
        stat("BALANCE",__lhmFmt(bal,cur)),
        stat("FLOATING P/L",pr==null?"—":(pr>0?"+":"")+__lhmFmt(pr,cur),pr==null?"":pr>=0?"pos":"neg"),
        stat("FREE MARGIN",__lhmFmt(fm,cur)),
        stat("MARGIN LEVEL",ml==null?"—":Math.round(ml).toLocaleString()+"%"),
        stat("LEVERAGE",lev?"1:"+lev:"—"),
        stat("PLATFORM",(acct.platform||plat)+" · ALWAYS ON")]}),
      (0,L.jsxs)("div",{className:"lhm-act",children:[
        (0,L.jsxs)("div",{className:"lhm-act-h",children:[(0,L.jsx)("span",{children:"ACCOUNT ACTIVITY"}),(0,L.jsxs)("em",{children:[(0,L.jsx)("i",{}),s.runState&&s.runState!=="idle"?"BOT "+String(s.runState).toUpperCase():"BOT IDLE"]})]}),
        acts.length?acts.map(function(l,k){return(0,L.jsxs)("div",{className:"lhm-act-r"+(l.kind==="exec"?" ok":l.kind==="err"||l.kind==="warn"?" bad":l.kind==="signal"?" sig":""),children:[(0,L.jsx)("span",{className:"lhm-act-d"}),(0,L.jsx)("span",{className:"lhm-act-t",children:l.text}),(0,L.jsx)("time",{children:__lhmAgo(l)})]},l.id||k)})
          :(0,L.jsx)("div",{className:"lhm-act-e",children:"No activity yet — signals and trades on this account show here."})]}),
      (0,L.jsx)("button",{className:"lhm-disc",onClick:e.disconnect,children:"DISCONNECT ACCOUNT"})]})
    :wait?(0,L.jsxs)("div",{className:"lhm-body lhm-wait",children:[
      (0,L.jsxs)("div",{className:"lhm-radar",children:[(0,L.jsx)("i",{}),(0,L.jsx)("i",{}),(0,L.jsx)("i",{}),(0,L.jsx)("b",{children:"MT"})]}),
      (0,L.jsx)("div",{className:"lhm-wait-t",children:e.statusMsg||"Checking your account…"}),
      (0,L.jsx)("div",{className:"lhm-wait-s",children:"Linking to your broker — this takes a few seconds"}),
      e.statusMsg&&e.statusMsg.includes("Still connecting")?(0,L.jsx)("button",{className:"lhm-link",onClick:e.disconnect,children:"Wrong details? Tap to enter them again"}):null]})
    :(function(){var H=_.createElement,ql=bq.trim().toLowerCase(),all=typeof __lhmBrokers!=="undefined"?__lhmBrokers:[],
        local=ql?all.filter(function(b){return b.name.toLowerCase().indexOf(ql)>=0||b.q.toLowerCase().indexOf(ql)>=0||b.id.indexOf(ql.replace(/[^a-z0-9]/g,""))>=0}):[],
        ids=local.map(function(b){return b.id}),more=ql&&rem.q.toLowerCase()===ql?rem.list.filter(function(g){return ids.indexOf(g.id)<0}):[],
        sqq=sq.trim().toLowerCase(),slist=sl.list.filter(function(n){return!sqq||n.toLowerCase().indexOf(sqq)>=0}),
        row=function(g,k){return H("button",{type:"button",key:g.id+"|"+k,className:"lhm-row",onClick:function(){pickB(g)},style:{animationDelay:Math.min(k,10)*30+"ms"}},__lhmLogo(g),
          H("span",{className:"lhm-row-t"},H("b",null,g.name),H("small",null,g.q?"Tap to see every server":g.servers.length+(g.servers.length===1?" server":" servers")+(g.co&&g.co.length?" · "+g.co[0]:""))),H("span",{className:"lhm-chev"},__lhmI("chev")))},
        steps=[["broker","BROKER"],["server","SERVER"],["login","LOGIN"]],si=steps.map(function(x){return x[0]}).indexOf(step);
      return H("div",{className:"lhm-body"},
        H("div",{className:"lhm-hero"},H("div",{className:"lhm-orb"},H("i"),H("i"),H("b",null,plat)),
          H("p",null,"Link your MetaTrader account so the bot can trade for you. Choose your broker, pick its server, then log in.")),
        H("div",{className:"lhm-seg",role:"tablist"},H("span",{className:"lhm-seg-k "+(plat==="MT4"?"r":"")}),
          H("button",{className:plat==="MT5"?"on":"",onClick:function(){switchPlat("MT5")},role:"tab","aria-selected":plat==="MT5"},"MT5"),
          H("button",{className:plat==="MT4"?"on":"",onClick:function(){switchPlat("MT4")},role:"tab","aria-selected":plat==="MT4"},"MT4")),
        H("div",{className:"lhm-steps"},steps.map(function(x,k){return H("button",{type:"button",key:x[0],className:"lhm-stp"+(k===si?" on":k<si?" done":""),onClick:function(){goStep(x[0])}},H("i",null,k+1),x[1])})),
        step==="broker"?H("div",{className:"lhm-pick",key:"b"},
          H("label",{className:"lhm-search"},__lhmI("search"),H("input",{value:bq,onChange:function(x){setBq(x.target.value)},placeholder:"Search your broker",autoComplete:"off","aria-label":"Search your broker"}),
            bq?H("button",{type:"button",onClick:function(){setBq("")},"aria-label":"Clear"},__lhmI("x")):null),
          ql?H("div",{className:"lhm-list"},local.map(row),more.map(function(g,k){return row(g,k+local.length)}),
              rem.loading?H("div",{className:"lhm-note"},H("span",{className:"lhm-spin"}),"Searching every "+plat+" broker…"):null,
              rem.err?H("div",{className:"lhm-note bad"},rem.err):null,
              ql.length<3&&!local.length?H("div",{className:"lhm-note"},"Type at least 3 letters to search every broker."):null,
              !rem.loading&&!rem.err&&ql.length>=3&&rem.q.toLowerCase()===ql&&!local.length&&!more.length?H("div",{className:"lhm-note"},"No "+plat+" broker called “"+bq.trim()+"”. Check the spelling or switch to "+(plat==="MT5"?"MT4":"MT5")+"."):null)
            :H(_.Fragment,null,
              H("div",{className:"lhm-cap"},H("span",null,"POPULAR BROKERS"),H("em",null,all.length+" WITH LOGOS")),
              H("div",{className:"lhm-grid-b"},all.map(function(b,k){return H("button",{type:"button",key:b.id,className:"lhm-tile",onClick:function(){pickB(b)},style:{animationDelay:Math.min(k,18)*22+"ms"}},__lhmLogo(b,"lg"),H("span",null,b.name))})),
              H("div",{className:"lhm-note"},"Every MetaTrader 4 and 5 broker can connect — search by name if yours isn't here."))):null,
        step==="server"&&pk?H("div",{className:"lhm-pick",key:"s"},
          H("div",{className:"lhm-chosen"},__lhmLogo(pk,"md"),H("span",{className:"lhm-row-t"},H("small",null,"YOUR BROKER"),H("b",null,pk.name)),
            H("button",{type:"button",className:"lhm-chg-b",onClick:function(){goStep("broker")}},"CHANGE")),
          H("label",{className:"lhm-search"},__lhmI("search"),H("input",{value:sq,onChange:function(x){setSq(x.target.value)},placeholder:"Search server",autoComplete:"off","aria-label":"Search server"}),
            sq?H("button",{type:"button",onClick:function(){setSq("")},"aria-label":"Clear"},__lhmI("x")):null),
          sl.loading?H("div",{className:"lhm-note"},H("span",{className:"lhm-spin"}),"Loading "+pk.name+" servers…"):null,
          sl.err?H("div",{className:"lhm-note bad"},sl.err):null,
          !sl.loading&&!sl.err?H("div",{className:"lhm-cap"},H("span",null,"SERVERS"),H("em",null,sl.list.length+" ON "+plat)):null,
          !sl.loading&&!sl.err&&!sl.list.length?H("div",{className:"lhm-note"},pk.name+" has no "+plat+" servers. Switch to "+(plat==="MT5"?"MT4":"MT5")+" or type your server below."):null,
          slist.length?H("div",{className:"lhm-list"},slist.slice(0,300).map(function(n,k){var demo=/demo|trial|contest/i.test(n);
            return H("button",{type:"button",key:n,className:"lhm-row srv"+(n===srv?" on":""),onClick:function(){pickS(n)},style:{animationDelay:Math.min(k,12)*25+"ms"}},__lhmLogo(pk,"sm"),
              H("span",{className:"lhm-row-t"},H("b",null,n)),H("span",{className:"lhm-tag"+(demo?" demo":"")},demo?"DEMO":"LIVE"))})):null,
          !sl.loading&&sqq&&sl.list.length&&!slist.length?H("div",{className:"lhm-note"},"No server matches “"+sq.trim()+"”."):null,
          man?H("div",{className:"lhm-man"},H("input",{value:mtxt,onChange:function(x){setMtxt(x.target.value)},placeholder:"Exact server, e.g. JustMarkets-Demo",autoComplete:"off"}),
              H("button",{type:"button",className:"lhm-chg-b",onClick:function(){mtxt.trim()&&pickS(mtxt.trim())}},"USE"))
            :H("button",{type:"button",className:"lhm-link",onClick:function(){setMan(!0)}},"My server isn't listed — type it")):null,
        step==="login"?H("div",{className:"lhm-pick",key:"l"},
          H("div",{className:"lhm-chosen"},__lhmLogo(pk||{name:srv},"md"),H("span",{className:"lhm-row-t"},H("small",null,(pk?pk.name:"SERVER")+" · "+plat),H("b",null,srv||"—")),
            H("button",{type:"button",className:"lhm-chg-b",onClick:function(){goStep(pk?"server":"broker")}},"CHANGE")),
          H("label",{className:"lhm-field"},H("span",null,"ACCOUNT ID"),H("input",{value:acc,onChange:function(x){setAcc(x.target.value)},placeholder:"e.g. 2001234567",inputMode:"numeric",name:"lh-mt-account",autoComplete:"off","data-lpignore":"true","data-1p-ignore":"true","data-form-type":"other"})),
          H("label",{className:"lhm-field"},H("span",null,"PASSWORD"),H("div",{className:"lhm-pw"},H("input",{type:showPw?"text":"password",value:pw,onChange:function(x){setPw(x.target.value)},placeholder:"Your trading password",name:"lh-mt-pass",autoComplete:"new-password",autoCapitalize:"off",autoCorrect:"off",spellCheck:!1,"data-lpignore":"true","data-1p-ignore":"true","data-form-type":"other"}),
            H("button",{type:"button",onClick:function(x){x.preventDefault();setShowPw(!showPw)}},showPw?"HIDE":"SHOW"))),
          H("button",{className:"lhm-go",onClick:connect},"CONNECT ACCOUNT")):null,
        err||e.error?H("div",{className:"lhm-err",role:"alert"},H("b",null,"Could not connect"),H("span",null,err||e.error)):null)})()]})}`;

export const metatraderStyle = `
.lhm{position:relative;min-height:100%;padding:calc(14px + env(safe-area-inset-top,0px)) 18px 120px;color:#e8eefb;overflow:hidden}
.lhm-bg{position:absolute;inset:0;pointer-events:none;background:radial-gradient(120% 60% at 50% -10%,rgba(var(--blue-rgb,56,189,248),.18),transparent 60%),linear-gradient(rgba(var(--blue-rgb,56,189,248),.05) 1px,transparent 1px),linear-gradient(90deg,rgba(var(--blue-rgb,56,189,248),.05) 1px,transparent 1px);background-size:auto,26px 26px,26px 26px;-webkit-mask-image:linear-gradient(180deg,#000,transparent 70%);mask-image:linear-gradient(180deg,#000,transparent 70%)}
.lhm-head{position:relative;display:flex;align-items:center;gap:12px;margin-bottom:18px}
.lhm-menu{flex-shrink:0}
.lhm-ht{flex:1;min-width:0}
.lhm-ht small{display:block;font-size:10px;font-weight:800;letter-spacing:.28em;color:#7d8899}
.lhm-ht h1{margin:2px 0 0;font-size:26px;font-weight:900;font-style:italic;letter-spacing:.02em;color:#fff;line-height:1}
.lhm-ht h1 em{font-style:italic;color:var(--blue-bright,#38bdf8);text-shadow:0 0 18px rgba(var(--blue-rgb,56,189,248),.5)}
.lhm-state{display:flex;align-items:center;gap:6px;padding:7px 11px;border-radius:999px;font-size:10px;font-weight:900;letter-spacing:.16em;color:#9aa6b8;background:rgba(255,255,255,.05);box-shadow:inset 0 0 0 1px rgba(255,255,255,.1)}
.lhm-state i{width:7px;height:7px;border-radius:50%;background:#64748b}
.lhm.is-on .lhm-state{color:#b8f5cf;box-shadow:inset 0 0 0 1px rgba(34,197,94,.45)}.lhm.is-on .lhm-state i{background:#22c55e;box-shadow:0 0 10px #22c55e;animation:lhmBlink 1.6s infinite}
.lhm.is-wait .lhm-state i{background:#f5a524;animation:lhmBlink .8s infinite}
@keyframes lhmBlink{50%{opacity:.35}}
.lhm-body{position:relative;display:grid;gap:14px;animation:lhmIn .45s cubic-bezier(.2,.9,.2,1) both}
@keyframes lhmIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
.lhm-card{position:relative;overflow:hidden;border-radius:28px;padding:18px 18px 0;background:linear-gradient(155deg,rgba(var(--blue-rgb,56,189,248),.2),rgba(10,14,26,.92) 45%,rgba(6,9,18,.96));box-shadow:inset 0 0 0 1px rgba(var(--blue-rgb,56,189,248),.35),0 24px 50px rgba(0,0,0,.45)}
.lhm-shine{position:absolute;top:-60%;left:-30%;width:60%;height:220%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.07),transparent);transform:rotate(18deg);animation:lhmShine 6s ease-in-out infinite;pointer-events:none}
@keyframes lhmShine{0%,60%{left:-40%}100%{left:130%}}
.lhm-card-top{display:flex;align-items:center;gap:10px}
.lhm-plat{padding:6px 9px;border-radius:10px;font-size:11px;font-weight:900;letter-spacing:.08em;color:#04121c;background:var(--blue-bright,#38bdf8)}
.lhm-acc{display:grid;min-width:0;flex:1}
.lhm-acc b{font-size:15px;color:#fff;font-family:var(--font-mono,ui-monospace,monospace)}
.lhm-acc span{font-size:11.5px;color:#8a93a6;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lhm-live{display:flex;align-items:center;gap:6px;font-size:9.5px;font-weight:900;letter-spacing:.14em;color:#86efac}
.lhm-live i{width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 10px #22c55e;animation:lhmBlink 1.6s infinite}
.lhm-eq-l{margin-top:20px;font-size:10.5px;font-weight:800;letter-spacing:.24em;color:#8a93a6}
.lhm-eq{margin-top:4px;font-size:36px;font-weight:900;letter-spacing:-.01em;color:#fff;font-variant-numeric:tabular-nums;text-shadow:0 0 26px rgba(var(--blue-rgb,56,189,248),.35)}
.lhm-chg{margin-top:4px;font-size:12px;font-weight:800;font-variant-numeric:tabular-nums}
.lhm-chg.up{color:#4ade80}.lhm-chg.down{color:#f87171}
.lhm-chart{position:relative;height:110px;margin:10px -18px 0;color:var(--blue-bright,#38bdf8)}
.lhm-chart svg{position:absolute;inset:6px 0 0;width:100%;height:calc(100% - 6px);overflow:visible}
.lhm-path{filter:drop-shadow(0 0 6px currentColor);transition:d .9s cubic-bezier(.2,.9,.2,1)}
.lhm-area{transition:d .9s cubic-bezier(.2,.9,.2,1)}
.lhm-end{filter:drop-shadow(0 0 8px currentColor);animation:lhmPulse 1.6s ease-in-out infinite;transition:cx .9s,cy .9s}
@keyframes lhmPulse{50%{r:7;opacity:.6}}
.lhm-scan{position:absolute;top:0;bottom:0;width:60px;left:-60px;background:linear-gradient(90deg,transparent,rgba(var(--blue-rgb,56,189,248),.08),transparent);animation:lhmScan 3.2s linear infinite;pointer-events:none}
@keyframes lhmScan{to{left:100%}}
.lhm-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.lhm-stat{border-radius:18px;padding:12px 14px;background:rgba(255,255,255,.04);box-shadow:inset 0 0 0 1px rgba(255,255,255,.07);display:grid;gap:4px}
.lhm-stat span{font-size:9.5px;font-weight:800;letter-spacing:.18em;color:#7d8899}
.lhm-stat b{font-size:14.5px;color:#fff;font-variant-numeric:tabular-nums;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lhm-stat.pos b{color:#4ade80}.lhm-stat.neg b{color:#f87171}
.lhm-broker{display:flex;align-items:center;gap:12px;margin-top:14px;padding:10px 12px;border-radius:16px;background:rgba(255,255,255,.05);box-shadow:inset 0 0 0 1px rgba(255,255,255,.1);animation:lhmIn .5s .1s both}
.lhm-broker-logo{flex:none;display:grid;place-items:center;height:38px;padding:0 12px;border-radius:12px;background:#fff;box-shadow:0 6px 18px rgba(48,79,254,.35)}
.lhm-broker-logo img{display:block;height:15px;width:auto}
.lhm-broker-txt{flex:none;padding:9px 12px;border-radius:12px;font-size:13px;font-weight:900;letter-spacing:.06em;color:#04121c;background:var(--blue-bright,#38bdf8)}
.lhm-broker-s{display:grid;min-width:0}
.lhm-broker-s small{font-size:9.5px;font-weight:800;letter-spacing:.2em;color:#7d8899}
.lhm-broker-s b{font-size:12.5px;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lhm-act{border-radius:22px;padding:14px;background:rgba(255,255,255,.04);box-shadow:inset 0 0 0 1px rgba(255,255,255,.07);display:grid;gap:8px}
.lhm-act-h{display:flex;align-items:center;justify-content:space-between;gap:8px}
.lhm-act-h span{font-size:10px;font-weight:800;letter-spacing:.2em;color:#9aa6b8}
.lhm-act-h em{display:flex;align-items:center;gap:6px;font-style:normal;font-size:9.5px;font-weight:900;letter-spacing:.14em;color:var(--blue-bright,#38bdf8)}
.lhm-act-h em i{width:6px;height:6px;border-radius:50%;background:currentColor;animation:lhmBlink 1.4s infinite}
.lhm-act-r{display:flex;align-items:center;gap:10px;padding:8px 2px;border-top:1px solid rgba(255,255,255,.06);animation:lhmIn .35s both}
.lhm-act-d{flex:none;width:8px;height:8px;border-radius:50%;background:#64748b}
.lhm-act-r.ok .lhm-act-d{background:#22c55e;box-shadow:0 0 8px #22c55e}.lhm-act-r.bad .lhm-act-d{background:#f87171}.lhm-act-r.sig .lhm-act-d{background:var(--blue-bright,#38bdf8);box-shadow:0 0 8px var(--blue-bright,#38bdf8)}
.lhm-act-t{flex:1;min-width:0;font-size:11.5px;font-family:var(--font-mono,ui-monospace,monospace);color:#dbe4f3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lhm-act-r time{flex:none;font-size:10.5px;color:#7d8899;font-variant-numeric:tabular-nums}
.lhm-act-e{font-size:12px;color:#7d8899;padding:4px 2px}
.lhm-disc{height:52px;border-radius:18px;border:0;font-size:12.5px;font-weight:900;letter-spacing:.16em;color:#fca5a5;background:rgba(239,68,68,.08);box-shadow:inset 0 0 0 1px rgba(239,68,68,.4)}
.lhm-disc:active,.lhm-go:active{transform:scale(.97)}
.lhm-wait{justify-items:center;text-align:center;padding-top:30px}
.lhm-radar{position:relative;width:170px;height:170px;display:grid;place-items:center}
.lhm-radar i{position:absolute;inset:0;border-radius:50%;box-shadow:inset 0 0 0 2px rgba(var(--blue-rgb,56,189,248),.5);animation:lhmRing 2.4s ease-out infinite}
.lhm-radar i:nth-child(2){animation-delay:.8s}.lhm-radar i:nth-child(3){animation-delay:1.6s}
@keyframes lhmRing{from{transform:scale(.35);opacity:1}to{transform:scale(1);opacity:0}}
.lhm-radar b{width:70px;height:70px;border-radius:22px;display:grid;place-items:center;font-size:20px;font-weight:900;font-style:italic;color:#04121c;background:var(--blue-bright,#38bdf8);box-shadow:0 0 40px rgba(var(--blue-rgb,56,189,248),.6)}
.lhm-wait-t{margin-top:18px;font-size:16px;font-weight:800;color:#fff}
.lhm-wait-s{font-size:12px;color:#7d8899}
.lhm-link{margin-top:8px;border:0;background:none;color:var(--blue-bright,#38bdf8);font-weight:700;text-decoration:underline;font-size:12.5px}
.lhm-hero{display:flex;align-items:center;gap:14px;padding:16px;border-radius:24px;background:rgba(255,255,255,.035);box-shadow:inset 0 0 0 1px rgba(255,255,255,.07)}
.lhm-hero p{margin:0;font-size:12.5px;line-height:1.5;color:#9aa6b8}
.lhm-orb{position:relative;flex-shrink:0;width:72px;height:72px;display:grid;place-items:center}
.lhm-orb i{position:absolute;inset:0;border-radius:50%;border:2px solid transparent;border-top-color:var(--blue-bright,#38bdf8);border-right-color:rgba(var(--blue-rgb,56,189,248),.35);animation:lhSpinRing 2.2s linear infinite}
.lhm-orb i:nth-child(2){inset:9px;animation-duration:3.4s;animation-direction:reverse}
.lhm-orb b{font-size:15px;font-weight:900;font-style:italic;color:#fff}
.lhm-seg{position:relative;display:grid;grid-template-columns:1fr 1fr;padding:5px;border-radius:18px;background:rgba(255,255,255,.05);box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)}
.lhm-seg-k{position:absolute;top:5px;bottom:5px;left:5px;width:calc(50% - 5px);border-radius:14px;background:var(--blue-bright,#38bdf8);box-shadow:0 6px 18px rgba(var(--blue-rgb,56,189,248),.4);transition:transform .32s cubic-bezier(.2,.9,.2,1)}
.lhm-seg-k.r{transform:translateX(100%)}
.lhm-seg button{position:relative;z-index:1;height:42px;border:0;background:none;font-size:14px;font-weight:900;letter-spacing:.1em;color:#9aa6b8;transition:color .25s}
.lhm-seg button.on{color:#04121c}
.lhm-field{display:grid;gap:7px}
.lhm-field>span{font-size:10px;font-weight:800;letter-spacing:.2em;color:#7d8899;margin-left:4px}
.lhm-field input{width:100%;box-sizing:border-box;height:52px;border-radius:16px;border:0;outline:0;padding:0 16px;font-size:15px;color:#fff;background:rgba(255,255,255,.05);box-shadow:inset 0 0 0 1px rgba(255,255,255,.1);transition:box-shadow .2s}
.lhm-field input:focus{box-shadow:inset 0 0 0 1.5px var(--blue-bright,#38bdf8),0 0 0 4px rgba(var(--blue-rgb,56,189,248),.14)}
.lhm-pw{position:relative}
.lhm-pw input{padding-right:70px}
.lhm-pw button{position:absolute;right:8px;top:8px;height:36px;padding:0 12px;border:0;border-radius:12px;font-size:10.5px;font-weight:900;letter-spacing:.1em;color:#cfe3ff;background:rgba(255,255,255,.08)}
.lhm-go{height:56px;margin-top:4px;border:0;border-radius:18px;font-size:14.5px;font-weight:900;letter-spacing:.16em;color:#04121c;background:linear-gradient(135deg,var(--blue-bright,#38bdf8),rgba(var(--blue-rgb,56,189,248),.7));box-shadow:0 14px 32px rgba(var(--blue-rgb,56,189,248),.35);transition:transform .15s}
.lhm-err{display:grid;gap:3px;padding:12px 14px;border-radius:16px;background:rgba(239,68,68,.1);box-shadow:inset 0 0 0 1px rgba(239,68,68,.4)}
.lhm-err b{font-size:12px;letter-spacing:.1em;color:#fca5a5;text-transform:uppercase}
.lhm-err span{font-size:12.5px;color:#e2e8f0;line-height:1.4}
.lhm-lg{position:relative;flex:none;width:40px;height:40px;border-radius:12px;display:grid;place-items:center;overflow:hidden;background:#fff;box-shadow:0 4px 14px rgba(0,0,0,.35),0 0 0 1px rgba(255,255,255,.12)}
.lhm-lg:has(img){background:transparent}
.lhm-lg img{width:100%;height:100%;object-fit:cover;display:block}
.lhm-lg::after{content:"";position:absolute;top:-20%;bottom:-20%;width:38%;left:-60%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.55),transparent);transform:skewX(-18deg);animation:lhmLogoShine 4.2s ease-in-out infinite;pointer-events:none}
@keyframes lhmLogoShine{0%,70%{left:-60%}100%{left:140%}}
@media (prefers-reduced-motion:reduce){.lhm-lg::after{animation:none;display:none}}
.lhm-lg.mono{color:#fff;font-size:13px;font-weight:900;letter-spacing:.04em}
.lhm-lg.sm{width:30px;height:30px;border-radius:9px;font-size:10.5px}
.lhm-lg.md{width:44px;height:44px;border-radius:13px}
.lhm-lg.lg{width:50px;height:50px;border-radius:15px;font-size:15px}
.lhm-steps{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
.lhm-stp{height:40px;border:0;border-radius:14px;display:flex;align-items:center;justify-content:center;gap:7px;font-size:10.5px;font-weight:900;letter-spacing:.14em;color:#7d8899;background:rgba(255,255,255,.04);box-shadow:inset 0 0 0 1px rgba(255,255,255,.08);transition:all .25s}
.lhm-stp i{font-style:normal;width:20px;height:20px;border-radius:50%;display:grid;place-items:center;font-size:10.5px;background:rgba(255,255,255,.08)}
.lhm-stp.on{color:#fff;box-shadow:inset 0 0 0 1.5px var(--blue-bright,#38bdf8),0 0 18px rgba(var(--blue-rgb,56,189,248),.25)}
.lhm-stp.on i{color:#04121c;background:var(--blue-bright,#38bdf8)}
.lhm-stp.done{color:#cfe3ff}.lhm-stp.done i{background:rgba(var(--blue-rgb,56,189,248),.35);color:#fff}
.lhm-pick{display:grid;gap:12px;animation:lhmIn .35s cubic-bezier(.2,.9,.2,1) both}
.lhm-search{position:relative;display:flex;align-items:center;gap:10px;height:52px;padding:0 14px;border-radius:16px;color:#7d8899;background:rgba(255,255,255,.05);box-shadow:inset 0 0 0 1px rgba(255,255,255,.1)}
.lhm-search:focus-within{box-shadow:inset 0 0 0 1.5px var(--blue-bright,#38bdf8),0 0 0 4px rgba(var(--blue-rgb,56,189,248),.14)}
.lhm-search input{flex:1;min-width:0;height:100%;border:0;outline:0;background:none;font-size:15px;color:#fff}
.lhm-search button{border:0;width:30px;height:30px;border-radius:10px;display:grid;place-items:center;color:#cfe3ff;background:rgba(255,255,255,.08)}
.lhm-cap{display:flex;align-items:center;justify-content:space-between;margin:2px 4px 0}
.lhm-cap span{font-size:10px;font-weight:800;letter-spacing:.2em;color:#9aa6b8}
.lhm-cap em{font-style:normal;font-size:9.5px;font-weight:900;letter-spacing:.14em;color:var(--blue-bright,#38bdf8)}
.lhm-grid-b{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}
.lhm-tile{display:grid;justify-items:center;gap:8px;padding:12px 6px 10px;border:0;border-radius:18px;color:#e8eefb;background:rgba(255,255,255,.04);box-shadow:inset 0 0 0 1px rgba(255,255,255,.08);animation:lhmIn .4s both;transition:transform .15s}
.lhm-tile span{font-size:11px;font-weight:800;line-height:1.2;text-align:center;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.lhm-tile:active,.lhm-row:active{transform:scale(.97)}
.lhm-list{display:grid;gap:8px}
.lhm-row{display:flex;align-items:center;gap:12px;width:100%;padding:10px 12px;border:0;border-radius:16px;text-align:left;color:#e8eefb;background:rgba(255,255,255,.04);box-shadow:inset 0 0 0 1px rgba(255,255,255,.08);animation:lhmIn .35s both;transition:transform .15s,box-shadow .2s}
.lhm-row.on{box-shadow:inset 0 0 0 1.5px var(--blue-bright,#38bdf8)}
.lhm-row-t{flex:1;min-width:0;display:grid;gap:2px}
.lhm-row-t b{font-size:14px;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.lhm-row.srv .lhm-row-t b{font-size:13px;font-family:var(--font-mono,ui-monospace,monospace)}
.lhm-row-t small{font-size:10.5px;color:#7d8899;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:.04em}
.lhm-chev{flex:none;color:#7d8899}
.lhm-tag{flex:none;padding:4px 8px;border-radius:8px;font-size:9.5px;font-weight:900;letter-spacing:.12em;color:#b8f5cf;background:rgba(34,197,94,.14);box-shadow:inset 0 0 0 1px rgba(34,197,94,.4)}
.lhm-tag.demo{color:#fde68a;background:rgba(245,165,36,.12);box-shadow:inset 0 0 0 1px rgba(245,165,36,.4)}
.lhm-chosen{display:flex;align-items:center;gap:12px;padding:12px;border-radius:18px;background:linear-gradient(135deg,rgba(var(--blue-rgb,56,189,248),.16),rgba(255,255,255,.03));box-shadow:inset 0 0 0 1px rgba(var(--blue-rgb,56,189,248),.4)}
.lhm-chosen .lhm-row-t small{font-weight:800;letter-spacing:.16em;font-size:9.5px}
.lhm-chg-b{flex:none;height:36px;padding:0 12px;border:0;border-radius:12px;font-size:10.5px;font-weight:900;letter-spacing:.12em;color:#04121c;background:var(--blue-bright,#38bdf8)}
.lhm-note{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:14px;font-size:12px;line-height:1.45;color:#9aa6b8;background:rgba(255,255,255,.03)}
.lhm-note.bad{color:#fca5a5;background:rgba(239,68,68,.08)}
.lhm-spin{flex:none;width:16px;height:16px;border-radius:50%;border:2px solid rgba(var(--blue-rgb,56,189,248),.25);border-top-color:var(--blue-bright,#38bdf8);animation:lhSpinRing .8s linear infinite}
@keyframes lhSpinRing{to{transform:rotate(360deg)}}
.lhm-man{display:flex;gap:8px}
.lhm-man input{flex:1;min-width:0;height:46px;border-radius:14px;border:0;outline:0;padding:0 14px;font-size:14px;color:#fff;background:rgba(255,255,255,.05);box-shadow:inset 0 0 0 1px rgba(255,255,255,.1)}
.lhm-man .lhm-chg-b{height:46px}
`;

// The component with the broker directory it searches (logos + search words) in front of it.
export const metatraderSrc = "var __lhmBrokers=" + JSON.stringify(brokerDirectory) + ";" + metatraderComponent;

export function applyMetatrader(html: string) {
  return applyMtRelay(applyMtConnect(html))
    .replace(/function oC\(\)\{let\{mt:e\}=\$\(\),[\s\S]*?\}function sC\(\{open:e,onClose:t\}\)\{/, () => metatraderSrc + "function sC({open:e,onClose:t}){")
    .replace("</head>\n<body>", () => `<style id="lh-metatrader">${metatraderStyle}</style>\n</head>\n<body>`);
}
