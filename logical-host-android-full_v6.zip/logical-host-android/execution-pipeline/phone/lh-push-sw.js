/* LOGICAL HOST notifications: shows "Trade placed" alerts sent by the server while the app is closed. */
self.addEventListener("install", function () { self.skipWaiting(); });
self.addEventListener("activate", function (e) { e.waitUntil(self.clients.claim()); });

self.addEventListener("push", function (e) {
  var msg = {};
  try { msg = e.data ? e.data.json() : {}; } catch (err) { msg = { title: "LOGICAL HOST", body: e.data ? e.data.text() : "" }; }
  e.waitUntil(self.registration.showNotification(msg.title || "LOGICAL HOST", {
    body: msg.body || "",
    tag: msg.tag || undefined,
    renotify: true,
    silent: false,
    vibrate: [180, 80, 180, 80, 180],
    icon: "/favicon.ico",
    badge: "/favicon.ico",
  }));
});

self.addEventListener("notificationclick", function (e) {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(function (list) {
    for (var i = 0; i < list.length; i++) if ("focus" in list[i]) return list[i].focus();
    return self.clients.openWindow("/");
  }));
});
