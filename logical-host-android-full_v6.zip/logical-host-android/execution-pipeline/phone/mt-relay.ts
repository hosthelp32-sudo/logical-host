// Which MetaTrader bridge addresses the /api/public/mt relay may forward to.
const ALLOWED = new Set(["mt4.mtapi.io", "mt5.mtapi.io"]);
const METHOD = /^\/[A-Za-z]{2,40}$/;

export function mtRelayTarget(raw: unknown): string | null {
  try {
    const u = new URL(String(raw || ""));
    if (u.protocol !== "https:" || !ALLOWED.has(u.hostname) || u.port || u.username || u.password) return null;
    if (!METHOD.test(u.pathname)) return null;
    return u.toString();
  } catch {
    return null;
  }
}

// Server side: headers that carry the paid MetaTrader API key (MTAPI_KEY secret) when set.
export function mtKeyHeaders(): Record<string, string> {
  // mtapi.io's public bridges reject logins when extra key headers are sent ("Request headers
  // must contain only ASCII characters"), so none are added; tested with real demo accounts.
  return {};
}

// Phone side: replaces the export's queued fetch (sv). Each phone talks to the bridge over its own
// internet first, so the load of every open app is spread over the phones' own addresses instead of
// funnelling through this site's address (the shared bridge limits per address). A call that errors
// or hangs past its time limit is retried through this site, and the phone keeps using the site for
// the rest of the visit. Plain JS, no backtick or "${" (spliced into the export).
export const mtRelaySrc =
  'var __lhMtR=0;try{__lhMtR=sessionStorage.getItem("lh_mt_relay")==="1"?1:0}catch(_){}' +
  'function __lhMtVia(e){return av("/api/public/mt?u="+encodeURIComponent(String(e)))}' +
  'function __lhMtDirect(e){var c=typeof AbortController=="function"?new AbortController():null,lim=/\\/(Connect|ConnectEx)\\?/.test(String(e))?25000:10000,h=setTimeout(function(){c&&c.abort()},lim);return av(e,c?{signal:c.signal}:void 0).then(function(r){clearTimeout(h);return r},function(x){clearTimeout(h);throw x})}' +
  'function __lhMtNet(x){return !/INVALID|invalid (user|password|account)|wrong|rejected/i.test(String(x&&x.message||x))}' +
  'function sv(e){let t=()=>{if(!/^https:\\/\\/mt[45]\\.mtapi\\.io\\//.test(String(e)))return av(e);if(__lhMtR)return __lhMtVia(e);return __lhMtDirect(e).catch(function(x){if(!__lhMtNet(x))throw x;__lhMtR=1;try{sessionStorage.setItem("lh_mt_relay","1")}catch(_){}return __lhMtVia(e)})},n=ov.then(t,t);return ov=n.then(()=>{},()=>{}),n}';

// MT5 calls go to this site's /api/public/mt5, which adds the owner's private API key on the server.
export const MT5_BASE_FROM = "nv={MT4:`https://mt4.mtapi.io`,MT5:`https://mt5.mtapi.io`}";
export const MT5_BASE_TO = 'nv={MT4:"https://mt4.mtapi.io",MT5:location.origin+"/api/public/mt5"}';

export function applyMtRelay(html: string) {
  return html.replace(MT5_BASE_FROM, () => MT5_BASE_TO).replace(
    "function sv(e){let t=()=>av(e),n=ov.then(t,t);return ov=n.then(()=>{},()=>{}),n}",
    () => mtRelaySrc,
  );
}
