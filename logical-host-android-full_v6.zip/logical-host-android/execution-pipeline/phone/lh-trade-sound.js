/* LOGICAL HOST bot sounds.
   - Signal sound: plays the moment the bot receives a mentor signal, before execution
     (window.__lhSignalSound()).
   - Trade sound: plays once for every trade the bot places (window.__lhTradeSound()).
   Both share one timeline, so a signal is heard first and each placed trade is heard after
   it, one after another (e.g. signal, then 5 trade sounds for 5 trades). Execution itself is
   never delayed by the sounds. */
(function () {
  "use strict";
  if (window.__lhTradeSound) return;
  var script = document.currentScript;
  var srcs = {
    trade: (script && script.getAttribute("data-src")) || "",
    signal: (script && script.getAttribute("data-signal")) || "",
  };
  var GAP = 0.3; // seconds between back-to-back trade sounds
  var ctx = null, nextAt = 0, fallbackAt = 0;
  var buffers = {}, loading = {};

  function audioCtx() {
    if (ctx) return ctx;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try { ctx = new AC(); } catch (e) { ctx = null; }
    return ctx;
  }

  function load(name) {
    var src = srcs[name];
    if (buffers[name] || !src) return Promise.resolve(buffers[name] || null);
    if (loading[name]) return loading[name];
    var c = audioCtx();
    if (!c) return Promise.resolve(null);
    loading[name] = fetch(src)
      .then(function (r) { return r.arrayBuffer(); })
      .then(function (data) {
        return new Promise(function (resolve, reject) { c.decodeAudioData(data, resolve, reject); });
      })
      .then(function (b) { buffers[name] = b; return b; })
      .catch(function () { loading[name] = null; return null; });
    return loading[name];
  }
  function loadAll() { load("signal"); load("trade"); }

  // Phones only allow sound after a tap, so unlock audio on the first touch.
  function unlock() {
    var c = audioCtx();
    if (c && c.state === "suspended") c.resume().catch(function () {});
    loadAll();
  }
  ["pointerdown", "touchstart", "keydown"].forEach(function (ev) {
    document.addEventListener(ev, unlock, { capture: true, passive: true });
  });

  // Without Web Audio: play through a plain audio element, still one after another.
  function fallback(name, length) {
    var now = Date.now();
    var at = Math.max(now, fallbackAt);
    fallbackAt = at + length * 1000;
    setTimeout(function () {
      try { var a = new Audio(srcs[name]); a.play().catch(function () {}); } catch (e) { /* no sound */ }
    }, at - now);
  }

  function playNow(name) {
    var c = audioCtx();
    var buffer = buffers[name];
    if (!c || !buffer) { fallback(name, name === "signal" ? 1.2 : GAP); return; }
    if (c.state === "suspended") c.resume().catch(function () {});
    var now = c.currentTime;
    // A new signal starts its sound straight away; trades wait for the sound before them.
    var at = name === "signal" ? now + 0.01 : Math.max(now + 0.01, nextAt);
    var node = c.createBufferSource();
    node.buffer = buffer;
    node.connect(c.destination);
    node.start(at);
    var end = at + (name === "signal" ? buffer.duration : Math.max(buffer.duration, GAP));
    nextAt = Math.max(nextAt, end);
  }

  function play(name) {
    if (!srcs[name]) return;
    if (buffers[name]) { playNow(name); return; }
    load(name).then(function () { playNow(name); });
  }

  window.__lhTradeSound = function () { play("trade"); };
  window.__lhSignalSound = function () { play("signal"); };

  loadAll();
})();
