// MetaTrader login used by the trading app (phone) and by server-side auto execution.
//
// Why: logging in by server name (the bridge's ConnectEx) fails for many accounts even with the
// right password — e.g. a broker lists several server names on the same machine and the student
// picks a sibling name, the bridge answers "Server closed the socket", and the old app then retried
// four times, which makes the bridge pause logins to that broker for EVERYONE for a few seconds.
// Now: one login by name (waiting out a short bridge pause instead of hammering it), then, if the
// broker refused it for any reason other than a wrong login, a direct login to that server's own
// addresses (the bridge's Connect, host + port from its broker search), which works whatever
// sibling name was picked. After a direct login the account's real server name is read back, so
// reconnects and the server use the right name from then on.

export type MtReply = { ok: boolean; status?: number; text: string; data: any }; // eslint-disable-line @typescript-eslint/no-explicit-any
export type MtIo = { get: (method: string, params: Record<string, string>) => Promise<MtReply>; wait: (ms: number) => Promise<unknown> };

export const MT_BAD_LOGIN = /PASSWORD_IS_SERVER|INVALID_ACCOUNT|invalid (user|password|account)|wrong password|authori[sz]ation failed/i;
const PRIVATE_HOST = /^(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|localhost$)/i;

export function mtToken(r: MtReply | null | undefined) {
  if (!r) return "";
  const d = r.data;
  if (d && typeof d === "object") return "";
  const t = String(typeof d === "string" ? d : r.text || "").replace(/"/g, "").trim();
  return r.ok && t && t.charAt(0) !== "{" && t.length >= 4 ? t : "";
}
export function mtMessage(r: MtReply | null | undefined) {
  const d = r && r.data;
  return d && typeof d === "object" && typeof d.message === "string" ? String(d.message) : "";
}
export function mtPause(msg: string) {
  const m = /paused for (\d+)/i.exec(msg);
  return m ? Math.min(Number(m[1]) + 400, 15000) : 0;
}

// The access points ("host:port", MT4 lists bare hosts = port 443) of one server name from the
// bridge's /Search reply; private addresses are skipped, at most four are kept.
export function mtHosts(list: unknown, name: string) {
  const out: { host: string; port: string }[] = [];
  const want = String(name || "").trim().toLowerCase();
  if (!Array.isArray(list) || !want) return out;
  for (const c of list) {
    for (const r of (c && Array.isArray(c.results) ? c.results : [])) {
      if (!r || String(r.name || "").trim().toLowerCase() !== want) continue;
      for (const a of Array.isArray(r.access) ? r.access : []) {
        const m = /^\[?([^\]\s]+?)\]?(?::(\d+))?$/.exec(String(a || "").trim());
        const host = m?.[1] ?? "";
        if (!host || PRIVATE_HOST.test(host) || host.includes(":")) continue;
        const port = m?.[2] || "443";
        if (!out.some((h) => h.host === host && h.port === port)) out.push({ host, port });
        if (out.length >= 4) return out;
      }
    }
  }
  return out;
}

export function mtUser(v: unknown) {
  const s = String(v ?? "").trim();
  const d = s.replace(/\D/g, "");
  return d || s;
}

// True when the password box holds the server name or the account number instead of a password.
export function mtPasswordIsServer(password: unknown, server: unknown, user?: unknown) {
  const p = String(password ?? "").trim().toLowerCase();
  if (!p) return false;
  return p === String(server ?? "").trim().toLowerCase() || p === String(user ?? "").trim().toLowerCase();
}

// Server-side copy of __lhMtLogin below (the phone runs the spliced source). Keep them alike;
// mt-connect.test.ts runs both against the same fake bridge.
export async function mtLogin(io: MtIo, input: { user?: unknown; password?: unknown; server?: unknown }, opts: { nameTimeout?: number; hostTimeout?: number; maxHosts?: number } = {}) {
  const user = mtUser(input.user), password = String(input.password ?? ""), server = String(input.server ?? "").trim();
  const call = async (m: string, p: Record<string, string>): Promise<MtReply> => {
    try { return await io.get(m, p); } catch (x) { return { ok: false, text: "", data: { message: String((x as Error)?.message || "network error") } }; }
  };
  // A phone's password manager can fill the password box with the server name; the broker then
  // refuses the login (INVALID_ACCOUNT) and repeated tries make the bridge pause that broker.
  if (mtPasswordIsServer(password, server, user)) throw new Error("PASSWORD_IS_SERVER");
  let last = "", token = "", via = "";
  for (let k = 0; k < 3 && !token; k++) {
    const r = await call("ConnectEx", { user, password, server, connectTimeoutSeconds: String(opts.nameTimeout ?? 40) });
    token = mtToken(r);
    if (token) { via = "name"; break; }
    last = mtMessage(r) || last || `Login failed (${r.status || 0})`;
    if (MT_BAD_LOGIN.test(last)) throw new Error(last);
    const w = mtPause(last);
    if (w && k < 2) { await io.wait(w); continue; }
    break;
  }
  if (!token) {
    const s = await call("Search", { company: server });
    const hosts = mtHosts(s.data, server).slice(0, opts.maxHosts ?? 4);
    for (let i = 0, paused = 0; i < hosts.length && !token; i++) {
      const h = hosts[i]!;
      const r = await call("Connect", { user, password, host: h.host, port: h.port, connectTimeoutSeconds: String(opts.hostTimeout ?? 20) });
      token = mtToken(r);
      if (token) { via = "host"; break; }
      const m = mtMessage(r);
      if (m) last = m;
      if (MT_BAD_LOGIN.test(m)) break;
      const w = mtPause(m);
      if (w && paused++ < 2) { await io.wait(w); i--; }
    }
  }
  if (!token) throw new Error(last || "Could not connect to the broker");
  let name = server;
  if (via === "host") {
    const d = await call("AccountDetails", { id: token });
    const sn = d.data && typeof d.data === "object" ? d.data.serverName || d.data.ServerName : "";
    if (sn && typeof sn === "string") name = sn;
  }
  return { token, server: name, via };
}

// Phone copy, spliced into the export before its MetaTrader request function (yv). Plain JS with
// no backtick and no "${" because it sits inside the export's script.
export const mtLoginSrc = String.raw`function __lhMtErr(n){n=String(n||"");if(/PASSWORD_IS_SERVER/.test(n))return"The password box has your server name or account number in it (your phone may have filled it in). Clear it and type your MetaTrader trading password.";if(/account (not found|does not exist)|no such account/i.test(n))return"Account ID is wrong \u2014 check the account number from your broker.";if(/invalid password|wrong password|INVALID_PASSWORD/i.test(n))return"Password is wrong \u2014 use your trading (master) password, not the investor password.";if(/INVALID_ACCOUNT|invalid (user|account|login)|authori[sz]ation failed/i.test(n))return"Account ID or password is wrong \u2014 check both and try again.";if(/SERVER_NOT_FOUND|not found|unknown server|CONNECT_ERROR|closed the socket|connection reset|Disconnected/i.test(n))return"Server is wrong \u2014 pick your server from the list exactly as in MetaTrader (demo and live use different servers).";return"Terminal error \u2014 the MetaTrader connection service has a problem. Please try again later."}
var __lhMtBad=/PASSWORD_IS_SERVER|INVALID_ACCOUNT|invalid (user|password|account)|wrong password|authori[sz]ation failed/i,__lhMtPriv=/^(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.|localhost$)/i;
function __lhMtTok(r){if(!r)return"";var d=r.data;if(d&&typeof d==="object")return"";var t=String(typeof d==="string"?d:r.text||"").replace(/"/g,"").trim();return r.ok&&t&&t.charAt(0)!=="{"&&t.length>=4?t:""}
function __lhMtMsg(r){var d=r&&r.data;return d&&typeof d==="object"&&typeof d.message==="string"?String(d.message):""}
function __lhMtPause(m){var x=/paused for (\d+)/i.exec(m);return x?Math.min(Number(x[1])+400,15e3):0}
function __lhMtHosts(list,name){var out=[],want=String(name||"").trim().toLowerCase();if(!Array.isArray(list)||!want)return out;
  for(var i=0;i<list.length;i++){var rs=list[i]&&Array.isArray(list[i].results)?list[i].results:[];
    for(var j=0;j<rs.length;j++){var r=rs[j];if(!r||String(r.name||"").trim().toLowerCase()!==want)continue;var ac=Array.isArray(r.access)?r.access:[];
      for(var k=0;k<ac.length;k++){var m=/^\[?([^\]\s]+?)\]?(?::(\d+))?$/.exec(String(ac[k]||"").trim());if(!m||__lhMtPriv.test(m[1])||m[1].indexOf(":")>=0)continue;
        var port=m[2]||"443",dup=out.some(function(h){return h.host===m[1]&&h.port===port});if(!dup)out.push({host:m[1],port:port});if(out.length>=4)return out}}}
  return out}
function __lhMtUser(v){var s=String(v==null?"":v).trim(),d=s.replace(/\D/g,"");return d||s}
async function __lhMtLogin(io,e){var user=__lhMtUser(e.user),pw=String(e.password==null?"":e.password),srv=String(e.server==null?"":e.server).trim(),last="",token="",via="";
  var __pl=pw.trim().toLowerCase();if(__pl&&(__pl===srv.toLowerCase()||__pl===user.toLowerCase()))throw Error("PASSWORD_IS_SERVER");
  var call=async function(m,p){if(/^Connect/.test(m)){var __gap=(globalThis.__lhMtLast||0)+5e3-Date.now();if(__gap>0&&globalThis.__lhMtLast)await io.wait(__gap);globalThis.__lhMtLast=Date.now()}try{return await io.get(m,p)}catch(x){return{ok:!1,text:"",data:{message:String(x&&x.message||"network error")}}}};
  for(var k=0;k<3&&!token;k++){var r=await call("ConnectEx",{user:user,password:pw,server:srv,connectTimeoutSeconds:"40"});token=__lhMtTok(r);if(token){via="name";break}
    last=__lhMtMsg(r)||last||"Login failed ("+(r.status||0)+")";if(__lhMtBad.test(last))throw Error(last);var w=__lhMtPause(last);if(w&&k<2){await io.wait(w);continue}break}
  if(!token){var s=await call("Search",{company:srv}),hosts=__lhMtHosts(s.data,srv),paused=0;
    for(var i=0;i<hosts.length&&!token;i++){var r2=await call("Connect",{user:user,password:pw,host:hosts[i].host,port:hosts[i].port,connectTimeoutSeconds:"20"});token=__lhMtTok(r2);if(token){via="host";break}
      var m2=__lhMtMsg(r2);if(m2)last=m2;if(__lhMtBad.test(m2))break;var w2=__lhMtPause(m2);if(w2&&paused++<2){await io.wait(w2);i--}}}
  if(!token)throw Error(hosts.length?(last||"Could not connect to the broker"):(__lhMtBad.test(last)?last:"SERVER_NOT_FOUND "+last));
  var name=srv;if(via==="host"){var d=await call("AccountDetails",{id:token}),sn=d.data&&typeof d.data==="object"?d.data.serverName||d.data.ServerName:"";if(sn&&typeof sn==="string")name=sn}
  return{token:token,server:name,via:via}}
`;

// Friendlier messages for what brokers answer (the export's E callback picks one).
export const MT_ERRORS = {
  badLogin: "The broker rejected this login — check the account number, password, server and MT4/MT5 match your broker account exactly.",
  wrongServer: "Your broker refused the login on this server. Make sure the server is the one in your broker's welcome email or in MetaTrader (demo and live accounts use different servers), then try again.",
  busy: "The broker is busy for a moment — wait 10 seconds and tap Connect again.",
  notFound: "That server name wasn't found. Go back and pick your server from the list instead of typing it.",
  slow: "The broker's server didn't answer in time. Check your internet and tap Connect again.",
};

export function applyMtConnect(html: string) {
  const E = MT_ERRORS;
  return html
    // one clear message per cause: account id, password, server, or terminal (API) error
    .replace(/throw\/INVALID_ACCOUNT\|invalid \(user\|password\|account\)\/i\.test\(n\)\?[\s\S]*?platform \(MT4\/MT5\) match your broker account exactly\.`\),x\(\),e\}/, () => "throw s(__lhMtErr(n)),x(),e}")
    // splice the login helpers in front of the export's MetaTrader request function
    .replace("async function yv(e){", () => mtLoginSrc + "async function yv(e){")
    // connect: the new login (one by-name try, then the server's own addresses) instead of 4 by-name retries
    .replace(
      /if\(e\.op===`connect`\)\{let n=\{user:String\(e\.user\),password:String\(e\.password\),server:String\(e\.server\)\}[\s\S]*?if\(!i\)throw Error\(a&&a\.message\|\|`Could not connect to the broker`\);/,
      () => "if(e.op===`connect`){let __g=await __lhMtLogin({get:(m,p)=>lv(t,m,p).then(r=>({ok:r.res.ok,status:r.res.status,text:r.text,data:r.data})),wait:cv},e),i=__g.token;",
    )
    .replace("return{token:i,summary:o}}", () => "return{token:i,summary:o,server:__g.server}}")
    // remember the account's real server name (reconnects and server trading use it)
    .replace(
      "o={accountID:e.accountID,server:e.server,platform:t};",
      () => "o={accountID:e.accountID,server:n.server||e.server,platform:t};",
    )
    .replace(",ww(e)},[y])", () => ",ww({...e,server:n.server||e.server})},[y])")
    // reconnect: stop when the broker says the saved login is wrong, and back off up to a minute,
    // so a changed password doesn't keep knocking on the broker (the bridge then pauses everyone)
    .replace(
      "catch{await new Promise(e=>setTimeout(e,Math.min(5e3+1e3*n,15e3)))}}},[C,w,x])",
      () => "catch(__e){if(__lhMtBad.test(String(__e&&__e.message||``))){h.current=!1,t(`error`),l(``),s(`" + E.badLogin + "`);return}await new Promise(e=>setTimeout(e,Math.min(5e3+3e3*n,6e4)))}}},[C,w,x])",
    );
}
