// LOGICAL HOST - connect the website to the floating bubble (Android app only).
// Paste this into the website code once. It does nothing in a normal browser.
//
// 1. Show every console line:   lhBubblePush(text, kind)
//      kind: signal, info, exec, ok, warn, err  (use the same text the app shows)
// 2. Bot ON / OFF:              lhBubbleBot(true, "BOT NAME", "https://.../bot.png")  or  lhBubbleBot(false)

function lhBubbleLink(url) {
  // Sends a lhbubble:// link to the Android app without leaving the page
  var f = document.createElement("iframe");
  f.style.display = "none";
  f.src = url;
  document.body.appendChild(f);
  setTimeout(function () { f.remove(); }, 1500);
}

function lhBubblePush(text, kind) {
  lhBubbleLink("lhbubble://push?text=" + encodeURIComponent(text) + "&kind=" + encodeURIComponent(kind || "info"));
}

function lhBubbleBot(on, name, pic) {
  if (on) {
    lhBubbleLink("lhbubble://start");
    if (name) lhBubbleLink("lhbubble://bot?name=" + encodeURIComponent(name) + (pic ? "&pic=" + encodeURIComponent(pic) : ""));
  } else {
    lhBubbleLink("lhbubble://stop");
  }
}
