package app.lovable.logicalhostea

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * Two jobs:
 *  1. Links from the website, e.g. lhbubble://push?text=...&kind=ok, lhbubble://bot?name=...&pic=...,
 *     lhbubble://start and lhbubble://stop. Each one is passed to the bubble and this screen closes at once.
 *  2. Opening the app's bubble switch: asks for "Display over other apps", then starts the bubble.
 */
class BubbleSetupActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val link = intent?.data
        if (link != null && link.scheme == "lhbubble") {
            handleLink(link)
            finish()
            return
        }

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7)
        if (BubbleService.canDraw(this)) { BubbleService.start(this); finish(); return }
        Toast.makeText(this, "Turn on \"Display over other apps\" for LOGICAL HOST", Toast.LENGTH_LONG).show()
        startActivityForResult(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), 9
        )
    }

    private fun handleLink(link: Uri) {
        when (link.host) {
            "start" -> {
                if (BubbleService.canDraw(this)) BubbleService.start(this)
                else Toast.makeText(this, "Allow \"Display over other apps\" for the bubble", Toast.LENGTH_LONG).show()
            }
            "stop" -> BubbleService.stop(this)
            "push" -> BubbleService.push(this, link.getQueryParameter("text") ?: "", link.getQueryParameter("kind") ?: "info")
            "bot" -> BubbleService.setBot(this, link.getQueryParameter("name") ?: "", link.getQueryParameter("pic"))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (BubbleService.canDraw(this)) BubbleService.start(this)
        else Toast.makeText(this, "Bubble is off - allow \"Display over other apps\" to use it", Toast.LENGTH_LONG).show()
        finish()
    }
}
