LOGICAL HOST Android app (Stage 2 fixed)

1. Upload the project files to the repo root (unzip first, keep the folders).
2. Make sure .github/workflows/build-apk.yml is in the repo.
3. Go to Actions > Build Android APK > Run workflow.
4. Download the APK from the run's Artifacts.
