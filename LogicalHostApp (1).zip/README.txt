LOGICAL HOST Android app

1. UNZIP this file first (on your phone or computer). GitHub will not unzip it for you.
2. Upload all the files and folders to your GitHub repo, keeping the folder structure.
   The .github folder holds the build workflow, so it must be uploaded too.
3. Go to the Actions tab. Wait for "Build Android APK" to turn green (about 3-5 minutes).
4. Go to the Releases section of your repo (right side of the repo page).
   Tap the newest release and download app-debug.apk.
5. Install app-debug.apk on your phone. You may need to allow installs from unknown sources.
