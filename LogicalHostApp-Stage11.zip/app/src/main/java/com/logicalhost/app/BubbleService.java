package com.logicalhost.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.view.animation.PathInterpolator;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * LOGICAL HOST floating bubble (ported from the original bubble kit).
 *  - Round robot bubble floats over other apps. Drag it; it snaps to a side.
 *  - Drag it onto the X at the bottom to hide it.
 *  - Tap it to open the bot console (assets/lh-console.html).
 */
public class BubbleService extends Service {

    public static final String ACTION_PUSH = "com.logicalhost.app.CONSOLE_PUSH";
    public static final String ACTION_BOT = "com.logicalhost.app.CONSOLE_BOT";
    private static final String CHANNEL = "lh_bubble";

    public static boolean canDraw(Context ctx) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx);
    }

    public static void start(Context ctx) {
        if (!canDraw(ctx)) return;
        Intent i = new Intent(ctx, BubbleService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            ctx.startForegroundService(i);
        } else {
            ctx.startService(i);
        }
    }

    public static void stop(Context ctx) {
        ctx.stopService(new Intent(ctx, BubbleService.class));
    }

    public static void push(Context ctx, String text, String kind) {
        ctx.sendBroadcast(new Intent(ACTION_PUSH).setPackage(ctx.getPackageName())
                .putExtra("text", text).putExtra("kind", kind));
    }

    public static void setBot(Context ctx, String name, String picUrl) {
        ctx.sendBroadcast(new Intent(ACTION_BOT).setPackage(ctx.getPackageName())
                .putExtra("name", name).putExtra("pic", picUrl));
    }

    private WindowManager wm;
    private ImageView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private View trash;
    private FrameLayout console;
    private WebView web;
    private boolean pageReady = false;
    private final List<String> waiting = new ArrayList<>();

    private float downX, downY;
    private int startX, startY;
    private boolean moved;

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startForeground(41, buildNotification());
        addBubble();
        buildConsole();

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_PUSH);
        f.addAction(ACTION_BOT);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, f);
        }
    }

    @Override
    public void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) { }
        try { if (bubble != null && bubble.isAttachedToWindow()) wm.removeView(bubble); } catch (Exception ignored) { }
        try { if (console != null && console.isAttachedToWindow()) wm.removeView(console); } catch (Exception ignored) { }
        try { if (trash != null && trash.isAttachedToWindow()) wm.removeView(trash); } catch (Exception ignored) { }
        if (web != null) web.destroy();
        super.onDestroy();
    }

    // ---------- notification (Android needs one while the bubble shows) ----------
    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(new NotificationChannel(
                        CHANNEL, "Floating bot", NotificationManager.IMPORTANCE_MIN));
            }
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return b.setSmallIcon(R.drawable.lh_bubble_logo)
                .setContentTitle("LOGICAL HOST")
                .setContentText("Bot bubble is on - tap the bubble to see the console")
                .setContentIntent(open)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_MIN)
                .build();
    }

    // ---------- the bubble ----------
    private void addBubble() {
        bubble = new ImageView(this);
        bubble.setImageResource(R.drawable.lh_bubble_logo);
        bubble.setBackground(getResources().getDrawable(R.drawable.lh_bubble_bg));
        int p = dp(8);
        bubble.setPadding(p, p, p, p);
        bubble.setElevation(dp(10));
        bubble.setContentDescription("LOGICAL HOST console");

        bubbleLp = new WindowManager.LayoutParams(
                dp(62), dp(62), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = 0;
        bubbleLp.y = dp(180);
        wm.addView(bubble, bubbleLp);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = bubbleLp.x;
                        startY = bubbleLp.y;
                        moved = false;
                        v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(120).start();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (!moved && (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6))) {
                            moved = true;
                            showTrash(true);
                            hideConsole();
                        }
                        if (moved) {
                            bubbleLp.x = startX + (int) dx;
                            bubbleLp.y = startY + (int) dy;
                            wm.updateViewLayout(bubble, bubbleLp);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(160)
                                .setInterpolator(new OvershootInterpolator()).start();
                        showTrash(false);
                        if (!moved) {
                            toggleConsole();
                        } else if (e.getRawY() > getResources().getDisplayMetrics().heightPixels - dp(150)) {
                            stopSelf();
                        } else {
                            snapToSide();
                        }
                        break;
                }
                return true;
            }
        });
    }

    private void snapToSide() {
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        bubbleLp.x = (bubbleLp.x + dp(31) < w / 2) ? 0 : w - dp(62);
        bubbleLp.y = Math.max(dp(24), Math.min(bubbleLp.y, h - dp(140)));
        wm.updateViewLayout(bubble, bubbleLp);
    }

    private void showTrash(boolean show) {
        if (show && trash == null) {
            ImageView t = new ImageView(this);
            t.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
            t.setBackground(getResources().getDrawable(R.drawable.lh_bubble_bg));
            int p = dp(14);
            t.setPadding(p, p, p, p);
            trash = t;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    dp(56), dp(56), overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            lp.y = dp(48);
            wm.addView(trash, lp);
        } else if (!show && trash != null) {
            try { wm.removeView(trash); } catch (Exception ignored) { }
            trash = null;
        }
    }

    // ---------- the console (tap the bubble) ----------
    @SuppressWarnings("SetJavaScriptEnabled")
    private void buildConsole() {
        FrameLayout box = new FrameLayout(this);
        WebView wv = new WebView(this);
        wv.setBackgroundColor(0);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setDomStorageEnabled(true);
        wv.addJavascriptInterface(new Bridge(), "LH");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                for (String code : waiting) {
                    view.evaluateJavascript(code, null);
                }
                waiting.clear();
            }
        });
        wv.loadUrl("file:///android_asset/lh-console.html");
        box.addView(wv, new FrameLayout.LayoutParams(dp(320), FrameLayout.LayoutParams.WRAP_CONTENT));
        // Tap outside the card closes it
        box.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_OUTSIDE) hideConsole();
                return false;
            }
        });
        web = wv;
        console = box;
    }

    private WindowManager.LayoutParams consoleLp() {
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = Math.max(dp(8), (w - dp(320)) / 2);
        lp.y = Math.max(dp(24), Math.min(bubbleLp.y + dp(70), h - dp(520)));
        return lp;
    }

    private void toggleConsole() {
        if (console == null) return;
        if (console.isAttachedToWindow()) {
            hideConsole();
        } else {
            wm.addView(console, consoleLp());
            console.setAlpha(0f);
            console.setTranslationY(dp(18));
            console.setScaleX(0.92f);
            console.setScaleY(0.92f);
            console.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(450)
                    .setInterpolator(new PathInterpolator(0.32f, 0.72f, 0f, 1f)).start();
        }
    }

    private void hideConsole() {
        if (console != null && console.isAttachedToWindow()) {
            try { wm.removeView(console); } catch (Exception ignored) { }
        }
    }

    private void js(final String code) {
        if (web == null) return;
        if (pageReady) {
            web.post(new Runnable() {
                @Override
                public void run() {
                    web.evaluateJavascript(code, null);
                }
            });
        } else {
            waiting.add(code);
        }
    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String action = i.getAction();
            if (ACTION_PUSH.equals(action)) {
                js("lhPush(" + JSONObject.quote(i.getStringExtra("text") == null ? "" : i.getStringExtra("text"))
                        + "," + JSONObject.quote(i.getStringExtra("kind") == null ? "info" : i.getStringExtra("kind")) + ")");
            } else if (ACTION_BOT.equals(action)) {
                js("lhSetBot(" + JSONObject.quote(i.getStringExtra("name") == null ? "" : i.getStringExtra("name"))
                        + "," + JSONObject.quote(i.getStringExtra("pic") == null ? "" : i.getStringExtra("pic")) + ")");
            }
        }
    };

    /** Buttons inside the console page call these. */
    public class Bridge {
        @JavascriptInterface
        public void closeConsole() {
            bubble.post(new Runnable() {
                @Override
                public void run() { hideConsole(); }
            });
        }

        @JavascriptInterface
        public void openApp() {
            bubble.post(new Runnable() {
                @Override
                public void run() {
                    hideConsole();
                    Intent i = new Intent(BubbleService.this, MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_SINGLE_TOP
                            | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(i);
                }
            });
        }

        @JavascriptInterface
        public void resize() {
            bubble.post(new Runnable() {
                @Override
                public void run() {
                    if (console != null) console.requestLayout();
                }
            });
        }

        @JavascriptInterface
        public void cleared() { }
    }
}
