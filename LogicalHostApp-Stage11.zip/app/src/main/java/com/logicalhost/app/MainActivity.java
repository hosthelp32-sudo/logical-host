package com.logicalhost.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private static final String APP_URL = "https://logicalhost.online/android";
    private static final String APP_HOST = "logicalhost.online";
    private static final int NAVY = Color.parseColor("#050B1A");
    private static final int HIDE_AFTER_MS = 5000;
    private static final int POLL_MS = 500;

    // Reads the bot state from the page: the big button shows STOP when the bot is on
    private static final String BOT_STATE_JS =
            "(function(){return document.body && document.body.innerText.indexOf('STOP') > -1;})()";

    private static final int IMMERSIVE_FLAGS =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean inFront = false;
    private boolean botOn = false;
    private boolean bubbleRunning = false;
    private boolean bridgeActive = false;

    // The website calls LogicalHost.setBotState(true/false) when the bot starts or stops
    public class BotBridge {
        @android.webkit.JavascriptInterface
        public void setBotState(final boolean on) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    bridgeActive = true;
                    if (on != botOn) {
                        botOn = on;
                        updateBubble();
                    }
                }
            });
        }
    }

    private final Runnable hideBars = new Runnable() {
        @Override
        public void run() {
            hideSystemBars();
        }
    };

    private final Runnable pollBot = new Runnable() {
        @Override
        public void run() {
            if (webView != null && !bridgeActive) {
                webView.evaluateJavascript(BOT_STATE_JS, new android.webkit.ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        boolean nowOn = "true".equals(value);
                        if (nowOn != botOn) {
                            botOn = nowOn;
                            updateBubble();
                        }
                    }
                });
            }
            handler.postDelayed(this, POLL_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        window.setStatusBarColor(NAVY);
        window.setNavigationBarColor(NAVY);

        webView = new WebView(this);
        webView.setBackgroundColor(NAVY);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                // Keep your site inside the app. Open other links in the phone browser.
                if (host != null && host.endsWith(APP_HOST)) {
                    return false;
                }
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new BotBridge(), "LogicalHost");

        // Hide the top and bottom bars. Swipe from an edge to show them;
        // they hide again 5 seconds later.
        View decor = window.getDecorView();
        decor.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) {
                boolean barsShown = (visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0;
                handler.removeCallbacks(hideBars);
                if (barsShown) {
                    handler.postDelayed(hideBars, HIDE_AFTER_MS);
                }
            }
        });
        hideSystemBars();

        // Ask for notification permission once (Android 13+)
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
        }

        // Ask for "Display over other apps" once
        SharedPreferences prefs = getSharedPreferences("logicalhost_prefs", MODE_PRIVATE);
        if (!Settings.canDrawOverlays(this) && !prefs.getBoolean("overlay_asked", false)) {
            prefs.edit().putBoolean("overlay_asked", true).apply();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(APP_URL);
        }

        // Keep JavaScript running in the background so the bot state keeps syncing
        webView.resumeTimers();
        handler.post(pollBot);
    }

    // Bubble shows only while the bot is on and the app is not on screen
    private void updateBubble() {
        boolean shouldShow = botOn && !inFront && Settings.canDrawOverlays(this);
        if (shouldShow && !bubbleRunning) {
            BubbleService.start(this);
            bubbleRunning = true;
        } else if (!shouldShow && bubbleRunning) {
            BubbleService.stop(this);
            bubbleRunning = false;
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemBars();
        }
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(IMMERSIVE_FLAGS);
    }

    @Override
    public void onBackPressed() {
        // Go back in the web app first, then close the app.
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        inFront = true;
        webView.onResume();
        updateBubble();
    }

    @Override
    protected void onPause() {
        super.onPause();
        inFront = false;
        // Do not pause the page: keep it running so the bot state keeps syncing
        updateBubble();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (bubbleRunning) {
            BubbleService.stop(this);
            bubbleRunning = false;
        }
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
