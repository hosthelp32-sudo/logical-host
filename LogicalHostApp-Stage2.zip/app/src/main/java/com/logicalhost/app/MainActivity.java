package com.logicalhost.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {

    private static final String APP_URL = "https://logicalhost.online/android";
    private static final String APP_HOST = "logicalhost.online";

    private static final String PREFS = "logicalhost_prefs";
    private static final String KEY_THEME = "theme";

    // Theme keys and their display names (order matches the picker)
    private static final String[] THEME_KEYS = {"navy", "dark", "light"};
    private static final String[] THEME_NAMES = {"Navy Blue", "Dark", "Light"};

    private WebView webView;
    private ProgressBar progressBar;
    private LinearLayout toolbar;
    private TextView titleView;
    private Button themeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Let us color the status bar and navigation bar
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        // Top bar: app name + theme button
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(16), 0, dp(8), 0);

        titleView = new TextView(this);
        titleView.setText("LOGICAL HOST");
        titleView.setTextSize(18);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        titleView.setLetterSpacing(0.1f);
        toolbar.addView(titleView, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        themeButton = new Button(this);
        themeButton.setText("Theme");
        themeButton.setAllCaps(false);
        themeButton.setBackgroundColor(Color.TRANSPARENT);
        themeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showThemeDialog();
            }
        });
        toolbar.addView(themeButton);

        root.addView(toolbar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56)));

        // Web area fills the rest of the screen
        FrameLayout content = new FrameLayout(this);

        webView = new WebView(this);
        content.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        FrameLayout.LayoutParams barParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(3));
        barParams.gravity = Gravity.TOP;
        content.addView(progressBar, barParams);

        root.addView(content, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                // Keep your site inside the app. Open other links in the phone browser.
                if (host != null && host.endsWith(APP_HOST)) {
                    return false;
                }
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });

        // Apply the saved theme (default: Navy Blue)
        applyTheme(loadTheme());

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(APP_URL);
        }
    }

    // ---------- Theme ----------

    private String loadTheme() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        return prefs.getString(KEY_THEME, "navy");
    }

    private void saveTheme(String key) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_THEME, key).apply();
    }

    private void showThemeDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Choose theme")
                .setItems(THEME_NAMES, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        String key = THEME_KEYS[which];
                        saveTheme(key);
                        applyTheme(key);
                    }
                })
                .show();
    }

    private void applyTheme(String key) {
        int barColor;
        int textColor;
        boolean lightBars = false;

        switch (key) {
            case "dark":
                barColor = Color.parseColor("#050B1A");
                textColor = Color.WHITE;
                break;
            case "light":
                barColor = Color.parseColor("#F2F6FF");
                textColor = Color.parseColor("#0A1F44");
                lightBars = true;
                break;
            case "navy":
            default:
                barColor = Color.parseColor("#0A1F44");
                textColor = Color.WHITE;
                break;
        }

        Window window = getWindow();
        window.setStatusBarColor(barColor);
        window.setNavigationBarColor(barColor);

        int flags = 0;
        if (lightBars) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
        }
        window.getDecorView().setSystemUiVisibility(flags);

        toolbar.setBackgroundColor(barColor);
        titleView.setTextColor(textColor);
        themeButton.setTextColor(textColor);
        webView.setBackgroundColor(barColor);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    // ---------- Navigation and lifecycle ----------

    @Override
    public void onBackPressed() {
        // Go back in the web app first, then close the app.
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
