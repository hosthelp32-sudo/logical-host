LOGICAL HOST Android app

1. Upload LogicalHostApp.zip to the repo root. Do NOT unzip it.
2. Make sure .github/workflows/build-apk.yml is in the repo (the workflow runs from there).
3. Go to Actions > Build Android APK > Run workflow.
4. When it finishes, download LogicalHost.apk from Releases.
